# Beyond leading asymptotics in the lattice nonlinear Schrödinger model

## Read first

`lattice_lieb_liniger_continuation.pdf` is the polished continuation manuscript, based on **Sant’Ana, arXiv:2603.09522v3, 4 September 2026**. It contains 35 pages, 11 vector numerical figures, 27 references, and seven technical appendices. `main.tex` and `sections/` are the editable source. `references.tex` is the compiled bibliography; `references.bib` supplies machine-readable metadata.

The central distinction is maintained throughout: exact identities and the spectral scaling theorem are separated from the formal endpoint trans-series and empirical Borel–Padé tests. A global endpoint Borel-reconstruction theorem is **not** claimed. Read `AUTHOR_REVIEW.md` before public submission.

## What is included

- `figures/`: eleven independent vector PDF figures and PNG previews.
- `data/`: all retained result tables, parameter scans and plotted numerical records, not just successful runs.
- `reproducibility/endpoint/`: the high-order commuting-flow generator, approximately 200 coefficients per sector through exponential level 12, fixed-source and endpoint recursions, lateral resummation, independent TBA, and failed-method trials.
- `reproducibility/determinant_thermal/`: determinant sectors and parity solver, higher-order thermal formulas and nonlinear TBA tests.
- `reproducibility/spectral_reconstruction/`: exact boundary reconstruction, regularized determinant scaling, fractional spectrum and sum rule, interval-certified TBA, and fixed-density thermal tests.
- `audit/`: fresh tests performed for this manuscript, including the principal endpoint and determinant sums and the interval certificate.
- `source_manifest.json`, `environment.json`, `SHA256SUMS.txt`: provenance, software versions, and file integrity.

The three modules retain their directory structure, with one shared basis file as described below. Their archived notes document the chronology; **the current paper supersedes their comparisons with the March revision**. The original module checksums are labelled `ORIGINAL_...`; the root checksum file describes this delivery.

`basis200_r8.json` is stored once, at `reproducibility/endpoint/data/basis200_r8.json`. The determinant/thermal generator resolves that sibling module's file relative to its own script location, so it does not depend on the current working directory. Keep both module directories together when extracting the archive. Historical module checksums describe the original layout with two copies; the root checksums describe the current shared layout.

## Inputs excluded from this public archive

- `o3.pdf`: Dániel Nógrádi's unpublished note, retained privately.
- `nenr_336.txt`: private coefficient input, retained privately.
- `2603.09522v3.pdf`: reference paper, available from [arXiv](https://arxiv.org/abs/2603.09522v3) instead of being redistributed here.

These exclusions apply to the public archive; original input files remain local. `source_manifest.json` lists them under `withheld_inputs`. Historical audit records and `ORIGINAL_...` checksums describe the earlier private delivery.

## Build the PDF

A normal TeX Live installation with pdfLaTeX, NewTX fonts, AMS packages, microtype, booktabs, hyperref and cleveref is sufficient. No font files are distributed. No BibTeX executable is required.

```bash
make
# Equivalently:
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

## Reproduce figures and fast checks

Figure generation uses the included data. The complete check runner below includes an independent comparison against `nenr_336.txt` and therefore requires that private input at `reproducibility/endpoint/inputs/nenr_336.txt`. It cannot complete from the public archive alone. The endpoint module's README separates that private-input check from the other checks; the determinant/thermal and spectral/reconstruction modules retain their own runners.

```bash
python -m pip install -r requirements.txt
python code/make_figures.py
python code/run_all_checks.py
```

The figure script uses retained high-precision records, not new fitted data. Its small-difference calculations use mpmath before conversion to plotting precision. Generated table extracts are in `tables/`; the paper also contains fixed copies of their selected rows for robust standalone TeX compilation.

## Reproduce the principal endpoint sum

```bash
cd reproducibility/endpoint/code
python green_resum.py ../data/sectors200_n12.json --Q .9 -n 1 -T 190 \
  --phi .50 --inner 384 --outer 32 --dps 200 --evaldps 90 \
  --out ../results/green_new.json
python factorized_resum.py ../data/basis200_r8.json --Q .9 \
  --T0 198 --TI 190 --TF 130 --phi .4 --nodes 512 --dps 200 \
  --green ../results/green_new.json --out ../results/factorized_new.json
```

The Green file is tied to its Q value. The code rejects mismatched input. Main-text signed remainders use independently computed reference values.

## Determinant and certified reference

```bash
(cd reproducibility/determinant_thermal/code && \
 python determinant_numeric.py resum --Q .9 --T 154 --phi .45 --nodes 512 --dps 170)
(cd reproducibility/spectral_reconstruction/code && \
 python interval_tba.py --Q .9 --n 64)
```

Read each module README for larger scans and seed regeneration. The optional production seed generation requires C++17 and Boost headers. Existing coefficient files suffice for all comparisons.

## What was rerun

For this manuscript: all three fast suites; the principal endpoint Green integral and factorized sum; the 154-term determinant sum; the Q=0.9, 64-node interval certificate; and all manuscript figure/table transformations. The portable copies of all three suites were also tested after packaging.

The complete 210-order seed-generation run, all large eigenvalue grids and every thermal scan were **retained, not rerun wholesale**. Their source code and original outputs are included. The paper distinguishes generated sectors from numerically resolved ones.

## Rights and unpublished input

The manuscript author is Istvan Vona. Reference [14] credits Dániel Nógrádi's unpublished note dated 21 October 2026. The private note and `nenr_336.txt`, together with the reference-paper PDF, are excluded as detailed above. The shared-data path was checked with small numerical regression runs for this packaging update; the full scientific validation was not rerun. Other included materials retain their original rights.
