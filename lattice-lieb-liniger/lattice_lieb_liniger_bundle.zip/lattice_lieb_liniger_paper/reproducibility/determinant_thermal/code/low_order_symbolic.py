"""Exact low-order verification; no fitted numerical coefficient recognition."""
import sympy as s
v=s.symbols('v',positive=True); Z3,Z5=s.symbols('zeta3 zeta5'); M=5
tr=lambda x:s.series(x,v,0,M+1).removeO().expand()
dot=lambda x:tr(-2*v**2/(1-v)*s.diff(x,v))
A=1/(16*v**2)-1/(4*v)-s.Rational(1,16)+(1-3*Z3)*v/32+(5-33*Z3)*v**2/96+(118-1776*Z3-405*Z5)*v**3/1536
qbar=tr(s.sqrt(tr(-8*v**3/(1-v)*s.diff(A,v))))
# log derivative of a0, a0=qbar/(2 sqrt(v))
p0=tr(-2*v**2/(1-v)*(s.diff(qbar,v)/qbar-1/(2*v)))
U=tr(dot(p0)+p0*p0)
def linear(rhs,lam,mu=0):
 rhs=tr(rhs); f=0
 for n in range(M+1):
  c=s.expand(rhs).coeff(v,n)+2*sum((mu+k)*s.expand(f).coeff(v,k) for k in range(n))
  f+=s.expand(c/lam)*v**n
 return tr(f)
a={};X={};N={}
for r in range(1,4):
 f=s.Integer(1)
 for n in range(1,M+1):
  c=s.symbols('c');trial=f+c*v**n
  residual=tr(dot(dot(trial))-4*r*dot(trial)-U*trial)
  f+=s.solve(residual.coeff(v,n+1),c)[0]*v**n if n<M else 0
 a[r]=f;X[r]=linear(tr(qbar*f/2),-2*r,s.Rational(-1,2))
for r in a:
 for k in a:N[r,k]=linear(tr(a[r]*a[k]),-2*(r+k))
# Factor exp(-n) from each Lambda^n coefficient.
S={r:2*s.I*s.Rational(r**(2*r),s.factorial(r-1)*s.factorial(r)) for r in a}
W={(r,n):s.Integer(0) for r in a for n in range(7)}
c={0:s.Integer(1)}
for n in range(1,7):
 ch=0
 for r in a:
  if n>=2*r:
   z=X[r] if n==2*r else 0
   z+=sum(W[k,n-2*r]*N[k,r] for k in a)
   W[r,n]=tr(S[r]*z)
  ch+=W[r,n]*a[r]
 c[n]=tr(2*ch/qbar)
p={0:p0};G={}
for n in range(1,7):
 p[n]=tr(dot(c[n])-2*n*c[n]-sum(c[k]*p[n-k] for k in range(1,n)))
 rhs=tr(-sum(p[k]*p[n-k] for k in range(n+1)))
 G[n]=linear(linear(rhs,-2*n),-2*n)
 if n%2==0:print('e^n G_',n,'=',s.series(G[n],v,0,4))
D=1/(2*s.pi*v)-1+(s.pi**2-3)*v/(12*s.pi)+(8*s.pi**2-9+27*Z3)*v**2/(24*s.pi)+(9*s.pi**4+250*s.pi**2-145+2370*Z3)*v**3/(240*s.pi)
# Q derivatives contain pi; mu = -pi^2 D_b/a0^2
mu=tr(-4*s.pi**2*v*dot(D)/qbar**2)
vs=tr(-s.pi*(-2*v**2/(1-v))*s.diff(mu,v)/mu)
print('mu=',s.series(mu,v,0,5));print('vs=',s.series(vs,v,0,5))
