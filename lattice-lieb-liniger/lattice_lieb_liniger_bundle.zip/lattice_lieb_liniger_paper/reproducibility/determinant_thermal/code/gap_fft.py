"""Piecewise-constant Galerkin approximation of the Love operator.
The exact cell integrals are evaluated by a rapidly convergent local series;
a Toeplitz FFT matvec allows large Q without dense matrices.
"""
import numpy as np, scipy.fft as fft, scipy.sparse.linalg as sla
import time,json
from pathlib import Path

def gap(Q,h=.05):
    n=int(round(2*Q/h));h=2*Q/n;x=h*np.arange(n,dtype=float)
    z=h/(x-1j);power=z.copy();c=np.zeros(n)
    for k in range(12):
        c+=2*power.imag/((2*k+1)*(2*k+2)*np.pi);power*=z*z
    nfft=fft.next_fast_len(2*n-1);emb=np.zeros(nfft);emb[:n]=c;emb[-(n-1):]=c[1:][::-1];ce=fft.rfft(emb)
    calls=[0]
    def mv(a):
        calls[0]+=1;v=np.zeros(nfft);v[:n]=a
        return fft.irfft(ce*fft.rfft(v),nfft)[:n]
    op=sla.LinearOperator((n,n),matvec=mv,dtype=float)
    # Even positive initial vector selects the top even state.
    start=np.sqrt(np.maximum(0,1-((-Q+(np.arange(n)+.5)*h)/Q)**2))
    t=time.time();val,vec=sla.eigsh(op,k=1,which='LA',tol=2e-14,v0=start,ncv=30)
    residual=np.linalg.norm(mv(vec[:,0])-val[0]*vec[:,0]);delta=1-val[0]
    return dict(Q=Q,h=h,n=n,gap=delta,Qgap=Q*delta,residual=residual,calls=calls[0],seconds=time.time()-t)

if __name__=='__main__':
 out=[]
 for Q in [32,64,128,256,512,1024,2048,4096,8192]:
  for h in [.1,.05]:
   d=gap(Q,h);out.append(d);print(d,flush=True)
 (Path(__file__).resolve().parents[1]/'results/gaps_fft.json').write_text(json.dumps(out,indent=2))
