"""Small, deterministic checks of the supplied formulas and recorded comparisons."""
from pathlib import Path
import json
import mpmath as mp
from exact_checks import solve
from thermodynamics import finiteT_subtracted,zero

ROOT=Path(__file__).resolve().parents[1]
mp.mp.dps=80
basis=json.loads((ROOT/'data/determinant_sectors.json').read_text())
dec=lambda a:{int(k):mp.mpc(*x) for k,x in a.items()}
sectors=list(map(dec,basis['logdet']))
for n in [1,3,5,7]:assert not sectors[n],f'Unexpected odd sector {n}'
assert abs(sectors[2][2]+mp.j/(2*mp.e**2))<mp.mpf('1e-70')
assert abs(sectors[4][0]-1/(4*mp.e**4))<mp.mpf('1e-70')
assert abs(sectors[6][0]-16/(9*mp.e**6))<mp.mpf('1e-70')
print('PASS: sector parity and exact leading coefficients')
beta=-mp.mpf(1)/6+mp.mpf(7)/12*mp.log(2)+mp.mpf(3)/4*mp.log(mp.pi)+6*mp.diff(mp.zeta,-1)
assert abs(mp.mpf(basis['beta_Q'])-beta)<mp.mpf('1e-70')
print('PASS: two analytic normalizations of the FH constant')
a=json.loads((ROOT/'results/exact_det_Q.9_n65.json').read_text());b=json.loads((ROOT/'results/exact_det_Q.9_n80.json').read_text())
assert abs(mp.mpf(a['logdet'])-mp.mpf(b['logdet']))<mp.mpf('1e-62')
exact=mp.mpf(b['logdet'])
for file in ['resum_det_Q.9_T150_phi.55_nodes512.json','resum_det_Q.9_T154_phi.45_nodes512.json','resum_det_Q.9_T158_phi.4_nodes512.json']:
 z=json.loads((ROOT/'results'/file).read_text())['data'];rem=exact-mp.mpf(z[-2]['cumre']);pred=mp.mpf(z[-1]['re'])
 assert abs(rem/pred-1)<mp.mpf('.0004')
print('PASS: stored determinant quadrature convergence and Lambda^8 stability ensemble')
z=solve(.9,80)
assert abs(z['chi']-z['parity_ratio'])<1e-12
print('PASS: fresh parity determinant / Love boundary identity')
t=finiteT_subtracted(.9,.005,50)
assert abs(t['omega_T4_estimate']-t['predicted_T4'])<.0002
print('PASS: fresh nonlinear thermal comparison approaches the T^4 formula')
q=zero(.9);h=1e-4
vs=-(zero(.9+h)['mu']-zero(.9-h)['mu'])/(2*h*q['mu'])
assert abs(vs-q['vs'])<2e-9
print('PASS: independent sound-velocity derivative identity')
