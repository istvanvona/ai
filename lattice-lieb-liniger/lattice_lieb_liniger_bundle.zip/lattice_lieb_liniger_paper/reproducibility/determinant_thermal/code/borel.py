"""High-precision lateral Borel(-Leroy)-Pade with refined Laguerre nodes."""
import scipy.linalg as la
import mpmath as mp, numpy as np, scipy.special as sp, json, argparse,time,os

def lag_pair(n,alpha,x):
 l0=mp.mpf(1);l1=1+alpha-x
 if n==0:return l0,mp.mpf(0)
 for k in range(1,n):l0,l1=l1,((2*k+1+alpha-x)*l1-(k+alpha)*l0)/(k+1)
 return l1,(n*l1-(n+alpha)*l0)/x

def nodes(n,alpha=0,dps=75,cache='../data'):
 name=f'{cache}/laguerre_{n}_{str(alpha)}_{dps}.json'
 if os.path.exists(name):return [(mp.mpf(x),mp.mpf(w)) for x,w in json.load(open(name))]
 old=mp.mp.dps;mp.mp.dps=dps+15
 if n<=300:roots,_=sp.roots_genlaguerre(n,float(alpha))
 else:
  k=np.arange(n,dtype=float);roots=la.eigh_tridiagonal(2*k+1+float(alpha),np.sqrt(k[1:]*(k[1:]+float(alpha))),eigvals_only=True)
 ans=[];pref=mp.gamma(n+alpha+1)/mp.factorial(n)
 for xx in roots:
  x=mp.mpf(float(xx))
  for _ in range(5):
   f,df=lag_pair(n,alpha,x);dx=f/df;x-=dx
   if abs(dx)<mp.mpf(10)**(-dps-5):break
  _,df=lag_pair(n,alpha,x);weight=pref/(x*df*df);ans.append((x,weight))
 json.dump([[mp.nstr(x,dps),mp.nstr(w,dps)] for x,w in ans],open(name,'w'));mp.mp.dps=old;return ans

def eval_poly(c,x):
 r=0
 for a in reversed(c):r=r*x+a
 return r

def bsum_terms(coefs,v,T,phi,nodes_,leroy=1):
 total=mp.mpc(0);c={int(k):mp.mpc(*val) for k,val in coefs.items()}
 for parity in [0,1]:
  keys=sorted(k for k,val in c.items() if k%2==parity and val)
  if not keys:continue
  # Keep all nonpositive integer powers explicit, and factor half powers.
  k0=keys[0]
  # For a series starting with v^-1 or constant, sum first term(s) exactly.
  while k0<=0:
   total+=c.get(k0,0)*v**(mp.mpf(k0)/2);k0+=2
  a=[c.get(k0+2*i,0) for i in range(T)]
  if not any(a):continue
  bb=[a[i]/mp.gamma(i+leroy) for i in range(T)]
  nn=T//2;mm=T-1-nn;p,q=mp.pade(bb,mm,nn)
  ei=mp.exp(1j*phi);fac=mp.exp(1j*leroy*phi)
  zsum=mp.fsum(weight*mp.exp(-(ei-1)*x)*eval_poly(p,v*ei*x)/eval_poly(q,v*ei*x) for x,weight in nodes_)
  total+=v**(mp.mpf(k0)/2)*fac*zsum
 return total

def compare(path,Q,T=50,phi='0.22',nnode=180,dps=100,leroy='1',which='rho',nmax=None):
 mp.mp.dps=dps;dat=json.load(open(path));Q=mp.mpf(str(Q));phi=mp.mpf(phi);leroy=mp.mpf(leroy)
 v=-1/mp.lambertw(-mp.exp(-2*mp.pi*Q)/(8*mp.e),-1);Lam=mp.exp(-2*mp.pi*Q)
 nd=nodes(nnode,leroy-1,dps=min(dps,100));res=[];cum=mp.mpc(0);nmax=len(dat[which])-1 if nmax is None else nmax
 for n in range(nmax+1):
  val=bsum_terms(dat[which][n],v,T,phi,nd,leroy)*Lam**n
  if n==0 and which=='rho':val+=mp.mpf(dat['rho_log'])*mp.log(v)
  cum+=val;res.append({'n':n,'sector_re':mp.nstr(val.real,40),'sector_im':mp.nstr(val.imag,40),'sum_re':mp.nstr(cum.real,40),'sum_im':mp.nstr(cum.imag,40)})
  print(which,'Q',Q,'T',T,'n',n,'sum',mp.nstr(cum,24),'piece',mp.nstr(val,15),flush=True)
 return {'Q':str(Q),'v':mp.nstr(v,40),'T':T,'phi':str(phi),'nnode':nnode,'dps':dps,'leroy':str(leroy),'which':which,'data':res}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--Q',default='.9');p.add_argument('-T',type=int,default=50);p.add_argument('--phi',default='.22');p.add_argument('--nodes',type=int,default=180);p.add_argument('--dps',type=int,default=100);p.add_argument('--leroy',default='1');p.add_argument('--which',default='rho');p.add_argument('--nmax',type=int,default=None);p.add_argument('--out',required=True);a=p.parse_args();t=time.time();r=compare(a.path,a.Q,a.T,a.phi,a.nodes,a.dps,a.leroy,a.which,a.nmax);r['runtime']=time.time()-t;json.dump(r,open(a.out,'w'),indent=2);print('runtime',r['runtime'])
