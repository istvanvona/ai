"""Cancellation-reduced finite-temperature comparison against the exact T^4 formula."""
import json
from pathlib import Path
from thermodynamics import finiteT_subtracted

def main():
 out=[]
 for Q in [.9,2.]:
  for n in [60,80]:
   for T in [.01,.005,.0025,.00125]:
    a=finiteT_subtracted(Q,T,n);out.append(a);print(a,flush=True)
 dest=Path(__file__).resolve().parents[1]/'results/thermo_subtracted.json'
 dest.write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
