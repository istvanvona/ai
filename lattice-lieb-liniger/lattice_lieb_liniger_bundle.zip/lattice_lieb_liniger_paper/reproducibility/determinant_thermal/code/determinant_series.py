"""Generate log det(I-L_Q) from the previously computed Love boundary series.
All new transformations follow the exact identity logdet''=-(chi'/chi)^2.
No numerical integral-equation data are used to construct coefficients.
"""
import sys,json,time,argparse
from pathlib import Path
import mpmath as mp
sys.path.insert(0,str(Path(__file__).resolve().parent))
import sectors as S

def integrate_v(poly):
    out={};log=mp.mpc(0)
    for k,c in poly.items():
        if k==-2:log+=c
        else:out[k+2]=c/(mp.mpf(k)/2+1)
    return out,log

def generate(N=110,nmax=8,dps=150):
    mp.mp.dps=dps;S.KMAX=2*N+8
    dat=json.load(open(Path(__file__).resolve().parents[2]/'endpoint/data/basis200_r8.json'))
    dec=lambda a:S.trim({int(k):mp.mpc(*z) for k,z in a.items()})
    q=dec(dat['a'][0]); rmax=nmax//2
    X={r:dec(dat['X'][r]) for r in range(1,rmax+1)}
    ar={r:dec(dat['a'][r]) for r in range(1,rmax+1)}
    NN={}
    for r in ar:
      for s in ar:
        key=f'{min(r,s)},{max(r,s)}'
        NN[r,s]=dec(dat['blocks'][dat['Npair'][key]])
    SS={r:2j*mp.power(mp.mpf(r)/mp.e,2*r)/(mp.factorial(r-1)*mp.factorial(r)) for r in ar}
    W={(r,n):{} for r in ar for n in range(nmax+1)}
    chi=[q]+[{} for _ in range(nmax)]
    for n in range(1,nmax+1):
      for r in ar:
        if n>=2*r:
          z=X[r].copy() if n==2*r else {}
          for s in ar:z=S.add(z,S.mul(W[s,n-2*r],NN[s,r]))
          W[r,n]=S.scale(z,SS[r]);chi[n]=S.add(chi[n],S.mul(W[r,n],ar[r]))
    invq=S.inverse(chi[0]);p=[];G=[];rhs=[]
    beta=-mp.mpf(1)/6+mp.log(4*mp.pi)/4+3*mp.diff(mp.zeta,-1)+2*mp.log(mp.barnesg(mp.mpf('1.5')))
    cv=beta-mp.log(2*mp.pi)/4
    for n in range(nmax+1):
        num=S.add(S.dot(chi[n]),chi[n],-2*n)
        for k in range(1,n+1):num=S.add(num,S.mul(chi[k],p[n-k]),-1)
        p.append(S.mul(num,invq));a={}
        for k in range(n+1):a=S.add(a,S.mul(p[k],p[n-k]),-1)
        rhs.append(a)
        if n:
            G.append(S.ode(S.ode(a,-2*n),-2*n))
        else:
            prim,l1=integrate_v(S.mul(a,{-4:-mp.mpf('.5'),-2:mp.mpf('.5')}))
            assert abs(l1)<mp.mpf('1e-100')
            g,l2=integrate_v(S.mul(prim,{-4:-mp.mpf('.5'),-2:mp.mpf('.5')}))
            g[0]=cv;G.append(g);print('logcoeff',l2,flush=True)
        print(n,[(k,mp.nstr(c,16)) for k,c in sorted(G[n].items())[:6]],flush=True)
    def enc(a):return {str(k):[mp.nstr(c.real,dps),mp.nstr(c.imag,dps)] for k,c in a.items() if k<=2*N}
    out={'N':N,'nmax':nmax,'dps':dps,'logdet':list(map(enc,G)),'curvature':list(map(enc,rhs)),
         'beta_Q':str(beta),'log_coefficient':'-0.25','explicit_linear_term':'-pi*Q/3',
         'source':'basis200_r8.json: constant-source blocks only'}
    path=Path(__file__).resolve().parents[1]/'data/determinant_sectors.json';path.write_text(json.dumps(out))
    return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--N',type=int,default=110);a=p.parse_args();generate(N=a.N)
