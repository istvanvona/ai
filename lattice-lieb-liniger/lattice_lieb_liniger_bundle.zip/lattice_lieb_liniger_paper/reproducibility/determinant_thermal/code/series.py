"""Dense truncated power series; scalar coefficients are mpmath numbers."""
import mpmath as mp

def pad(a,n): return list(a[:n])+[mp.mpf(0)]*max(0,n-len(a))
def add(a,b,n):
 a,b=pad(a,n),pad(b,n);return [a[i]+b[i] for i in range(n)]
def mul(a,b,n):
 c=[mp.mpf(0)]*n
 for i,x in enumerate(a[:n]):
  if x:
   for j,y in enumerate(b[:n-i]):
    if y:c[i+j]+=x*y
 return c
def scale(a,c):return [x*c for x in a]
def inv(a,n):
 c=[1/a[0]]
 for k in range(1,n):c.append(-sum(a[j]*c[k-j] for j in range(1,min(k+1,len(a))))/a[0])
 return c
def power(a,p,n):
 a=pad(a,n);b=[a[0]**p]
 for k in range(1,n):b.append(sum(((p+1)*j-k)*a[j]*b[k-j] for j in range(1,k+1))/(k*a[0]))
 return b
def log(a,n):
 r=mul([(i+1)*a[i+1] for i in range(len(a)-1)],inv(a,n),n-1)
 return [mp.log(a[0])]+[r[i-1]/i for i in range(1,n)]
def compose(a,b,n):
 r=[mp.mpf(0)]*n
 for x in reversed(a[:n]):
  r=mul(r,b,n);r[0]+=x
 return r

def binomial(p,n):
 a=[mp.mpf(1)]
 for k in range(1,n):a.append(a[-1]*(-2)*(p-k+1)/k)
 return a

def dx(a,mu,n):
 d=scale(binomial(-mp.mpf('0.5'),n),-2)
 r=mul([(k+mu)*x for k,x in enumerate(a)],d,n-1)
 return [mp.mpf(0)]+r

def w_of_v(n):
 """Newton-doubling reversion of 2x(w)=1/v+log(v)-1."""
 t=binomial(mp.mpf('.5'),n+1)
 p=scale(t,mp.mpf('.5'));p[0]+=mp.mpf('.5')
 lp=log(p,n)
 R=[mp.mpf(0)]+[t[k+1]-2*lp[k] for k in range(1,n)]
 Rp=[(k+1)*R[k+1] for k in range(n-1)]
 W=[mp.mpf(1)];m=1
 while m<n:
  m=min(2*m,n);W=pad(W,m);iw=inv(W,m)
  w=[mp.mpf(0)]+W[:-1]
  F=add(add(iw,[0]+log(W,m-1),m),[0]+compose(R,w,m-1),m);F[0]-=1
  Fp=add(add(scale(mul(iw,iw,m),-1),[0]+iw[:-1],m),[0,0]+compose(Rp,w,max(0,m-2)),m)
  W=add(W,scale(mul(F,inv(Fp,m),m),-1),m)
 return [mp.mpf(0)]+W[:n-1]
