"""Zero-T derivative identities and finite-T Yang-Yang comparison, kappa=1."""
import numpy as np, scipy.linalg as la
from scipy.special import roots_legendre, expit
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'data'
RESULTS=ROOT/'results'
RESULTS.mkdir(exist_ok=True)
K=lambda x:1/(np.pi*(1+x*x))
Kp=lambda x:-2*x/(np.pi*(1+x*x)**2)
Kpp=lambda x:(6*x*x-2)/(np.pi*(1+x*x)**3)
Kppp=lambda x:24*x*(1-x*x)/(np.pi*(1+x*x)**4)

def zero(Q,n=120):
 z,w=roots_legendre(n);x=(z+1)*Q/2;w=w*Q/2
 KK=K(x[:,None]-x[None,:])+K(x[:,None]+x[None,:])
 A=np.eye(n)-KK*w[None,:]
 f,r=la.solve(A,np.array([np.ones(n),K(x)]).T).T
 edge=K(Q-x)+K(Q+x);de=Kp(Q-x)+Kp(Q+x)
 chi=1+np.dot(edge*w,f);eta=K(Q)+np.dot(edge*w,r)
 fx=np.dot(de*w,f);rx=Kp(Q)+np.dot(de*w,r)
 mu=-2*np.pi*eta/chi;energy=-4*np.pi*np.dot(w*K(x),r)
 D=2*np.dot(w,r);eps=-2*np.pi*r-mu*f
 epsx=-2*np.pi*rx-mu*fx;vs=epsx/(2*np.pi*eta)
 R=K(0)+2*np.dot(w*K(x),r)
 d2=Kpp(Q-x)+Kpp(Q+x);d3=Kppp(Q-x)+Kppp(Q+x)
 rxx=Kpp(Q)+np.dot(d2*w,r);rxxx=Kppp(Q)+np.dot(d3*w,r)
 fxx=np.dot(d2*w,f);fxxx=np.dot(d3*w,f)
 epsxx=-2*np.pi*rxx-mu*fxx;epsxxx=-2*np.pi*rxxx-mu*fxxx
 Af=la.solve(A,edge);Ae=K(0)+K(2*Q)+np.dot(edge*w,Af)
 Axe=Kp(2*Q)+np.dot(de*w,Af)
 c1=np.pi**2/6;c2=7*np.pi**4/360
 eps2=-c1*Ae/epsx;eps2x=-c1*Axe/epsx
 der1=(rx*eps2+eta*eps2x)/epsx**2-eta*eps2*epsxx/epsx**3
 der2=rxx/epsx**3-3*rx*epsxx/epsx**4-eta*epsxxx/epsx**4+3*eta*epsxx**2/epsx**5
 omega4=-eta*eps2**2/epsx+2*c1*der1-2*c2*der2
 return dict(Q=Q,mu=mu,vs=vs,chi=chi,eta=eta,D=D,R=R,energy=energy,
             omega0=energy-mu*D,kL=chi**2,cv_coefficient=np.pi/(3*vs),
             Dprime=2*chi*eta,mup=epsx/chi,omega_T4=omega4)

def finiteT(Q,T,n=60):
 z0=zero(Q);mu=z0['mu'];ends=sorted(set([0.,max(0,Q-.4),Q-.12,Q,Q+.12,Q+.4,2.,4.,8.,16.]))
 ends=[x for x in ends if x>=0]
 zz,ww=roots_legendre(n);x=np.concatenate([(b+a)/2+(b-a)*zz/2 for a,b in zip(ends[:-1],ends[1:])]);w=np.concatenate([(b-a)*ww/2 for a,b in zip(ends[:-1],ends[1:])])
 mat=(K(x[:,None]-x[None,:])+K(x[:,None]+x[None,:]))*w[None,:]
 bare=-2/(1+x*x)-mu;eps=bare.copy()
 for it in range(20):
  occ=expit(-eps/T);F=eps-bare+T*(mat@np.logaddexp(0,-eps/T))
  delta=la.solve(np.eye(len(x))-mat*occ[None,:],F);eps-=delta
  if np.max(abs(delta))<2e-14:break
 res=eps-bare+T*mat@np.logaddexp(0,-eps/T)
 omega=-2*T*np.dot(w*K(x),np.logaddexp(0,-eps/T))
 pred=-np.pi*T*T/(6*z0['vs']);diff=omega-z0['omega0']
 return dict(T=T,n=n,omega=omega,omega0=z0['omega0'],delta=diff,predicted_T2=pred,ratio=diff/pred,T4_prediction=z0['omega_T4'],T4_from_difference=(diff-pred)/T**4,iterations=it+1,residual=np.max(abs(res)))

if __name__=='__main__':
 out={}
 for Q in [.9,2.]:
  a=zero(Q);h=1e-4;muprime=(zero(Q+h)['mu']-zero(Q-h)['mu'])/(2*h)
  a['vs_from_mu_derivative']=-muprime/a['mu']
  tests=[finiteT(Q,T) for T in [.02,.01,.005,.0025]]
  out[str(Q)]={'zero':a,'finiteT':tests};print(Q,a,tests,flush=True)
 (RESULTS/'thermodynamic_checks.json').write_text(json.dumps(out,indent=2))


def finiteT_subtracted(Q,T,n=80):
 """Solve for epsilon(T)-epsilon(0), avoiding cancellation of O(1) pressures.
 A composite rule has the zero-temperature Fermi endpoint as a panel boundary.
 The chemical potential and sound speed are recomputed on its occupied nodes.
 """
 ends=sorted(set([0.,max(0.,Q-.4),max(0.,Q-.12),Q,Q+.12,Q+.4,2.,4.,8.,16.]))
 zz,ww=roots_legendre(n)
 x=np.concatenate([(a+b)/2+(b-a)*zz/2 for a,b in zip(ends[:-1],ends[1:])])
 w=np.concatenate([(b-a)*ww/2 for a,b in zip(ends[:-1],ends[1:])])
 mat=(K(x[:,None]-x[None,:])+K(x[:,None]+x[None,:]))*w[None,:]
 mask=x<Q;xs=x[mask];ws=w[mask];As=np.eye(mask.sum())-mat[np.ix_(mask,mask)]
 fs,rs=la.solve(As,np.array([np.ones(len(xs)),K(xs)]).T).T
 edge=K(Q-xs)+K(Q+xs);der=Kp(Q-xs)+Kp(Q+xs)
 chi=1+np.dot(edge*ws,fs);eta=K(Q)+np.dot(edge*ws,rs)
 mu=-2*np.pi*eta/chi;es=-2*np.pi*rs-mu*fs
 eps0=-2/(1+x*x)-mu+mat[:,mask]@es
 # In the occupied interval use the solved vector directly.
 eps0[mask]=es
 ep=-2*np.pi*(Kp(Q)+np.dot(der*ws,rs))-mu*np.dot(der*ws,fs)
 vs=ep/(2*np.pi*eta)
 delta=np.zeros_like(x)
 for it in range(20):
  eps=eps0+delta;neg=eps<0
  thermal=T*np.log1p(np.exp(-np.abs(eps)/T))
  H=thermal.copy()
  both=neg & mask;H[both]-=delta[both]
  H[neg & ~mask]-=eps[neg & ~mask]
  H[~neg & mask]+=eps0[~neg & mask]
  F=delta+mat@H
  update=la.solve(np.eye(len(x))-mat*expit(-eps/T)[None,:],F)
  delta-=update
  if np.max(np.abs(update))<3e-16*max(T,1e-3):break
 # Recompute thermal difference after final Newton step.
 eps=eps0+delta;neg=eps<0
 H=T*np.log1p(np.exp(-np.abs(eps)/T))
 H[neg & mask]-=delta[neg & mask]
 H[neg & ~mask]-=eps[neg & ~mask]
 H[~neg & mask]+=eps0[~neg & mask]
 domega=-2*np.dot(w*K(x),H);c2=-np.pi/(6*vs)
 return dict(Q=Q,T=T,n=n,mu=mu,vs=vs,delta_omega=domega,omega_T4_estimate=(domega-c2*T*T)/T**4,
             predicted_T4=zero(Q)['omega_T4'],residual=float(np.max(abs(delta+mat@H))),iterations=it+1)
