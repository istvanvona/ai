"""Independent arbitrary-precision Nystrom determinant and lateral-sector checks."""
import sys,os,json,argparse,time
from pathlib import Path
import mpmath as mp
from scipy.special import roots_legendre
sys.path.insert(0,str(Path(__file__).resolve().parent))
import borel
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'data'
RESULTS=ROOT/'results'
RESULTS.mkdir(exist_ok=True)

def rule(n,dps):
    cache=BASE/f'legendre_{n}_{dps}.json'
    if cache.exists():return [(mp.mpf(x),mp.mpf(w)) for x,w in json.loads(cache.read_text())]
    ans=[]
    for xx in roots_legendre(n)[0]:
        x=mp.mpf(float(xx))
        for j in range(7):
            p0,p1=mp.mpf(1),x
            for k in range(1,n):p0,p1=p1,((2*k+1)*x*p1-k*p0)/(k+1)
            dp=n*(x*p1-p0)/(x*x-1);step=p1/dp;x-=step
            if abs(step)<mp.power(10,-dps-5):break
        dp=n*(x*mp.legendre(n,x)-mp.legendre(n-1,x))/(x*x-1)
        ans.append((x,2/((1-x*x)*dp*dp)))
    cache.write_text(json.dumps([[mp.nstr(x,dps+8),mp.nstr(w,dps+8)] for x,w in ans]))
    return ans

def exact(Q,n=70,dps=70):
    mp.mp.dps=dps+15;Q=mp.mpf(str(Q));nodes=rule(n,dps)
    x=[(z+1)*Q/2 for z,w in nodes];w=[w*Q/2 for z,w in nodes];sw=list(map(mp.sqrt,w))
    ld=[];rs=[];K=lambda z:1/(mp.pi*(1+z*z));chi=None
    for sg in [1,-1]:
        A=mp.matrix(n)
        for i in range(n):
            for j in range(i+1):
                A[i,j]=A[j,i]=(1 if i==j else 0)-sw[i]*sw[j]*(K(x[i]-x[j])+sg*K(x[i]+x[j]))
        C=mp.cholesky(A);ld.append(2*sum(mp.log(C[i,i]) for i in range(n)))
        f=mp.cholesky_solve(A,mp.matrix(sw)) if sg==1 else None
        src=mp.matrix([sw[i]*(K(Q-x[i])+sg*K(Q+x[i])) for i in range(n)])
        z=mp.cholesky_solve(A,src)
        rs.append(K(0)+sg*K(2*Q)+mp.fdot(src,z))
        if sg==1:chi=1+mp.fdot(src,f)
    return {'Q':str(Q),'n':n,'dps':dps,'logdet':mp.nstr(sum(ld),dps),
            'chi':mp.nstr(chi,dps),'parity_error':mp.nstr(chi-mp.exp(ld[1]-ld[0]),10),
            'curvature_b':mp.nstr(-(rs[0]-rs[1])**2/mp.pi**2,dps)}

def resume(Q,T,phi,nnode,dps):
    mp.mp.dps=dps;dat=json.load(open(BASE/'determinant_sectors.json'))
    Q=mp.mpf(str(Q));v=-1/mp.lambertw(-mp.exp(-2*mp.pi*Q)/(8*mp.e),-1);Lam=mp.exp(-2*mp.pi*Q)
    nodes=borel.nodes(nnode,0,dps=min(90,dps),cache=str(BASE));out=[];cum=mp.mpc(0)
    for n,z in enumerate(dat['logdet']):
        if n%2:continue
        s=borel.bsum_terms(z,v,T,mp.mpf(phi),nodes,1)*Lam**n
        if n==0:s-=mp.pi*Q/3+mp.log(v)/4
        cum+=s;out.append({'n':n,'re':mp.nstr(s.real,50),'im':mp.nstr(s.imag,50),'cumre':mp.nstr(cum.real,50),'cumim':mp.nstr(cum.imag,50)})
        print('Q',Q,'T',T,'n',n,'cumulative',mp.nstr(cum,30),'piece',mp.nstr(s,20),flush=True)
    return dict(Q=str(Q),T=T,phi=phi,nnode=nnode,dps=dps,data=out)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['exact','resum']);p.add_argument('--Q',default='.9');p.add_argument('--n',type=int,default=70);p.add_argument('--T',type=int,default=90);p.add_argument('--phi',default='.45');p.add_argument('--nodes',type=int,default=320);p.add_argument('--dps',type=int,default=90);a=p.parse_args();t=time.time()
 if a.mode=='exact':z=exact(a.Q,a.n,a.dps);fname=f'exact_det_Q{a.Q}_n{a.n}.json';print(z,flush=True)
 else:z=resume(a.Q,a.T,a.phi,a.nodes,a.dps);fname=f'resum_det_Q{a.Q}_T{a.T}_phi{a.phi}_nodes{a.nodes}.json'
 z['seconds']=time.time()-t;(RESULTS/fname).write_text(json.dumps(z,indent=2))
