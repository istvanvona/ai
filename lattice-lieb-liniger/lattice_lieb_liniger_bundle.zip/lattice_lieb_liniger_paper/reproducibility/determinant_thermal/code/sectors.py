"""Formal lateral sectors: integer keys denote HALF powers of v."""
import mpmath as mp, json, argparse, time
from series import inv, power, mul as pmul
KMAX=160

def trim(a):return {k:c for k,c in a.items() if c and k<=KMAX}
def add(a,b,s=1):
 r=a.copy()
 for k,c in b.items():
  if k<=KMAX:r[k]=r.get(k,0)+s*c
 return trim(r)
def scale(a,s):return trim({k:c*s for k,c in a.items()})
def mul(a,b):
 r={}
 for k,c in a.items():
  for l,d in b.items():
   if k+l<=KMAX:r[k+l]=r.get(k+l,0)+c*d
 return trim(r)
def inverse(a):
 k=min(a);n=(KMAX+k)//2+3
 if any((i-k)%2 for i in a):raise ValueError('inverse requires one parity')
 c=inv([a.get(k+2*i,mp.mpf(0)) for i in range(n)],n)
 return trim({-k+2*i:x for i,x in enumerate(c)})
def dot(a):
 r={}
 for parity in [0,1]:
  ks=[k for k in a if k%2==parity]
  if not ks:continue
  sm=0
  for k in range(min(ks),KMAX+1,2):
   if sm:r[k]=sm
   sm-=k*a.get(k,0)
 return trim(r)
def ode(h,lam):
 if not h:return {}
 r={}
 for parity in [0,1]:
  ks=[k for k in h if k%2==parity]
  if not ks:continue
  sm=0
  for k in range(min(ks),KMAX+1,2):
   c=(h.get(k,0)+sm)/lam
   if c:r[k]=c
   sm+=k*c
 return trim(r)
def aalpha(f,alpha,N):
 a=[mp.mpf(1)];cum=mp.mpf(0);cumd=mp.mpf(0)
 for n in range(1,N+1):
  dn=-2*cum;cumd+=n*dn
  conv=sum(f.get(2*j,0)*a[n+1-j] for j in range(2,n+2))
  an=(-2*cumd-4*alpha*cum-conv)/(4*alpha*n)
  a.append(an);cum+=n*an
 return trim({2*i:c for i,c in enumerate(a)})
def run(seed,nmax,N,dps,out):
 global KMAX;KMAX=2*N+8;mp.mp.dps=dps;t0=time.time()
 rows=[l.split() for l in open(seed) if not l.startswith('#')]
 D0={2*int(r[0]):mp.mpf(r[1]) for r in rows};A00={2*int(r[0]):mp.mpf(r[2]) for r in rows}
 da=dot(A00);lo=min(da);sqrtc=power([da.get(lo+2*i,mp.mpf(0)) for i in range(N+6)],mp.mpf('.5'),N+6)
 a0=trim({lo//2+2*i:x for i,x in enumerate(sqrtc)});ia0=inverse(a0);f=mul(dot(dot(a0)),ia0)
 I0=scale(D0,mp.pi);Iprime=dot(I0);ar={};X={};Ir={};Nr={}
 for r in range(1,nmax+1):
  ar[r]=aalpha(f,-2*r,N+3);X[r]=ode(mul(a0,ar[r]),-2*r)
  Ir[r]=ode(mul(mul(ar[r],ia0),Iprime),-2*r)
  for s in range(1,r+1):Nr[r,s]=Nr[s,r]=ode(mul(ar[r],ar[s]),-2*(r+s))
 print('basis',time.time()-t0,flush=True)
 SS={r:2j*mp.power(mp.mpf(r)/mp.e,2*r)/(mp.factorial(r-1)*mp.factorial(r)) for r in ar}
 C={r:mp.power(mp.mpf(r)/mp.e,r)/(mp.factorial(r-1)*mp.sqrt(2*mp.pi*r)) for r in ar}
 W={(r,n):{} for r in ar for n in range(nmax+1)}
 for n in range(1,nmax+1):
  for r in ar:
   if n>=2*r:
    z=X[r].copy() if n==2*r else {}
    for s in ar:z=add(z,mul(W[s,n-2*r],Nr[s,r]))
    W[r,n]=scale(z,SS[r])
 D=[D0]+[{} for _ in range(nmax)];chi=[a0]+[{} for _ in range(nmax)]
 for n in range(1,nmax+1):
  for r in ar:
   D[n]=add(D[n],mul(W[r,n],Ir[r]),1/mp.pi);chi[n]=add(chi[n],mul(W[r,n],ar[r]))
   if n>=r:
    z=X[r].copy() if n==r else {}
    for s in ar:z=add(z,mul(W[s,n-r],Nr[s,r]))
    D[n]=add(D[n],z,4j*C[r])
 print('D,chi',time.time()-t0,flush=True)
 U=[];rho=[]
 for n in range(nmax+1):
  dd=add(dot(D[n]),D[n],-2*n)
  for k in range(1,n+1):dd=add(dd,mul(chi[k],U[n-k]),-1)
  U.append(mul(dd,ia0));rhs={}
  for k in range(n+1):rhs=add(rhs,mul(U[k],U[n-k]),mp.pi/2)
  if n:rho.append(ode(rhs,-2*n))
  else:
   integrand=mul(rhs,{-4:-mp.mpf('.5'),-2:mp.mpf('.5')})
   r0={0:(mp.euler-mp.log(mp.pi))/mp.pi}
   print('rho log coeff',integrand.get(-2,0),flush=True)
   for k,c in integrand.items():
    if k!=-2:r0[k+2]=c/(mp.mpf(k)/2+1)
   rho.append(trim(r0))
  print('rho sector',n,time.time()-t0,flush=True)
 # Truncate guards before output.
 obj={'N':N,'nmax':nmax,'dps':dps,'rho_log':mp.nstr(-1/mp.pi,dps),'convention':'upper lateral Lambda=exp(-2*pi*Q), 2*pi*Q=1/v+log(v/(8e))'}
 for name,arr in [('D',D),('rho',rho),('chi',chi)]:
  obj[name]=[{str(k):[mp.nstr(mp.re(c),dps),mp.nstr(mp.im(c),dps)] for k,c in z.items() if k<=2*N} for z in arr]
 open(out,'w').write(json.dumps(obj))
 print('done',time.time()-t0,flush=True)
 print('rho0:',[(k,mp.nstr(c,40)) for k,c in sorted(rho[0].items())[:7]],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('seed');p.add_argument('out');p.add_argument('-N',type=int,default=60);p.add_argument('--nmax',type=int,default=6);p.add_argument('--dps',type=int,default=100);a=p.parse_args();run(a.seed,a.nmax,a.N,a.dps,a.out)
