from pathlib import Path
import numpy as np, scipy.linalg as la
from scipy.special import roots_legendre
import mpmath as mp
import json,time

def solve(Q,n=200):
    x,w=roots_legendre(n);x=(x+1)*Q/2;w=w*Q/2;sw=np.sqrt(w)
    Km=1/(np.pi*(1+(x[:,None]-x[None,:])**2))
    Kp=1/(np.pi*(1+(x[:,None]+x[None,:])**2))
    mats=[sw[:,None]*(Km+s*Kp)*sw[None,:] for s in [1,-1]]
    fs=[];ld=[];RR=[]
    for s,mat in zip([1,-1],mats):
        A=np.eye(n)-mat;cf=la.cho_factor(A)
        ld.append(2*np.log(np.diag(cf[0])).sum())
        k=1/(np.pi*(1+(Q-x)**2))+s/(np.pi*(1+(Q+x)**2))
        src=sw*k;y=la.cho_solve(cf,src)
        RR.append((1+s/(1+4*Q*Q))/np.pi+src@y)
        if s==1:
            f=la.cho_solve(cf,sw);chi=1+src@f
        fs.append(la.eigh(mat,subset_by_index=[n-1,n-1],eigvals_only=True)[0])
    return dict(Q=Q,n=n,logdet=sum(ld),logdet_even=ld[0],logdet_odd=ld[1],chi=chi,parity_ratio=np.exp(ld[1]-ld[0]),r=(RR[0]+RR[1])/2,s=(RR[0]-RR[1])/2,gap_even=1-fs[0],gap_odd=1-fs[1])

if __name__=='__main__':
    out=[]
    for Q in [.5,.9,1.,2.,4.,8.,16.,32.,64.,128.]:
        d=solve(Q,max(100,int(Q*7)))
        print(d,flush=True);out.append(d)
    json.dump(out,open(Path(__file__).resolve().parents[1]/'results/exact_nystrom.json','w'),indent=2)
    mp.mp.dps=50
    def g(t):return 1/(2*mp.pi*t*t)-mp.coth(mp.pi*t)/(2*t)
    C=mp.quad(lambda t:t*g(t)**2,[mp.mpf('1e-10'),.1,1])+mp.quad(lambda t:t*g(t)**2-1/(4*t),[1,10,mp.inf])
    beta=C-mp.euler/4+2*mp.log(mp.barnesg(mp.mpf('1.5')))+mp.log(2)/4
    print('Creg',C,'beta candidate',beta,flush=True)
