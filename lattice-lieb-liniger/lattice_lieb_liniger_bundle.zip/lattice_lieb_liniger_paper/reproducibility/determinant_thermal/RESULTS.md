# Numerical results

All results below were calculated in the current extension, rather than copied from earlier endpoint-sector comparisons. The determinant is a different observable from the previously studied D and rho(0).

## 1. Independent determinant at Q=0.9

Parity-decomposed Gauss–Legendre Nyström calculation with 80 nodes per parity and 75 output digits:

```
log det(I-K) = -0.708694420174360089470064218064777771741733335797538530899872574594386962832
chi          =  1.58610507906984552944710556167318389060976354641546881330052859188777607746
```

The 65-node/65-digit and 80-node/75-digit log determinants agree through the 65-digit output precision. The parity-ratio identity `chi=F_-/F_+` has numerical residual `7.09e-79` in the larger calculation. This is convergence evidence, not a rigorous interval error bound.

## 2. Nonperturbative determinant sectors

The coefficient generator uses constant-source input blocks only, retaining 180 perturbative orders and sectors Lambda^0 through Lambda^8. The main upper-lateral Borel–Padé calculation uses 154 tail coefficients, ray angle 0.45 radians, 512 generalized Laguerre nodes and 170-digit arithmetic.

Let `remainder = exact logdet - Re(sum of previous sectors)`.

| Lambda power | Remainder before sector | Real lateral sector | Ratio |
|---:|---:|---:|---:|
| 4 | 7.2411376479123764e-13 | 7.2410533513437003e-13 | 1.00001164147874 |
| 6 | 8.4296568676126422e-18 | 8.4295666137760655e-18 | 1.00001070681812 |
| 8 | 9.0253836576740878e-23 | 9.0234138894509161e-23 | 1.00021829523142 |

Odd sectors vanish in this formal basis. The Lambda^2 sector has purely imaginary perturbative coefficients but a nonzero real lateral sum; it is included in all cumulative comparisons above. Omitting it fails the test.

After Lambda^8, the main run has real residual `1.9697682e-26` and cumulative imaginary part `-4.0389885e-26`. The perturbative sector alone has imaginary part `8.3660806e-8`.

Stability variations:

| Tail terms | Angle | Nodes | Lambda^8 remainder/prediction | Final real residual |
|---:|---:|---:|---:|---:|
| 150 | 0.55 | 512 | 1.00032371224 | 2.92099e-26 |
| 154 | 0.45 | 512 | 1.00021829523 | 1.96977e-26 |
| 158 | 0.40 | 512 | 1.00016828348 | 1.51849e-26 |

Thus Lambda^8 (`exp(-16*pi*Q)`) is resolved for the determinant in this tested ensemble at a few parts in ten thousand. This does not resolve the eighth sectors of the original D and rho observables, nor prove a uniform resummation error bound. The earlier 90-term/320-node trial is also retained; its substantially larger error shows why order/quadrature checks matter.

## 3. Largest kernel eigenvalue

An FFT Toeplitz Galerkin method uses exact cell-integrated Lorentzian matrix entries, evaluated by a convergent local series. Two cell widths, 0.1 and 0.05, allow a second-order Richardson estimate. The largest calculation has 327,680 cells. Eigensolver residuals are of order 1e-14 or smaller, but discretization and cancellation in `1-mu` must still be accounted for.

| Q | Extrapolated Q(1-mu_0) |
|---:|---:|
| 32 | 1.10628568648 |
| 128 | 1.14259267085 |
| 512 | 1.15345177439 |
| 2048 | 1.15656630144 |
| 8192 | 1.15744061942 |
| Limiting half-Laplacian eigenvalue | 1.157773883697... |

These computations support the independently derived limit. They do not measure exponentially small eigenvalue sectors.

## 4. Thermodynamics at Q=0.9, kappa=1

Direct zero-temperature Fredholm solution:

```
mu        = -1.2999150573992906
v_s       =  0.6138856180302584
K_Luttinger = 2.515729321851161
Omega_4   = -0.6292090698625181
```

The sound velocity agrees with `-partial_Q log(-mu)` to about 1e-10 using a simple centered finite difference. The finite-temperature code solves the nonlinear Yang–Yang equation independently. A cancellation-reduced implementation solves for `epsilon(T)-epsilon(0)` and computes `Omega(T)-Omega(0)` directly.

Define `C4(T)=[Omega(T)-Omega0+pi*T^2/(6*v_s)]/T^4`.

| T | C4(T), 80-point composite rule |
|---:|---:|
| 0.01000 | -0.62971106824 |
| 0.00500 | -0.62933435272 |
| 0.00250 | -0.62924040225 |
| 0.00125 | -0.62921705415 |
| Analytic T^4 coefficient | -0.62920906986 |

The deviations decrease approximately as T^2, as expected from a T^6 correction to Omega. Results for 60-point and 80-point rules and for Q=2 are in `thermo_subtracted.json`. At Q=2 the independent analytic value is `Omega_4=-1.6064948412846778`.

The nonlinear iteration residual is below 1e-19 in the subtraction formulation. That number is not the complete discretization error. The T^4 test concerns a low-temperature coefficient, not its separately resolved weak-coupling nonperturbative sectors.

## 5. Checks and provenance

`code/run_checks.py` checks coefficient parity, analytic low-order normalizations, exact determinant quadrature convergence, the stored Lambda^8 stability ensemble, a fresh parity identity, a fresh nonlinear thermal calculation, and the sound-velocity derivative relation.

`code/low_order_symbolic.py` verifies displayed determinant and thermodynamic coefficients using exact symbolic arithmetic. It does not use numerical integer-relation fitting.

No numerical values of the Fredholm determinant or thermal free energy were used to fit the transseries coefficients or the Sommerfeld T^4 expression.
