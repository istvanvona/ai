# Derivations and scope of the new results

## 1. Exact determinant identity

Let `K_Q(x,y)=1/[pi(1+(x-y)^2)]` on `[-Q,Q]`. Define
\[
 f=(1-K_Q)^{-1}1,\quad \chi(Q)=f(Q),\quad
 \mathscr R=K_Q(1-K_Q)^{-1},\quad
 G(Q)=\log\det(1-K_Q).
\]
In this section primes denote total Q derivatives. Put
\(r=\mathscr R(Q,Q)\), \(s=\mathscr R(Q,-Q)\).

Domain variation gives
\[
 \partial_Q\mathscr R(x,y)=\mathscr R(x,Q)\mathscr R(Q,y)
 +\mathscr R(x,-Q)\mathscr R(-Q,y),
\]
while translation invariance of the original convolution kernel gives
\[
 (\partial_x+\partial_y)\mathscr R(x,y)
 =\mathscr R(x,-Q)\mathscr R(-Q,y)
 -\mathscr R(x,Q)\mathscr R(Q,y).
\]
Consequently
\[
 r'=2s^2,\quad \chi'=2s\chi,\quad G'=-2r,
 \qquad \boxed{G''=-(\chi'/\chi)^2}.
\]
The domain-variation identity for f and the spatial derivative obtained by integration by parts give the middle equation. These identities hold for every finite positive Q, not only asymptotically.

The initial values are `G(0)=0`, `G'(0)=-2/pi`, `chi(0)=1`. Hence
\[
 G(Q)=-2Q/\pi-\int_0^Q (Q-u)[\partial_u\log\chi(u)]^2du.
\]
There is no undetermined exact integration constant.

On `[0,Q]`, let F+ and F- be determinants of the even/odd kernels `K(x-y)+/-K(x+y)`. Then
\[
 F=F_+F_-,\qquad \chi=F_-/F_+,
\]
because `(log F+)'=-(r+s)` and `(log F-)'=-(r-s)`.

## 2. Full formal determinant transseries

Use `b=pi Q`, `Lambda=exp(-2b)` and `partial_b=-2v^2/(1-v) partial_v`. The determinant curvature identity has the same form with b derivatives.

The Bajnok constant-source boundary amplitude is
\[
 \chi=a_0+X^T P(1-NP)^{-1}a,
 \quad P_{rs}=\delta_{rs}S_{2r}\Lambda^{2r},
 \quad S_{2r}=\frac{2i(r/e)^{2r}}{(r-1)!r!}.
\]
Thus chi, and therefore G, have only even powers of Lambda in this formal convention. Let
\[
 p=\partial_b\log\chi=\sum_{n\ge0}\Lambda^n p_n,
 \quad G=\sum_{n\ge0}\Lambda^n G_n.
\]
At n>0,
\[
 (\partial_b-2n)^2G_n=-\sum_{k=0}^n p_kp_{n-k}.
\]
Two triangular first-order inversions determine G_n, excluding growing homogeneous solutions. For `F=v^mu sum f_j v^j` and `F'+lambda F=H`,
\[
 f_j=\lambda^{-1}\left(h_j+2\sum_{k<j}(\mu+k)f_k\right).
\]
There is no new endpoint packet. Exponentiating G gives the determinant itself.

Exact symbolic checks yield
\[
G_2=-\frac{i}{e^2}\left(\frac v2+\frac{5v^2}8+\frac{61v^3}{64}+\cdots\right),
\]
\[
G_4=\frac1{e^4}\left[\frac14+(\frac18-i)v+(\frac7{32}-\frac{13i}8)v^2
 +(\frac{169}{384}-\frac{409i}{128})v^3+\cdots\right],
\]
\[
G_6=\frac1{e^6}\left[\frac{16}9+(\frac23-\frac{13i}4)v
 +(\frac98-\frac{91i}{16})v^2+(\frac{1379}{576}-\frac{4691i}{384})v^3+\cdots\right].
\]
These are full complex lateral sectors, not their coefficientwise real parts.

## 3. Perturbative normalization and the Fisher–Hartwig constant

For the symbol `sigma(p)=1-exp(-abs(p))`, the Fourier transform of its logarithm is
\[
 g(t)=\frac1{2\pi t^2}-\frac{\coth(\pi t)}{2t}.
\]
Its regularized Szego integral evaluates to
\[
 C_E=\lim_{L\to\infty}\left[\int_0^L t g(t)^2dt-\frac14\log L\right]
 =\frac{\gamma_E}4-\frac16+\frac14\log(2\pi)+3\zeta'(-1).
\]
One way to evaluate the finite part is the Mellin identity, initially for `-2<Re z<0`,
\[
\int_0^\infty u^{z-1}(\coth u-1/u)^2du
=2^{2-z}\Gamma(z-1)(z-3)\zeta(z-1).
\]
The finite part at z=0 is `gamma_E-2/3+log 2+12 zeta'(-1)`.

In the single-root Wiener–Hopf/Fisher–Hartwig normalization, including interval length 2Q,
\[
 \beta_{\rm FH}=C_E-\gamma_E/4+2\log G_B(3/2)+\log2/4
\]
\[
 =-\frac16+\frac14\log(4\pi)+3\zeta'(-1)+2\log G_B(3/2)
 =-\frac16+\frac7{12}\log2+\frac34\log\pi+6\zeta'(-1).
\]
Here G_B is Barnes' G function, not the logarithm of the determinant. Numerically
`beta_FH=0.103689740844312652484104622908713175195294572718755...`.

The perturbative series is
\[
 G_0=-b/3-\tfrac14\log v+\beta_{\rm FH}-\tfrac14\log(2\pi)
 -\tfrac18v-\tfrac{11}{48}v^2+\tfrac{27\zeta(3)-109}{288}v^3+\cdots.
\]
Equivalently, with `L=log(16 pi Q)`,
\[
G_0=-\pi Q/3+\tfrac14\log Q+\beta_{\rm FH}
+\frac{2L+1}{16\pi Q}+\frac{-6L^2+6L+1}{192\pi^2Q^2}+\cdots.
\]
The constant was not fitted. Its use in the independent determinant comparison reproduces the exact numerical result to about 25 decimal places after adding the tested sectors. The full theorem-level checking of the smooth-factor approximation assumptions in the FH limit is separate from this evaluation and is not supplied here.

## 4. The leading kernel eigenvalue gap

Let mu_0 be the largest eigenvalue of normalized K_Q and `delta_0=1-mu_0`. Rescale x=Qy and set h=1/Q. The operator is unitarily equivalent to
\[
 T_h=P_{(-1,1)}e^{-h|D|}P_{(-1,1)}.
\]
This is a compression of the full-line semigroup, not the killed-process semigroup at finite h. For a function extended by zero,
\[
 \langle f,(I-T_h)f/h\rangle
 =\frac1{2\pi}\int\frac{1-e^{-h|p|}}h|\widehat f(p)|^2dp
 \uparrow\frac1{2\pi}\int|p||\widehat f(p)|^2dp.
\]
The limiting form is that of the restricted half-Laplacian on (-1,1), with zero exterior condition.

For completeness, low-energy sequences are compact in L2: a uniform form bound gives Fourier-tail mass at frequencies above R bounded by `C/[(1-exp(-hR))/h]`, which tends to C/R as h tends to zero. Together with fixed spatial support this gives compactness. Fatou's lemma gives the lower variational bound, while testing on fixed limiting eigenfunctions gives the upper bound. The min-max principle then yields, for every fixed j,
\[
 Q(1-\mu_j(Q))\longrightarrow\lambda_{j+1}.
\]
The published first eigenvalue is `lambda_1=1.157773883697...`, hence
\[
 \delta_0\sim\lambda_1/Q.
\]
For Sant'Ana's unnormalized operator `mathcal K=2 pi K`,
\[
 \Delta_0=2\pi\delta_0\sim7.27450785508\ldots/Q.
\]
An elementary independent bound is
\[
 1-\frac2\pi\arctan Q\le\delta_0(Q)\le\frac{3\pi}{8Q}.
\]
The lower bound is Schur's row-sum bound. The upper bound uses `(1-e^{-h|D|})/h <= |D|` and the test function `sqrt(1-y^2)`; its half-Laplacian is 1 on the interval, and its Rayleigh quotient is 3pi/8.

Thus neither `1/(Q log Q)` nor an unbounded `log Q/Q` leading law is possible. The March version's single-mode explanation of the central logarithm is invalid: every fixed low mode contributes O(1), whereas an increasing number of modes produces the logarithm.

The Galerkin results also suggest subleading logarithms at order Q^-2, but their complete analytic expansion and exponentially small corrections are not established here.

For individual-eigenvalue transseries one needs `F(z,Q)=det(1-zK_Q)`. Its first zero is z=1/mu_0. The same exact boundary identities hold, with `chi_z=(1-zK_Q)^-1 1`, but the relevant regime is `z=1+u/Q`:
\[
 Q(I-zK_Q)\longrightarrow |D|_{(-1,1)}-u.
\]
A fixed-z=1 determinant transseries does not supply a uniform solution of that spectral problem.

## 5. Thermodynamics and low-energy excitations

Set kappa=1 and bare energy `e0(x)=-2/(1+x^2)`. At zero temperature,
\[
 \epsilon(x)=-2\pi\widetilde\rho(x)-\mu f(x),\qquad \epsilon(Q)=0.
\]
Let eta=rho(Q), chi=f(Q). With Q derivatives,
\[
 D'=2\chi\eta,\quad R'=2\eta^2,\quad
 \mu=-2\pi\eta/\chi=-\pi D'/\chi^2,
\]
\[
 v_s=\epsilon_x(Q)/(2\pi\eta)=-\partial_Q\log(-\mu),\quad
 K_{\rm Lutt}=\chi^2,\quad \partial D/\partial\mu=\chi^2/(\pi v_s).
\]
The identity `partial_Q epsilon=-mu' f` follows because the moving-endpoint source vanishes when epsilon(Q)=0. It gives `epsilon_x(Q)=mu' chi`.

The weak-coupling perturbative expansions begin
\[
\mu_0=-4\pi v\left[1+2v+(\tfrac92-\tfrac{\pi^2}6)v^2
 +(\tfrac{43}4-\tfrac{5\pi^2}3-\tfrac{21\zeta(3)}4)v^3+\cdots\right],
\]
\[
v_{s,0}=2\pi v\left[1+3v+(8-\tfrac{\pi^2}3)v^2
 +(\tfrac{85}4-\tfrac{13\pi^2}3-\tfrac{63\zeta(3)}4)v^3+\cdots\right].
\]
All Lambda sectors follow by formal differentiation and division of existing D and chi sectors. This establishes a low-energy extension, not the entire excitation dispersion.

At fixed chemical potential and fixed finite Q, the Yang–Yang equation is
\[
\epsilon_T(x)=e_0(x)-\mu-T\int_{\mathbb R}K(x-y)\log(1+e^{-\epsilon_T(y)/T})dy,
\]
\[
\Omega=-T\int_{\mathbb R}K(x)\log(1+e^{-\epsilon_T(x)/T})dx.
\]
The low-T expansion is
\[
\Omega=\Omega_0-\frac{\pi T^2}{6v_s}+\Omega_4T^4+\cdots.
\]
Therefore the complete weak-coupling transseries of the T^2 coefficient, and of the linear specific heat coefficient, follows immediately. This does not assume the T expansion is uniform as Q tends to infinity.

## 6. Explicit T^4 coefficient

Let `u=epsilon_0'(Q)>0`, `c1=pi^2/6`, `c2=7pi^4/360`, and near the positive Fermi edge use the energy coordinate z=epsilon_0(x), so `partial_z=(1/epsilon_0')partial_x`. Then
\[
 (1-K_Q)\epsilon_2(x)=-\frac{c_1}{u}[K(x-Q)+K(x+Q)],
\]
\[
 \epsilon_2(x)=-\frac{c_1}{u}[\mathscr R(x,Q)+\mathscr R(x,-Q)].
\]
A distributional Sommerfeld expansion gives
\[
\boxed{\Omega_4=-2\left[
\frac{\rho\epsilon_2^2}{2\epsilon_0'}
-c_1\partial_z\left(\frac{\rho\epsilon_2}{\epsilon_0'}\right)
+c_2\partial_z^2\left(\frac{\rho}{\epsilon_0'}\right)
\right]_{x=Q}.}
\]
Here rho and epsilon are smoothly continued through the endpoint by their integral equations. The epsilon_4 term cancels by self-adjointness of the resolvent. This is a grand-canonical T^4 coefficient; the fixed-density T^4 coefficient needs an additional Legendre-transform correction.

No new endpoint seed is needed for this coefficient. To express its jets in Q derivatives of D, chi, and G, set
\[
 r=-G'/2,\quad s=\chi'/(2\chi),\quad A=r+s,\quad
 A_x=s'/2+(s^2-r^2)/2-rs.
\]
For either g=rho or g=f, with boundary value gamma=eta or chi,
\[
 g_x=\gamma'-\gamma A,\qquad
 g_{xx}=\gamma''-\gamma'A-\gamma(A'+A_x).
\]
Then
\[
 \epsilon_x=\mu'\chi,
 \quad\epsilon_{xx}=(\mu'\chi)'+\mu'f_x,
 \quad\epsilon_{xxx}=(\epsilon_{xx})'+\mu'f_{xx},
\]
\[
 \epsilon_2(Q)=-c_1A/u,\qquad \epsilon_{2,x}(Q)=-c_1A_x/u.
\]
Thus the formal weak-coupling sectors of Omega_4 are also obtained by algebra and derivatives. We tested the T^4 formula directly, rather than numerically resolving its individual exponentially small sectors.

At higher even orders, Sommerfeld expansion recursively generates linear equations with the same Fredholm resolvent and sources determined by lower thermal orders. Those higher orders were not implemented in this bundle.

## 7. What is still unproved

The new exact identities are not a proof of the global endpoint Borel completion. That proof still needs controlled spectral-contour deformations, analytic continuation and growth bounds for the Borel transforms, and control of the infinite sector sum. Formal ODE consistency and numerical ambiguity cancellation alone do not provide it.

There is a direct finite-Q validation criterion. For a candidate full profile f_app and residual `r_app=(I-K_Q)f_app-g`,
\[
 \|f_{\rm app}-f\|_\infty
 \le\frac{\|r_{\rm app}\|_\infty}{1-(2/\pi)\arctan Q}.
\]
This follows from a Neumann-series norm bound. It would turn a uniformly certified profile residual into a rigorous error bar. The current Padé scalar comparisons do not supply such a uniform interval-certified residual.

Finally, the kernel gap is not a many-body mass gap. The conjectured attractive dual requires a specified Hamiltonian, reference state, Bethe strings and continuation prescription. No physical dual-gap identification is proved here; a simple sign flip of the real-root Fredholm equation is insufficient.

## Sources

* F. T. Sant'Ana, arXiv:2603.09522v2, especially Sections 8–9 and Appendix A. https://arxiv.org/html/2603.09522v2
* Z. Bajnok et al., arXiv:2504.05932, constant-source ODEs and resurgent paths. https://arxiv.org/pdf/2504.05932
* E. Basor and H. Widom, Wiener–Hopf determinants with Fisher–Hartwig symbols, arXiv:math/0205198. https://arxiv.org/abs/math/0205198
* K. K. Kozlowski, Truncated Wiener–Hopf operators with Fisher–Hartwig singularities, arXiv:0805.3902. https://arxiv.org/abs/0805.3902
* T. Kulczycki, M. Kwasnicki, J. Malecki, A. Stos, Spectral properties of the Cauchy process, arXiv:0906.3113; Proc. London Math. Soc. 101 (2010) 589–622. https://arxiv.org/abs/0906.3113
* R. Zhong, Y.-Y. Chen, K. Hao, W.-L. Yang, V. Korepin, Thermodynamics of the Heisenberg XXX chain with negative spin, JHEP08(2026)101, arXiv:2602.03714. https://arxiv.org/html/2602.03714v2

The published 2026 thermodynamics article cites Sant'Ana as reference 55, correcting the earlier conversation's negative citation-search claim. Its finite-temperature results are prior literature, not discoveries of this bundle. The present extensions are the transseries propagation and the explicit computations above.
