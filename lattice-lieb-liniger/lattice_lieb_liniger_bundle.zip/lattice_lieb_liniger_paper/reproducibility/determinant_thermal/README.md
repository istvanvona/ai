# Lattice Lieb–Liniger: determinant, operator gap, and low-temperature extensions

Research calculations, 12 November 2026.

## Scope

This bundle extends the earlier lattice endpoint-transseries archive. It contains:

* an exact reduction of the Fredholm determinant to the ordinary Love boundary value;
* 180-order formal log-determinant sectors through Lambda^8 and fresh lateral Borel–Padé comparisons;
* an FFT Toeplitz/Galerkin calculation of the largest-eigenvalue gap up to Q=8192;
* exact zero-temperature thermodynamic identities and a derived Sommerfeld T^4 coefficient;
* independent finite-temperature Yang–Yang comparisons;
* exact symbolic verification of displayed low-order coefficients.

The exact determinant identities and limiting-gap argument do not depend on the proposed new endpoint seed. The determinant coefficient calculation uses only constant-source blocks from the earlier Bajnok/O(3) construction. The input is shared with the endpoint module at `../endpoint/data/basis200_r8.json`; the generator resolves this path from its script location. Its original production code remains in the endpoint module. No TBA output was fitted to obtain the determinant sectors or the T^4 formula.

A proof that the complete infinite lateral/median transseries reconstructs the endpoint observables for all Q is **not** supplied. No instanton correction to an individual kernel eigenvalue or attractive-dual mass gap has been computed. Error estimates from Padé variation are empirical, not interval-certified.

## Conventions

`K(x-y)=1/[pi(1+(x-y)^2)]` on `[-Q,Q]`, `(1-K)f=1`, `chi=f(Q)`.

`b=pi Q`, `2b=1/v+log(v/(8e))`, `Lambda=exp(-2b)`.

`G=log det(1-K)`. Its formal odd powers of Lambda vanish. A complex formal sector must not be discarded before lateral summation.

For thermodynamics the bare energy is `-2/(1+x^2)` (kappa=1), the chemical potential is fixed in a low-temperature expansion, and `energy=2-2*pi*rho(0)`.

## Installation and quick checks

```bash
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python code/run_checks.py
python code/low_order_symbolic.py
```

## Reproduce the main computations

```bash
# The input basis has 200-order coefficients; retain guards.
python code/determinant_series.py --N 180

# Independent determinant, with two different quadrature sizes.
OPENBLAS_NUM_THREADS=1 python code/determinant_numeric.py exact --Q .9 --n 65 --dps 65
OPENBLAS_NUM_THREADS=1 python code/determinant_numeric.py exact --Q .9 --n 80 --dps 75

# Upper-lateral summation and two stability variations.
python code/determinant_numeric.py resum --Q .9 --T 154 --phi .45 --nodes 512 --dps 170
python code/determinant_numeric.py resum --Q .9 --T 150 --phi .55 --nodes 512 --dps 170
python code/determinant_numeric.py resum --Q .9 --T 158 --phi .4 --nodes 512 --dps 170

# Large-Q kernel eigenvalue calculation, two cell sizes.
OPENBLAS_NUM_THREADS=1 python code/gap_fft.py

# Direct and cancellation-reduced finite-temperature calculations.
OPENBLAS_NUM_THREADS=1 python code/thermodynamics.py
OPENBLAS_NUM_THREADS=1 python code/thermal_validation.py
```

Scripts use paths relative to their locations, not the original sandbox. Keep the sibling `endpoint/` directory beside this module so that the shared basis can be found. Generated outputs are written under `data/` and `results/`. Cached quadrature nodes are supplied. The determinant-series generator is configured for sectors 0–8 because of the retained basis file; the formal recursion in `DERIVATIONS.md` has no such fixed cutoff.

## Reading order

1. `DERIVATIONS.md`: proofs, conventions, explicit formulas, and remaining analytical gaps.
2. `RESULTS.md`: fresh numerical tests and their limitations.
3. `results/determinant_comparison.csv` and `results/gap_extrapolation.csv`: machine-readable comparison tables.
4. `results/thermo_subtracted.json`: finite-temperature validation with reduced cancellation.

The determinant asymptotic normalization uses the single-root Wiener–Hopf/Fisher–Hartwig constant. Its evaluation is analytic, not a fitted TBA constant. A fully self-contained theorem justifying all regularization and smooth-factor approximation hypotheses is not included; the constant and subsequent sectors are independently tested numerically.

The paper-specific corrections refer to the accessible March 22, 2026 version of arXiv:2603.09522. A September revision is indexed online but its complete text could not be obtained in this run. The September version may have changed those claims.
