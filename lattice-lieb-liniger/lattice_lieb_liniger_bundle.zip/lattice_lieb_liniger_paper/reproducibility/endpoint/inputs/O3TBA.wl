(* Recursion for Chebyshev x Kernel integrals *)

F0[x_, \[Lambda]_] = (ArcTan[(1 - x)/\[Lambda]] + ArcTan[(1 + x)/\[Lambda]])/\[Pi];
F1[x_, \[Lambda]_] = (-2 x ArcTan[(-1 + x)/\[Lambda]] + 2 x ArcTan[(1 + x)/\[Lambda]] + \[Lambda] (Log[(-1 + x)^2 + \[Lambda]^2] - Log[(1 + x)^2 + \[Lambda]^2]))/(2 \[Pi]);
G0[x_, \[Lambda]_] = (-2 x ArcTan[(-1 + x)/\[Lambda]] + 2 x ArcTan[(1 + x)/\[Lambda]] + \[Lambda] (Log[(-1 + x)^2 + \[Lambda]^2] - Log[(1 + x)^2 + \[Lambda]^2]))/\[Pi];
G1[x_, \[Lambda]_] = (2 ((-x^2 + \[Lambda]^2) ArcTan[(-1 + x)/\[Lambda]] + (x^2 - \[Lambda]^2) ArcTan[(1 + x)/\[Lambda]] + \[Lambda] (2 + x Log[(-1 + x)^2 + \[Lambda]^2] - x Log[(1 + x)^2 + \[Lambda]^2])))/\[Pi];


recursion[x_, \[Lambda]_, M_] := Module[{F, G, sqr},
  F = ConstantArray[0, {2 M + 1, Length[x]}];
  G = ConstantArray[0, {2 M + 1, Length[x]}];
  F[[0 + 1]] = F0[x, \[Lambda]];
  F[[1 + 1]] = F1[x, \[Lambda]];
  G[[0 + 1]] = G0[x, \[Lambda]];
  G[[1 + 1]] = G1[x, \[Lambda]];
  sqr = 4 (x^2 + \[Lambda]^2);
  F[[2 + 1]] = G[[1 + 1]] - F[[0 + 1]];
  G[[2 + 1]] = 4 x G[[1 + 1]] - G[[0 + 1]] - sqr F[[1 + 1]];
  Table[
   F[[j + 1]] = G[[j - 1 + 1]] - F[[j - 2 + 1]];
   G[[j + 1]] = -((4 \[Lambda])/\[Pi]) (1 - (-1)^j)/(j (j - 2)) + 
     4 x G[[j - 1 + 1]] - G[[j - 2 + 1]] - sqr F[[j - 1 + 1]];
   , {j, 3, 2 M}];
  Transpose[F[[;; ;; 2]]]]


(* Recursion for energy coefficients *)

ClearAll[s, c]
s[0, 0] = 2;
s[1, 0] = 8;
s[1, 1] = 2;
c[1, 0] = -8;
c[k_, l_] /; l < 0 := 0
s[k_, l_] /; l < 0 := 0
s[k_, l_] /; l == k := s[k, l] = -s[k - 2, k - 2] + 2 s[k - 1, k - 1]
c[k_, l_] /; l == k - 1 := 
 c[k, l] = -c[k - 2, k - 3] + 2 c[k - 1, k - 2] - 8 s[k - 1, k - 1]
s[k_, l_] /; l < k := 
 s[k, l] = 
  16 (l - k) c[k - 1, l - 1] + 8 (2 k - 2 l - 1) (k - l) s[k - 1, l] -
    s[k - 2, l - 2] + 2 s[k - 1, l - 1]
c[k_, l_] /; l < k - 1 := 
 c[k, l] = 
  8 (2 (k - l) - 1) (k - 1 - l) c[k - 1, l] - c[k - 2, l - 2] + 
   2 c[k - 1, l - 1] - 8 (2 (k - l) - 1) s[k - 1, l]

FE[k_, alphapowers_, coshalpha_, sinhcalpha_] := (((c[k, #] &) /@ Range[0, k - 1]).alphapowers[[;; k]] coshalpha + ((s[k, #] &) /@ Range[0, k]).alphapowers[[;; k + 1]] sinhcalpha)/(alphapowers[[k + 1]] )
FENR[k_, j_, PREC_] := ((2 j)!) (Sum[N[c[k, j + k - n]/((2 n)!), PREC], {n, j + 1, j + k}] + Sum[N[s[k, j + k - n]/((2 n + 1)!), PREC], {n, j, j + k}])


calculate[B_, M_, PREC_] := Module[{xs, Jmx, source0, source1, rhovec, powers, coshalpha, sinhcalpha, evec, Fmx, s0, s1, chi0, chi1, cap00, rho01, rho10, eps11, NRmoments, i,j,k,l},

 xs = N[Table[Cos[(i \[Pi])/(2 M)], {i, 0, M}], PREC];
 Jmx = N[Table[Cos[(i j \[Pi])/M], {i, 0, M}, {j, 0, M}], PREC];

 source0 = Table[1, {k, 0, M}];
 source1 = Cosh[B xs];
 rhovec = Table[2/(1 - 4 j^2), {j, 0, M}];

 powers = N[B^(2 Range[0,M]), PREC]; 
 coshalpha = N[Cosh[B], PREC];
 sinhcalpha = N[Sinh[B]/B, PREC];
 evec = Table[ FE[j, powers, coshalpha, sinhcalpha] , {j, 0, M}];

 lambda = \[Pi]/B;
 
 Fmx = recursion[xs, lambda, M];
 s0 = LinearSolve[Jmx - Fmx, source0 ];
 s1 = LinearSolve[Jmx - Fmx, source1 ];

 chi0 = Plus @@ s0;
 chi1 = Plus @@ s1; 
 
 cap00 = B/(2 \[Pi]) rhovec . s0;
 rho01 = B/(2 \[Pi]) evec . s0;
 rho10 = B/(2 \[Pi]) rhovec . s1;
 eps11 = B/(2 \[Pi]) evec . s1;

 NRmoments = Table[(B)^(2 l + 1)/(2 \[Pi]) ((FENR[#,l,PREC]&) /@ Range[0,M] ).s0 , {l, 0, 4}];

 {B, lambda, M, chi0, chi1, cap00, rho01, rho10, eps11, NRmoments, rho01-rho10,  s0[[-1]]/s0[[1]], s1[[-1]]/s1[[1]], s0, s1}]


$MaxExtraPrecision = Infinity;

PREC = 200;

Bs = Range[1, 20, 1];
Ms = Table[100 , {i,Length[Bs]}];
PRECs = Table[Round[PREC + 31/20 M] ,{M, Ms}]; 

data = ParallelTable[ calculate[N[Bs[[i]],PRECs[[i]]], Ms[[i]], PRECs[[i]]], {i, Length[Bs]}]
Save["O3tbadata.wl", data]


