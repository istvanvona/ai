# Lattice Lieb–Liniger endpoint trans-series

Fresh research implementation, 12 November 2026.

The package contains a formal all-sector construction for the lattice observables
D(Q), rho(0;Q), and E(Q)=2*pi*rho(0;Q)-2, together with a high-order implementation
and independent Chebyshev integral-equation tests. Read `DERIVATION.md` before
changing conventions. `results/NUMERICAL_RESULTS.md` distinguishes numerically
resolved sectors from coefficients that have only been generated formally.

## What is supplied

- The KdV/tau-flow seed through order 210; scalar series through v^208.
- Integer and half-integer coefficient lattices through v^200, NP levels 0–12.
- A compact matrix formula for both D and rho; no unknown endpoint seed remains
  in the formal construction.
- Two independent coefficient constructions and an algebraic density check.
- Lateral Borel–Leroy–Padé summation, primitive-block factorization, and the
  decaying Green-function treatment of the first endpoint function.
- A fresh arbitrary-precision finite-interval Chebyshev solver.
- Raw parameter scans, failed conformal-method trials, and a numerical report.

This is **not** an interval-certified error analysis or a theorem of global Borel
summability. No TBA values were fitted to seed coefficients or NP amplitudes.
The new endpoint seed is explained as a formal Wiener–Hopf/KdV extension in the
notes. The supplied A00 coefficients were independently checked against the
user's nenr data; a separate 208-order direct-Volin endpoint data set was not used.

## Requirements

Python 3.10 or later, with `mpmath`, `numpy`, `scipy`, and `sympy`.
For regeneration of the high-order flow: a C++17 compiler and Boost headers.
The numerical work was run with Python 3.13. The code uses no network access.

The public archive excludes `inputs/nenr_336.txt` and `inputs/o3.pdf`. The complete `run_checks.py` runner requires a private copy of `nenr_336.txt` for its independent coefficient comparison; without it, use the public-input checks below. Historical results record checks performed with the private inputs present.

```
python -m pip install -r requirements.txt
cd code
python run_checks.py
```

Run the commands below **from the `code` directory**. The numerical scripts use
`../data` as a writable cache for Padé coefficients and quadrature nodes.

## Reproduce the principal tests from the supplied seed

The high-order coefficient files are already present, so rerunning the C++
calculation is optional.

Checks using included inputs:

```
python check_o3_table.py
python low_order_exact.py
python check_algebraic_density.py -N 120 --dps 160
```

The independent raw-coefficient comparison requires the separately held private file:

```
python verify_nenr.py --seed ../data/seeds210.tsv \
  --nenr /path/to/private/nenr_336.txt --dps 220 \
  --out ../results/nenr_recheck.txt
```

Regenerate all formal levels through 12:

```
python sectors_compact.py ../data/seeds210.tsv ../data/sectors200_n12.json \
  -N 200 --nmax 12 --dps 210
```

Generate independent TBA values:

```
python tba.py --Q .75 .9 1 --M 65 --dps 75 \
  --out ../results/tba_recheck.json
```

Direct sector-by-sector lateral summation:

```
python batch_borel.py ../data/sectors200_n12.json --T 190 \
  --Q .75,.9,1 --phi .4,.55 --nodes 512 --dps 200 \
  --leroy 1.5 --nmax 8 --out ../results/direct_rho_recheck.json
```

The more accurate factorized method:

```
python export_basis.py ../data/seeds210.tsv ../data/sectors200_n12.json \
  ../data/basis200_r8.json -N 200 --rmax 8 --dps 210
python green_resum.py ../data/sectors200_n12.json --Q .9 -T 190 \
  --phi .50 --inner 384 --outer 32 --dps 200 --evaldps 90 \
  --out ../results/G190_recheck.json
python factorized_resum.py ../data/basis200_r8.json --Q .9 \
  --T0 198 --TI 190 --TF 130 --phi .4 --nodes 512 --dps 200 \
  --green ../results/G190_recheck.json \
  --out ../results/factorized_recheck.json
```

The Green file is specific to Q. Its first-sector result is converted to I_1 by
`factorized_resum.py`; using a file with the wrong Q raises an error.

## Regenerate the scalar seed

```
python prepare_flow.py -N 210 --dps 240 --out ../data/flow_input210.txt
c++ -O3 -std=c++17 -DDIGITS=270 kdv_flow.cpp -o kdv_flow
./kdv_flow ../data/flow_input210.txt ../data/flow210.tsv
python extract_seeds.py ../data/flow210.tsv ../data/seeds210.tsv --dps 230
```

The measured C++ flow stage took 736.5 seconds in the present runtime, with
roughly 1.3 GB observed memory use near completion. This is not a controlled
benchmark against the original Volin code at the same precision.

The production code keeps an auxiliary flow parameter and never expands large
polynomials in separate zeta monomials. It **does** evaluate the tau constants
numerically before the high-order run. It is not a fully symbolic 210th-order
zeta-polynomial generator. The formal algorithm permits deferred substitution;
the supplied exact low-order check uses symbolic rational arithmetic.

## File formats

`seeds210.tsv`: integer power, coefficient of D0, coefficient of A00. Negative
powers are included. `A00` is not the lattice number density.

`sectors200_n12.json`: `D`, `rho`, and `H` are arrays indexed by NP order n. Each
series is a dictionary: key k denotes v^(k/2), and the value is `[real, imag]` as
decimal strings. The explicit rho0 logarithm is stored separately as `rho_log`.
To obtain E, multiply every rho coefficient by 2*pi, subtract 2 from the n=0
constant, and multiply `rho_log` by 2*pi.

All coefficients use the upper-lateral convention, Lambda=exp(-2*pi*Q), and
2*pi*Q=1/v+log(v/(8*e)). Transposes in the matrix formulas are NOT Hermitian
adjoints. Do not discard imaginary coefficient series before resumming.

`basis200_r8.json` contains X_r=A_(0,-2r), I_r, a_r, and the needed symmetric
N_rs=A_(-2r,-2s) blocks. Its `Npair` dictionary maps a pair to an entry of `blocks`.

The Padé cache validates the coefficient input with SHA-256. Cache files can be
removed without losing any generated seed or sector data.

## Numerical status

The final-order/order-angle tests resolve the seventh exponential sector for
both D and rho at Q=0.9. The eighth is comparable to the remaining resummation
systematic. Levels 9–12 are supplied as formal predictions, not independently
resolved TBA remainders. The energy comparison is inherited from its exact
linear relation to rho and is not a third independent check.

See `results/comparison.csv`, `results/stability.csv`, and the raw JSON records.
The first 256-node/angle-0.22 tests illustrate a quadrature error floor. Plain
conformal Taylor and the tested conformal Padés were not used to claim improved
precision. The high-order input precision was also varied in one Padé test.

## Provenance

The original user-supplied materials were `inputs/o3.pdf`, `inputs/O3TBA.wl`, and
`inputs/nenr_336.txt`. Only `inputs/O3TBA.wl` is included in this public archive;
the unpublished note and raw coefficient file remain private. All code in `code/` and the displayed computation results were newly
created in this calculation. No expired earlier code was required.
