import argparse,mpmath as mp, pathlib
from series import *
p=argparse.ArgumentParser();p.add_argument('-N',type=int,default=20);p.add_argument('--dps',type=int,default=100);p.add_argument('--out',required=True);a=p.parse_args();mp.mp.dps=a.dps
N=a.N;n=N+1
U=scale(mul([0,0,1,0,1],binomial(-3,n),n),-1)
Q=binomial(mp.mpf('.25'),n);Hcl=binomial(-mp.mpf('.75'),n)
# sqrt(z*cot(z)) = E(y), y=k^2; z=pi*k/2.
sin=[(-1)**k*(mp.pi/2)**(2*k)/mp.factorial(2*k+1) for k in range(n)]
cos=[(-1)**k*(mp.pi/2)**(2*k)/mp.factorial(2*k) for k in range(n)]
E=power(mul(cos,inv(sin,n),n),mp.mpf('.5'),n)
H=[mp.mpf(0)]*n;Lh=Hcl
for k in range(N//2+1):
 H=add(H,scale(Lh,E[k]),n)
 Lh=add(dx(dx(Lh,mp.mpf('.5'),n),mp.mpf('.5'),n),scale(mul(U,Lh,n),-1),n)
tau=[mp.mpf(0)]+[-mp.mpf(4**j-1)*mp.zeta(2*j+1)/((2*j+1)*16**j) for j in range(1,N//2+2)]
d=scale(binomial(-mp.mpf('.5'),n),-2)
with open(a.out,'w') as f:
 f.write(str(N)+'\n')
 for v in [U,Q,H,d,tau]:f.write(' '.join(mp.nstr(x,a.dps) for x in v)+'\n')
print('Prepared N=',N,flush=True)
