#include <boost/multiprecision/cpp_bin_float.hpp>
#include <vector>
#include <fstream>
#include <iostream>
#include <chrono>
#ifndef DIGITS
#define DIGITS 120
#endif
using R=boost::multiprecision::number<boost::multiprecision::cpp_bin_float<DIGITS>>;
using P=std::vector<R>;using S=std::vector<P>;
int N,J;
void add(P& a,const P& b,R c=1){if(c==0)return;if(a.size()<b.size())a.resize(b.size());for(size_t i=0;i<b.size();++i)a[i]+=c*b[i];}
P prod(const P&a,const P&b,R c=1){if(a.empty()||b.empty()||c==0)return{};P r(a.size()+b.size()-1);for(size_t i=0;i<a.size();++i)if(a[i]!=0)for(size_t j=0;j<b.size();++j)if(b[j]!=0)r[i+j]+=c*a[i]*b[j];return r;}
P conv(const S&a,const S&b,int n){P r;for(int k=0;k<=n;++k)add(r,prod(a[k],b[n-k]));return r;}
P integ(P a,R init){P r(a.size()+1);r[0]=init;for(size_t k=0;k<a.size();++k)r[k+1]=a[k]/R(k+1);return r;}
P der(const S&a,int n,R mu,const P&d){P r;for(int k=0;k<n;++k)add(r,a[k],d[n-k-1]*(R(k)+mu));return r;}
R eval(const P&a){R r=0;for(auto &x:a)r+=x;return r;}
int main(int argc,char**argv){if(argc!=3){std::cerr<<"input output\n";return 1;}std::ifstream in(argv[1]);in>>N;J=N/2+1;P u0(N+1),q0(N+1),h0(N+1),d(N+1),tau(J+1);for(P *p:{&u0,&q0,&h0,&d,&tau})for(auto&x:*p)in>>x;
 S U(N+1),Q(N+1),H(N+1),DQ(N+1);std::vector<S>G(J+2,S(N+1)),DG=G,DDG=G,HK(J+1,S(N+1)),DH=HK,DDH=HK,RK=HK,DRK=HK;
 G[0][0]={R(-.5)};for(int k=1;k<=J;++k)RK[k][0]={-tau[k]*pow(R(4),k)/2};
 auto t=std::chrono::steady_clock::now();
 for(int n=0;n<=N;++n){
  for(int j=1;j<=J+1;++j){DG[j][n]=der(G[j],n,0,d);DDG[j][n]=der(DG[j],n,0,d);}
  DQ[n]=der(Q,n,R(-.5),d);
  for(int k=0;k<=J;++k){DH[k][n]=der(HK[k],n,R(.5),d);DDH[k][n]=der(DH[k],n,R(.5),d);DRK[k][n]=der(RK[k],n,0,d);}
  P du,dq,dh;for(int j=1;j<=J;++j)add(du,DG[j+1][n],-tau[j]);
  add(dq,conv(RK[0],DQ,n),2);add(dq,conv(DRK[0],Q,n),-1);
  for(int k=0;k<=J;++k){add(dh,conv(RK[k],DH[k],n),2);add(dh,conv(DRK[k],HK[k],n),-1);}
  U[n]=integ(du,u0[n]);Q[n]=integ(dq,q0[n]);H[n]=integ(dh,h0[n]);HK[0][n]=H[n];G[1][n]=U[n];
  for(int j=1;2*(j+1)<=n;++j){G[j+1][n]=DDG[j][n];for(int k=2;k<=n-2*j;++k)add(G[j+1][n],prod(U[k],G[j][n-k]),-4+R(2*k)/n);}
  for(int k=0;k<=J;++k)for(int i=1;i+k<=J&&2*i<=n;++i)add(RK[k][n],G[i][n],pow(R(4),k)*tau[k+i]);
  for(int k=1;2*k<=n;++k){HK[k][n]=DDH[k-1][n];add(HK[k][n],conv(U,HK[k-1],n),-1);}
  if(n%10==0)std::cerr<<n<<" "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count()<<" s\n";
 }
 std::ofstream out(argv[2]);out.precision(DIGITS-10);out<<"# n U Q H (flow time T=1)\n";for(int n=0;n<=N;++n)out<<n<<" "<<eval(U[n])<<" "<<eval(Q[n])<<" "<<eval(H[n])<<"\n";
}
