import argparse,mpmath as mp
from read_nenr import read_nenr
from series import *
p=argparse.ArgumentParser();p.add_argument('--seed',default='../data/seeds210.tsv');p.add_argument('--nenr',default='../inputs/nenr_336.txt');p.add_argument('--dps',type=int,default=100);p.add_argument('--out',default='../results/nenr_check.txt');a=p.parse_args();mp.mp.dps=a.dps
seed={int(z[0]):mp.mpf(z[2]) for l in open(a.seed) if not l.startswith('#') and (z:=l.split())};n=max(seed)+3
r=read_nenr(a.nenr)[:n];e=[r[k][1]*2**k for k in range(n)];rho=[r[k][2]*2**k for k in range(n)]
x=[rho[0]]+[rho[k]-2*(k-1)*rho[k-1] for k in range(1,n)]
y=[e[0]]+[e[k]-k*e[k-1] for k in range(1,n)]
f=mul(mul(x,x,n),inv(y,n),n)
A={k-2:-f[k]/(8*(k-2)) for k in range(n) if k!=2};A[0]=-mp.mpf(1)/16
lines=['# A00 compared with raw nenr gamma=v (before B2coupling gamma->beta).']
for k in sorted(seed):
 err=abs(seed[k]-A[k])/(1+abs(A[k]));lines.append(f'{k} {mp.nstr(A[k],50)} relerr {mp.nstr(err,8)}')
open(a.out,'w').write('\n'.join(lines)+'\n');print('\n'.join(lines[:12]));print('max error:',mp.nstr(max(abs(seed[k]-A[k])/(1+abs(A[k])) for k in seed),10))
