"""Resum primitive blocks first; assemble all NP sectors algebraically.

A supplied Green-function evaluation replaces I_1, the most poorly
conditioned direct Padé. Products are formed AFTER lateral summation.
"""
import mpmath as mp,json,argparse,time
from batch_borel import cache_get,evaluate
from borel import nodes

def run(path,Q,T0,TI,TF,phi,nnodes,dps,greenfile,out):
 mp.mp.dps=dps;dat=json.load(open(path));Q=mp.mpf(Q);b=mp.pi*Q;v=-1/mp.lambertw(-mp.exp(-2*b)/(8*mp.e),-1);Lam=mp.exp(-2*b);phi=mp.mpf(phi);R=dat['rmax'];t=time.time()
 nd={l:nodes(nnodes,mp.mpf(l)-1,100) for l in ['1','1.5','2.5']}
 def val(name,n,T,lr):
  pp=cache_get(dat,name,n,T,mp.mpf(lr),dps);return evaluate(pp,v,phi,nd[lr],mp.mpf(lr))
 d0=val('D',0,T0,'2.5');rho0=val('rho',0,T0,'1.5')+mp.mpf(dat['rho_log'])*mp.log(v)
 ss={r:2j*(mp.mpf(r)/mp.e)**(2*r)/(mp.factorial(r-1)*mp.factorial(r)) for r in range(1,R+1)}
 cs={r:4j*mp.pi*(mp.mpf(r)/mp.e)**r/(mp.factorial(r-1)*mp.sqrt(2*mp.pi*r)) for r in range(1,R+1)}
 X={r:val('X',r,TF,'1') for r in range(1,R+1)};I={}
 for r in range(1,R+1):
  if r==1 and greenfile:
   g=json.load(open(greenfile))
   if abs(mp.mpf(g['Q'])-Q)>mp.mpf('1e-30'):raise ValueError('Green file has wrong Q')
   I[r]=mp.mpc(g['sector_re'],g['sector_im'])/(Lam*4j*(mp.mpf(1)/mp.e)/mp.sqrt(2*mp.pi))
  else:I[r]=val('I',r,TI,'1.5')
  print('I',r,'time',round(time.time()-t,2),flush=True)
 NN={}
 for key,idx in dat['Npair'].items():
  r,s=map(int,key.split(','));NN[r,s]=NN[s,r]=val('blocks',idx,TF,'1')
 print('blocks done',time.time()-t,flush=True)
 Z={(r,n):mp.mpc(0) for r in range(1,R+1) for n in range(R+1)};dr=[d0];rr=[rho0]
 for n in range(1,R+1):
  for r in range(1,n+1):
   z=cs[r] if n==r else mp.mpc(0)
   if n==2*r:z+=ss[r]*I[r]
   if n>=2*r:
    for s in range(1,n-2*r+1):z+=ss[r]*NN[r,s]*Z[s,n-2*r]
   Z[r,n]=z
  dr.append(mp.fsum(X[r]*Z[r,n] for r in range(1,n+1))/mp.pi)
  z=mp.fsum(I[r]*Z[r,n] for r in range(1,n+1))+cs[n]*I[n]
  for r in range(1,n):
   for s in range(1,n-r+1):z+=cs[r]*NN[r,s]*Z[s,n-r]
  rr.append(z/(2*mp.pi))
 result={'Q':str(Q),'T0':T0,'TI':TI,'TF':TF,'phi':str(phi),'nnode':nnodes,'dps':dps,'green':greenfile,'elapsed':time.time()-t}
 for name,arr in [('D',dr),('rho',rr)]:
  cum=mp.mpc(0);ls=[]
  for n,z in enumerate(arr):
   z*=Lam**n;cum+=z;ls.append({'n':n,'sector_re':mp.nstr(z.real,60),'sector_im':mp.nstr(z.imag,60),'sum_re':mp.nstr(cum.real,60),'sum_im':mp.nstr(cum.imag,60)})
  result[name]=ls;print(name,'sum',mp.nstr(cum,50),flush=True)
 result['building_blocks']={'I':{str(r):[mp.nstr(I[r].real,60),mp.nstr(I[r].imag,60)] for r in I}}
 json.dump(result,open(out,'w'),indent=2);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--Q',default='.9');p.add_argument('--T0',type=int,default=198);p.add_argument('--TI',type=int,default=190);p.add_argument('--TF',type=int,default=130);p.add_argument('--phi',default='.4');p.add_argument('--nodes',type=int,default=512);p.add_argument('--dps',type=int,default=200);p.add_argument('--green',default=None);p.add_argument('--out',required=True);a=p.parse_args()
 run(a.path,a.Q,a.T0,a.TI,a.TF,a.phi,a.nodes,a.dps,a.green,a.out)
