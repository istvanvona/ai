"""Resum an NP density sector via its decaying Green function, not its Padé.

rho_n(b)=-(2n)^(-1) int_0^inf exp(-y) J_n(b+y/(2n))dy,
J_n=(2*pi)^(-1) sum H_k H_(n-k). This removes the growing homogeneous
solution and avoids approximating the negative-action singularity created
by formal inversion of d/db-2n.
"""
import mpmath as mp,json,argparse,time
from batch_borel import cache_get,evaluate
from borel import nodes

def run(path,Q,n,T,phi,inner,outer,dps,evaldps,leroy,out):
 if n<1:raise ValueError('Green formula is for n>=1')
 mp.mp.dps=dps;dat=json.load(open(path));Q=mp.mpf(Q);b0=mp.pi*Q;Lam=mp.exp(-2*b0);phi=mp.mpf(phi);leroy=mp.mpf(leroy);t0=time.time()
 pre=[cache_get(dat,'H',k,T,leroy,dps) for k in range(n+1)]
 nd=nodes(inner,leroy-1,100);ou=nodes(outer,0,100);mp.mp.dps=evaldps;terms=[]
 for index,(y,wt) in enumerate(ou):
  b=b0+y/(2*n);v=-1/mp.lambertw(-mp.exp(-2*b)/(8*mp.e),-1)
  hs=[evaluate(p,v,phi,nd,leroy) for p in pre]
  rhs=mp.fsum(hs[k]*hs[n-k] for k in range(n+1))/(2*mp.pi)
  terms.append(wt*rhs)
  if index%8==0:print('node',index,'time',round(time.time()-t0,2),flush=True)
 val=-Lam**n*mp.fsum(terms)/(2*n)
 row={'Q':str(Q),'n':n,'T':T,'phi':str(phi),'inner_nodes':inner,'outer_nodes':outer,'dps':dps,'evaldps':evaldps,'leroy':str(leroy),'sector_re':mp.nstr(val.real,65),'sector_im':mp.nstr(val.imag,65),'runtime':time.time()-t0}
 json.dump(row,open(out,'w'),indent=2);print(json.dumps(row,indent=2),flush=True);return row
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--Q',default='.9');p.add_argument('-n',type=int,default=1);p.add_argument('-T',type=int,default=190);p.add_argument('--phi',default='.5');p.add_argument('--inner',type=int,default=384);p.add_argument('--outer',type=int,default=32);p.add_argument('--dps',type=int,default=200);p.add_argument('--evaldps',type=int,default=90);p.add_argument('--leroy',default='1.5');p.add_argument('--out',required=True);a=p.parse_args()
 run(a.path,a.Q,a.n,a.T,a.phi,a.inner,a.outer,a.dps,a.evaldps,a.leroy,a.out)
