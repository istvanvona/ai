"""Cached high-precision Padé preparation, independent Q/angle/quadrature scans."""
import mpmath as mp, json, os, argparse, time, hashlib
from borel import nodes,eval_poly

def prepare(coefs,T,leroy):
 c={int(k):mp.mpc(*val) for k,val in coefs.items()};explicit=[];parts=[]
 for parity in [0,1]:
  keys=sorted(k for k,val in c.items() if k%2==parity and val)
  if not keys:continue
  k0=keys[0]
  while k0<=0:
   if c.get(k0,0):explicit.append((k0,c[k0]))
   k0+=2
  if k0>keys[-1]:continue
  if k0+2*(T-1)>max(c):raise ValueError('Insufficient coefficients for requested Padé order')
  a=[c.get(k0+2*i,0)/mp.gamma(i+leroy) for i in range(T)]
  if not any(a):continue
  nn=T//2;mm=T-1-nn;p,q=mp.pade(a,mm,nn);parts.append((k0,p,q))
 return explicit,parts

def enc(z,dps):return [mp.nstr(mp.re(z),dps),mp.nstr(mp.im(z),dps)]
def cache_get(dat,which,n,T,leroy,dps,cache='../data'):
 name=f'{cache}/pade_{which}_n{n}_T{T}_L{str(leroy)}_d{dps}.json'
 digest=hashlib.sha256(json.dumps(dat[which][n],sort_keys=True).encode()).hexdigest()
 if os.path.exists(name):
  z=json.load(open(name))
  if z.get('sha256')==digest:
   return [(k,mp.mpc(*v)) for k,v in z['explicit']],[(k,[mp.mpc(*v) for v in p],[mp.mpc(*v) for v in q]) for k,p,q in z['parts']]
 ex,parts=prepare(dat[which][n],T,leroy)
 json.dump({'sha256':digest,'explicit':[(k,enc(v,dps)) for k,v in ex],'parts':[(k,[enc(v,dps) for v in p],[enc(v,dps) for v in q]) for k,p,q in parts]},open(name,'w'))
 return ex,parts

def evaluate(prepared,v,phi,nd,leroy):
 ex,parts=prepared;ei=mp.exp(1j*phi);fac=mp.exp(1j*leroy*phi)
 total=sum(c*v**(mp.mpf(k)/2) for k,c in ex)
 for k,p,q in parts:
  z=mp.fsum(weight*mp.exp(-(ei-1)*x)*eval_poly(p,v*ei*x)/eval_poly(q,v*ei*x) for x,weight in nd)
  total+=v**(mp.mpf(k)/2)*fac*z
 return total

def run(path,Ts,Qs,phis,nnodes,dps,leroy,which,nmax,out):
 mp.mp.dps=dps;dat=json.load(open(path));leroy=mp.mpf(leroy);t0=time.time();results=[]
 for T in Ts:
  pre=[]
  for n in range(nmax+1):
   pre.append(cache_get(dat,which,n,T,leroy,dps));print('prepared',which,T,n,'seconds',round(time.time()-t0,2),flush=True)
  for nnode in nnodes:
   nd=nodes(nnode,leroy-1,dps=min(dps,100))
   for Qstr in Qs:
    Q=mp.mpf(Qstr);v=-1/mp.lambertw(-mp.exp(-2*mp.pi*Q)/(8*mp.e),-1);Lam=mp.exp(-2*mp.pi*Q)
    for phis0 in phis:
     phi=mp.mpf(phis0);cum=mp.mpc(0);rr=[]
     for n in range(nmax+1):
      val=evaluate(pre[n],v,phi,nd,leroy)*Lam**n
      if n==0 and which=='rho':val+=mp.mpf(dat['rho_log'])*mp.log(v)
      cum+=val;rr.append({'n':n,'sector_re':mp.nstr(val.real,55),'sector_im':mp.nstr(val.imag,55),'sum_re':mp.nstr(cum.real,55),'sum_im':mp.nstr(cum.imag,55)})
     row={'Q':str(Q),'v':mp.nstr(v,50),'T':T,'phi':str(phi),'nnode':nnode,'dps':dps,'leroy':str(leroy),'which':which,'data':rr};results.append(row)
     json.dump({'runs':results,'elapsed':time.time()-t0},open(out,'w'),indent=2)
     print('evaluated',which,T,str(Q),str(phi),nnode,'sum',mp.nstr(cum,35),'seconds',round(time.time()-t0,2),flush=True)
 return results
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--T',default='190');p.add_argument('--Q',default='.9');p.add_argument('--phi',default='.22');p.add_argument('--nodes',default='256');p.add_argument('--dps',type=int,default=200);p.add_argument('--leroy',default='1.5');p.add_argument('--which',default='rho');p.add_argument('--nmax',type=int,default=8);p.add_argument('--out',required=True);a=p.parse_args()
 run(a.path,[int(t) for t in a.T.split(',')],a.Q.split(','),a.phi.split(','),[int(n) for n in a.nodes.split(',')],a.dps,a.leroy,a.which,a.nmax,a.out)
