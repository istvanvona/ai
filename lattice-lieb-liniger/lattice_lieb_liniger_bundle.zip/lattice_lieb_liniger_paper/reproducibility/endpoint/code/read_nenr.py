import re,mpmath as mp

def read_nenr(path):
 txt=open(path).read().replace('\\\n','')
 txt=re.sub(r'`[0-9.]*','',txt).replace('*^','e')
 triples=re.findall(r'\{\s*(\d+)\s*,\s*([^,{}]+),\s*([^,{}]+)\}',txt)
 return [(int(n),mp.mpf(e.strip()),mp.mpf(r.strip())) for n,e,r in triples]
if __name__=='__main__':
 mp.mp.dps=60
 for r in read_nenr('/mnt/data/nenr_336.txt')[:6]:print(r[0],mp.nstr(r[1],30),mp.nstr(r[2],30))
