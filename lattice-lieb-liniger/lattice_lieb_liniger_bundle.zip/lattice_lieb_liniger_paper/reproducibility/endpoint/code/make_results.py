"""Generate a human-readable numerical report and machine-readable tables."""
import pathlib,json,csv,mpmath as mp
mp.mp.dps=90
root=pathlib.Path(__file__).resolve().parents[1];p=root/'results'
refs={mp.mpf(x['Q']):x for x in json.load(open(p/'tba65_extended.json'))}
ref=refs[mp.mpf('.9')]
A=json.load(open(p/'factorized198.json'));B=json.load(open(p/'factorized_alt198.json'))
rows=[];lines=['# Fresh numerical validation','',
'All target values are from the independent finite-interval Chebyshev solver. No TBA data are fitted to coefficients or sector amplitudes. The energy E=2*pi*rho-2 is not an independent validation.', '',
'## Primary point: Q=0.9','',f"D_TBA = `{ref['D']}`",'',f"rho_TBA = `{ref['rho']}`",'',
'Primary resummation: 198 terms for perturbative seeds; 190 for endpoint blocks; 130 for fixed-source blocks; 512 generalized Laguerre nodes; angle 0.40. The first endpoint is evaluated by a separate decaying Green-function integral.', '',
'Remainder before sector n includes all sectors n,n+1,...; its ratio to the n-th sector need not be exactly one.', '']
for name in ['D','rho']:
 lines += ['## '+name,'','| n | Exact remainder before n | Predicted sector n | Remainder / prediction |','|---:|---:|---:|---:|']
 exact=mp.mpf(ref[name]);arr=A[name]
 for n in range(1,9):
  rem=exact-mp.mpf(arr[n-1]['sum_re']);piece=mp.mpf(arr[n]['sector_re']);ratio=rem/piece
  if n>=3:lines.append(f'| {n} | {mp.nstr(rem,12)} | {mp.nstr(piece,12)} | {mp.nstr(ratio,12)} |')
  for label,z in [('factorized_primary',A),('factorized_alternative',B)]:
   ar=z[name];r=exact-mp.mpf(ar[n-1]['sum_re']);pc=mp.mpf(ar[n]['sector_re'])
   rows.append({'method':label,'Q':'0.9','observable':name,'sector':n,'exact':str(exact),'remainder_before':str(r),'predicted_sector':str(pc),'ratio':str(r/pc),'sum_after':ar[n]['sum_re'],'real_error_after':str(mp.mpf(ar[n]['sum_re'])-exact),'imag_after':ar[n]['sum_im']})
 err=mp.mpf(arr[-1]['sum_re'])-exact
 lines+=['',f"Sum through sector 8: `{arr[-1]['sum_re']}`.",f'Real error: `{mp.nstr(err,18)}`; remaining imaginary part: `{arr[-1]["sum_im"]}`.','']
# Re-use the primitive-block contributions, varying only the perturbative Padé.
ens=[]
for name,file in [('rho','rho0_last_orders.json'),('D','D0_last_orders.json')]:
 rr=json.load(open(p/file))['runs']
 for z in [A,B]:
  rr.append({'T':198,'phi':z['phi'],'Q':z['Q'],'data':[z[name][0]]})
 exact=mp.mpf(ref[name]);norm=abs(mp.mpf(A[name][7]['sector_re']))
 for run in rr:
  if mp.mpf(run['Q'])!=mp.mpf('.9'):continue
  base=A if mp.mpf(run['phi'])==mp.mpf('.4') else B
  core=mp.mpc(base[name][-1]['sum_re'],base[name][-1]['sum_im'])-mp.mpc(base[name][0]['sum_re'],base[name][0]['sum_im'])
  total=core+mp.mpc(run['data'][0]['sum_re'],run['data'][0]['sum_im']);err=total.real-exact
  ens.append({'observable':name,'T0':run['T'],'phi':run['phi'],'real_error':str(err),'imaginary_part':str(total.imag),'error_over_sector7':str(err/norm)})
 es=[mp.mpf(e['error_over_sector7']) for e in ens if e['observable']==name]
 lines += [f'Final-order ensemble for {name}: error / |sector 7| ranges from `{mp.nstr(min(es),10)}` to `{mp.nstr(max(es),10)}` for orders 194,196,197,198,199,200 and angles 0.40,0.55. These are empirical stability diagnostics, not rigorous error bars.','']
lines += ['## Interpretation','',
'The seventh exponential sector is resolved for both D and rho in the tested ensemble. The eighth is not: it is comparable to the remaining resummation systematic. Formal coefficients through sector 12 are supplied, but sectors 9–12 are not claimed to be numerically resolved.', '',
'The independent data check is for A00 through power v^208, agreeing to over 150 digits. The new D0 seed has analytic low-order checks and numerical integral-equation checks; it has not been compared coefficient-by-coefficient with an independent 208-order direct-Volin endpoint file.', '',
'Plain conformal Taylor and tested conformal Padé outputs are retained in the raw results. They did not outperform the factorized/Green-function method and are not used to claim higher-sector verification.']
(p/'NUMERICAL_RESULTS.md').write_text('\n'.join(lines)+'\n')
with open(p/'comparison.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open(p/'stability.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(ens[0]));w.writeheader();w.writerows(ens)
print('\n'.join(lines[-12:]))
