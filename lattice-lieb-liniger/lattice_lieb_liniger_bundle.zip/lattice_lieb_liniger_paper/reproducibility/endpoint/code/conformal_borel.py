"""Two-cut Borel(-Leroy) summation, with cuts (-inf,-1] and [1,inf).

Uses t=2*z/(1+z*z). Unlike the one-cut map, this excludes the negative
Borel singularities of the negative-source basis as well. Plain polynomial
and optional Padé in z are independent approximants.
"""
import mpmath as mp,json,argparse,time
from borel import nodes,eval_poly

def prep(coefs,T,leroy,pade=False):
 c={int(k):mp.mpc(*val) for k,val in coefs.items()};ex=[];parts=[]
 for par in [0,1]:
  keys=sorted(k for k,val in c.items() if k%2==par and val)
  if not keys:continue
  k0=keys[0]
  while k0<=0:
   if c.get(k0,0):ex.append((k0,c[k0]))
   k0+=2
  if k0>keys[-1]:continue
  bb=[c.get(k0+2*i,0)/mp.gamma(i+leroy) for i in range(T)]
  cc=[mp.mpc(0) for _ in range(T)];cc[0]=bb[0]
  for n in range(1,T):
   b=bb[n]*2**n;binom=mp.mpf(1)
   for j in range((T-n+1)//2):
    cc[n+2*j]+=b*binom
    binom*=-(n+j)/mp.mpf(j+1)
  if pade:p,q=mp.pade(cc,T-1-T//2,T//2)
  else:p,q=cc,[mp.mpf(1)]
  parts.append((k0,p,q))
 return ex,parts

def ev(prepared,v,phi,nd,leroy):
 ex,parts=prepared;ei=mp.exp(1j*phi);fac=mp.exp(1j*leroy*phi)
 s=sum(c*v**(mp.mpf(k)/2) for k,c in ex)
 for k,p,q in parts:
  terms=[]
  for x,weight in nd:
   z=v*ei*x;w=z/(1+mp.sqrt(1-z*z))
   terms.append(weight*mp.exp(-(ei-1)*x)*eval_poly(p,w)/eval_poly(q,w))
  s+=v**(mp.mpf(k)/2)*fac*mp.fsum(terms)
 return s

def run(path,Ts,Qs,phis,nnodes,dps,leroy,which,nmax,pade,out):
 mp.mp.dps=dps;dat=json.load(open(path));leroy=mp.mpf(leroy);t0=time.time();results=[]
 for T in Ts:
  pre=[prep(dat[which][n],T,leroy,pade) for n in range(nmax+1)]
  print('prepared',which,T,'time',time.time()-t0,flush=True)
  for nnode in nnodes:
   nd=nodes(nnode,leroy-1,min(dps,100))
   for qs in Qs:
    Q=mp.mpf(qs);v=-1/mp.lambertw(-mp.exp(-2*mp.pi*Q)/(8*mp.e),-1);Lam=mp.exp(-2*mp.pi*Q)
    for phis0 in phis:
     phi=mp.mpf(phis0);cum=mp.mpc(0);rr=[]
     for n in range(nmax+1):
      val=ev(pre[n],v,phi,nd,leroy)*Lam**n
      if n==0 and which=='rho':val+=mp.mpf(dat['rho_log'])*mp.log(v)
      cum+=val;rr.append({'n':n,'sector_re':mp.nstr(val.real,55),'sector_im':mp.nstr(val.imag,55),'sum_re':mp.nstr(cum.real,55),'sum_im':mp.nstr(cum.imag,55)})
     row={'Q':str(Q),'v':mp.nstr(v,50),'T':T,'phi':str(phi),'nnode':nnode,'dps':dps,'leroy':str(leroy),'which':which,'conformal_pade':pade,'data':rr};results.append(row)
     json.dump({'runs':results,'elapsed':time.time()-t0},open(out,'w'),indent=2)
     print('evaluated',which,T,str(Q),str(phi),nnode,'sum',mp.nstr(cum,40),'time',time.time()-t0,flush=True)
 return results
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--T',default='190');p.add_argument('--Q',default='.9');p.add_argument('--phi',default='.4');p.add_argument('--nodes',default='384');p.add_argument('--dps',type=int,default=180);p.add_argument('--leroy',default='1.5');p.add_argument('--which',default='rho');p.add_argument('--nmax',type=int,default=8);p.add_argument('--pade',action='store_true');p.add_argument('--out',required=True);a=p.parse_args()
 run(a.path,[int(t) for t in a.T.split(',')],a.Q.split(','),a.phi.split(','),[int(n) for n in a.nodes.split(',')],a.dps,a.leroy,a.which,a.nmax,a.pade,a.out)
