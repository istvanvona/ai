"""Reproduce Table 1 of uploaded o3.pdf from the independently checked A00 seed."""
import mpmath as mp
import sectors as S
from series import *
mp.mp.dps=100;N=15;S.KMAX=2*N
r=[l.split() for l in open('../data/seeds210.tsv') if not l.startswith('#')];A={2*int(x[0]):mp.mpf(x[2]) for x in r};dotA=S.dot(A)
a0c=power([dotA.get(-2+2*j,mp.mpf(0)) for j in range(N+1)],mp.mpf('.5'),N+1);a0={-1+2*j:c for j,c in enumerate(a0c)};ia0=S.inverse(a0);f=S.mul(S.dot(S.dot(a0)),ia0)
a=[mp.mpf(1)];da=[mp.mpf(0)];c=dc=cd=dcd=mp.mpf(0)
for n in range(1,N+1):
 dn=-2*c;ddn=-2*dc;cd+=n*dn;dcd+=n*ddn
 B=-2*cd-sum(f.get(2*j,0)*a[n+1-j] for j in range(2,n+2));dB=-2*dcd-sum(f.get(2*j,0)*da[n+1-j] for j in range(2,n+2))
 an=B/(4*n)-c/n;dan=(dB-B)/(4*n)-dc/n;a.append(an);da.append(dan);c+=n*an;dc+=n*dan
asr={2*j:c for j,c in enumerate(a)};b={2*j:-c for j,c in enumerate(da)};ia=S.inverse(asr)
br=S.add({0:mp.mpf(1)},S.add(S.mul(S.dot(asr),ia),S.mul(S.dot(a0),ia0),-1),2)
wr=S.add(S.mul(S.dot(asr),b),S.mul(asr,S.dot(b)),-1);br=S.add(br,S.mul(wr,S.mul(ia,ia)),-1)
Om=S.scale(S.mul(S.mul(a0,a0),br),2)
M=log(mul(a,inv(scale(a0c,2),N+1),N+1),N+1);M[0]-=1
T=[mp.mpf(1)]+[mp.mpf(0)]*N
for _ in range(N+1):T=inv(add([1],[0]+scale(add(M,scale(log(T,N),-1),N),2),N+1),N+1)
g=[0]+scale(T,2);gc=S.trim({2*j:c for j,c in enumerate(g)});C=S.mul(gc,Om);Cv=[C.get(2*j,mp.mpf(0)) for j in range(N)]
# reversion g(v)
v=[0,mp.mpf('.5')];m=2
gp=[(j+1)*g[j+1] for j in range(N)]
while m<N:
 m=min(2*m,N);v=pad(v,m);ff=compose(g,v,m);ff[1]-=1;v=add(v,scale(mul(ff,inv(compose(gp,v,m),m),m),-1),m)
coef=compose(Cv,v,N)
z3,z5,z7=mp.zeta(3),mp.zeta(5),mp.zeta(7)
ref=[1,-mp.mpf(1)/2,-mp.mpf(1)/2,-mp.mpf(7)/8+3*z3/32,-mp.mpf(25)/12+7*z3/16,-mp.mpf(1153)/192+785*z3/512+405*z5/2048,-mp.mpf(6543)/320+2907*z3/512+3663*z5/2048-81*z3*z3/512,-mp.mpf(154403)/1920+98911*z3/4096+84357*z5/8192+70875*z7/65536-3729*z3*z3/2048,-mp.mpf(3209511)/8960+235407*z3/2048+448803*z5/8192+244863*z7/16384-104337*z3*z3/8192-81405*z3*z5/32768]
lines=[]
for j,x in enumerate(ref):lines.append(f'{j} {mp.nstr(coef[j],60)} error {mp.nstr(coef[j]-x,8)}')
open('../results/o3_table_check.txt','w').write('\n'.join(lines)+'\n');print('\n'.join(lines))

assert max(abs(coef[j] - x) for j, x in enumerate(ref)) < mp.mpf("1e-80"), "O(3) Table 1 mismatch"
