"""All upper-lateral sectors from Z=(1-P*N)^(-1)(P*I+c).

This independent implementation avoids differentiation/division of full
trans-series. It is checked against sectors.py's boundary-variation route.
Integer series keys are twice the power of v. All coefficients are mpmath.
"""
import mpmath as mp, argparse,json,time
import sectors as S
from series import power

def run(seed,nmax,N,dps,out):
 S.KMAX=2*N+8;mp.mp.dps=dps;t0=time.time()
 rows=[l.split() for l in open(seed) if not l.startswith('#')]
 D0={2*int(r[0]):mp.mpf(r[1]) for r in rows};A00={2*int(r[0]):mp.mpf(r[2]) for r in rows}
 da=S.dot(A00);lo=min(da);sq=power([da.get(lo+2*i,mp.mpf(0)) for i in range(N+6)],mp.mpf('.5'),N+6)
 q=S.trim({lo//2+2*i:c for i,c in enumerate(sq)});iq=S.inverse(q);U=S.mul(S.dot(S.dot(q)),iq)
 Ip=S.scale(S.dot(D0),mp.pi);h=S.mul(Ip,iq);ar={};X={};I={};Nr={}
 for r in range(1,nmax+1):
  ar[r]=S.aalpha(U,-2*r,N+3);X[r]=S.ode(S.mul(q,ar[r]),-2*r);I[r]=S.ode(S.mul(ar[r],h),-2*r)
  for s in range(1,r+1):Nr[r,s]=Nr[s,r]=S.ode(S.mul(ar[r],ar[s]),-2*(r+s))
 ss={r:2j*(mp.mpf(r)/mp.e)**(2*r)/(mp.factorial(r-1)*mp.factorial(r)) for r in ar}
 cs={r:4j*mp.pi*(mp.mpf(r)/mp.e)**r/(mp.factorial(r-1)*mp.sqrt(2*mp.pi*r)) for r in ar}
 Z={(r,n):{} for r in ar for n in range(nmax+1)};D=[D0]+[{} for _ in range(nmax)];H=[h]+[{} for _ in range(nmax)]
 for n in range(1,nmax+1):
  for r in range(1,n+1):
   z={0:cs[r]} if n==r else {}
   if n>=2*r:
    if n==2*r:z=S.add(z,S.scale(I[r],ss[r]))
    for s in ar:z=S.add(z,S.mul(Nr[r,s],Z[s,n-2*r]),ss[r])
   Z[r,n]=z;D[n]=S.add(D[n],S.mul(X[r],z),1/mp.pi);H[n]=S.add(H[n],S.mul(ar[r],z))
 rho=[]
 for n in range(nmax+1):
  rhs={}
  for k in range(n+1):rhs=S.add(rhs,S.mul(H[k],H[n-k]),1/(2*mp.pi))
  if n:rho.append(S.ode(rhs,-2*n))
  else:
   integrand=S.mul(rhs,{-4:-mp.mpf('.5'),-2:mp.mpf('.5')});r0={0:(mp.euler-mp.log(mp.pi))/mp.pi}
   for k,c in integrand.items():
    if k!=-2:r0[k+2]=c/(mp.mpf(k)/2+1)
   rho.append(S.trim(r0))
  print('sector',n,'elapsed',round(time.time()-t0,3),flush=True)
 obj={'N':N,'nmax':nmax,'dps':dps,'rho_log':mp.nstr(-1/mp.pi,dps),'method':'compact Z resolvent','convention':'upper lateral Lambda=exp(-2*pi*Q), 2*pi*Q=1/v+log(v/(8e))'}
 for name,arr in [('D',D),('rho',rho),('H',H)]:
  obj[name]=[{str(k):[mp.nstr(mp.re(c),dps),mp.nstr(mp.im(c),dps)] for k,c in z.items() if k<=2*N} for z in arr]
 with open(out,'w') as f:json.dump(obj,f)
 print('done',time.time()-t0,flush=True)
 return obj
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('seed');p.add_argument('out');p.add_argument('-N',type=int,default=60);p.add_argument('--nmax',type=int,default=6);p.add_argument('--dps',type=int,default=100);a=p.parse_args();run(a.seed,a.nmax,a.N,a.dps,a.out)
