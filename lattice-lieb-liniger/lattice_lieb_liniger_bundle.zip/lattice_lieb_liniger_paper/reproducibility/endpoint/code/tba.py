"""Independent finite-interval Chebyshev solver; no asymptotic coefficients used."""
import mpmath as mp,json,argparse,time

def solve(Q,M=45,dps=60):
 old=mp.mp.dps;mp.mp.dps=dps+2*M+25;Q=mp.mpf(str(Q));t0=time.time()
 nodes=[mp.cos(mp.pi*i/(2*M)) for i in range(M+1)]
 A=mp.matrix(M+1);source=mp.matrix(M+1,2);lam=1/Q
 for i,x in enumerate(nodes):
  z=mp.mpc(x,lam);I0=mp.log((z+1)/(z-1));In=[I0,z*I0-2]
  for n in range(1,2*M):
   mn=mp.mpf(0) if n%2 else mp.mpf(2)/(1-n*n)
   In.append(2*z*In[-1]-In[-2]-2*mn)
  for j in range(M+1):A[i,j]=mp.cos(mp.pi*i*j/M)+mp.im(In[2*j])/mp.pi
  source[i,0]=1;source[i,1]=1/(mp.pi*(1+(Q*x)**2))
 LU,piv=mp.mp.LU_decomp(A);sol=[]
 for k in [0,1]:
  rhs=mp.matrix([source[i,k] for i in range(M+1)])
  sol.append(mp.mp.U_solve(LU,mp.mp.L_solve(LU,rhs,piv)))
 f,r=sol;D=sum((-1)**j*f[j] for j in range(M+1))-1;rho=sum((-1)**j*r[j] for j in range(M+1));Dint=Q*sum(mp.mpf(2)/(1-4*j*j)*r[j] for j in range(M+1))
 result={'Q':str(Q),'M':M,'dps':dps,'D':mp.nstr(D,dps),'rho':mp.nstr(rho,dps),'E':mp.nstr(2*mp.pi*rho-2,dps),'chi':mp.nstr(sum(f),dps),'rho_edge':mp.nstr(sum(r),dps),'duality_error':mp.nstr(D-Dint,8),'last_coeff':mp.nstr(max(abs(f[M]),abs(r[M])),8),'runtime_s':time.time()-t0}
 mp.mp.dps=old;return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--Q',nargs='+',default=['0.75','0.9','1.0']);p.add_argument('--M',type=int,default=45);p.add_argument('--dps',type=int,default=70);p.add_argument('--out',required=True);a=p.parse_args();res=[solve(q,a.M,a.dps) for q in a.Q];open(a.out,'w').write(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
