"""Quick independent checks using the supplied seed, not a new long flow run."""
import pathlib,subprocess,sys,tempfile,json,mpmath as mp
ROOT=pathlib.Path(__file__).resolve().parents[1];CODE=ROOT/'code';mp.mp.dps=100

def call(args):
 p=subprocess.run([sys.executable]+args,cwd=CODE,check=True,capture_output=True,text=True)
 print(p.stdout.rstrip());return p

call(['low_order_exact.py'])
call(['check_o3_table.py'])
call(['verify_nenr.py','--seed',str(ROOT/'data/seeds210.tsv'),'--nenr',str(ROOT/'inputs/nenr_336.txt'),'--dps','220','--out',str(ROOT/'results/nenr_recheck.txt')])
errs=[mp.mpf(l.split('relerr ')[1]) for l in (ROOT/'results/nenr_recheck.txt').read_text().splitlines() if 'relerr ' in l]
assert max(errs)<mp.mpf('1e-145')
call(['check_algebraic_density.py','-N','35','--dps','100','--out',str(ROOT/'results/algebraic_quick_recheck.txt')])
from tba import solve
x=solve('.9',55,75);y=solve('.9',65,75)
for name in ['D','rho']:
 err=abs(mp.mpf(x[name])-mp.mpf(y[name]));assert err<mp.mpf('1e-45');print('TBA 55/65',name,'difference',mp.nstr(err,12))
ref=next(z for z in json.load(open(ROOT/'results/tba65_extended.json')) if mp.mpf(z['Q'])==mp.mpf('.9'))
assert abs(mp.mpf(y['rho'])-mp.mpf(ref['rho']))<mp.mpf('1e-60')
print('All quick checks passed. High-order resummation commands are in README.md.')
