"""Compare the closed matrix formula for rho with the endpoint ODE coefficients."""
import json,argparse,mpmath as mp
import sectors as S
p=argparse.ArgumentParser();p.add_argument('--basis',default='../data/basis200_r8.json');p.add_argument('--sectors',default='../data/sectors200_n12.json');p.add_argument('-N',type=int,default=100);p.add_argument('--dps',type=int,default=150);p.add_argument('--out',default='../results/algebraic_density_check.txt');a=p.parse_args()
mp.mp.dps=a.dps;S.KMAX=2*a.N;dat=json.load(open(a.basis));ref=json.load(open(a.sectors));R=dat['rmax']
def dec(z):return S.trim({int(k):mp.mpc(*v) for k,v in z.items()})
I={r:dec(dat['I'][r]) for r in range(1,R+1)};N={}
for key,idx in dat['Npair'].items():
 r,s=map(int,key.split(','));N[r,s]=N[s,r]=dec(dat['blocks'][idx])
ss={r:2j*(mp.mpf(r)/mp.e)**(2*r)/(mp.factorial(r-1)*mp.factorial(r)) for r in I};cs={r:4j*mp.pi*(mp.mpf(r)/mp.e)**r/(mp.factorial(r-1)*mp.sqrt(2*mp.pi*r)) for r in I}
Z={(r,n):{} for r in I for n in range(R+1)};lines=[]
for n in range(1,R+1):
 for r in range(1,n+1):
  z={0:cs[r]} if n==r else {}
  if n==2*r:z=S.add(z,I[r],ss[r])
  if n>=2*r:
   for s in range(1,n-2*r+1):z=S.add(z,S.mul(N[r,s],Z[s,n-2*r]),ss[r])
  Z[r,n]=z
 rr=S.scale(I[n],cs[n])
 for r in range(1,n+1):rr=S.add(rr,S.mul(I[r],Z[r,n]))
 for r in range(1,n):
  for s in range(1,n-r+1):rr=S.add(rr,S.mul(N[r,s],Z[s,n-r]),cs[r])
 rr=S.scale(rr,1/(2*mp.pi));old=dec(ref['rho'][n]);err=max(abs(rr.get(k,0)-old.get(k,0))/(1+abs(old.get(k,0))) for k in set(rr)|set(old))
 lines.append(f'n={n} max_relative_error={mp.nstr(err,12)}')
 assert err<mp.mpf(10)**(-a.dps+12)
open(a.out,'w').write('\n'.join(lines)+'\n');print('\n'.join(lines))
