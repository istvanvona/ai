import argparse,mpmath as mp
from series import *
p=argparse.ArgumentParser();p.add_argument('flow');p.add_argument('out');p.add_argument('--dps',type=int,default=100);a=p.parse_args();mp.mp.dps=a.dps
rows=[l.split() for l in open(a.flow) if not l.startswith('#')];N=len(rows);U,Q,H=([mp.mpf(r[c]) for r in rows] for c in (1,2,3))
t=binomial(mp.mpf('.5'),N)
qh=mul(t,mul(Q,H,N),N);qq=mul(t,mul(Q,Q,N),N)
# D(w)=1/(2pi w)-1+sum -qh[n]/(2pi(n-1))*w^(n-1)
Iw=[-mp.pi]+[-qh[n]/(2*(n-1)) for n in range(2,N)]
Aw=[mp.mpf(0)]+[-qq[n]/(8*(n-2)) for n in range(3,N)]
w=w_of_v(N+1);wv=w[1:];iwv=inv(wv,N)
I=add(scale(iwv[1:],mp.mpf('.5')),compose(Iw,w,N-1),N-1)
A=add(add(scale(mul(iwv,iwv,N)[2:],mp.mpf(1)/16),scale(iwv[1:],-mp.mpf(1)/4),N-2),compose(Aw,w,N-2),N-2)
# a0(v)=v^-1/2 Aq(v)
Aq=scale(mul(power(wv,-mp.mpf('.5'),N),compose(Q,w,N),N),mp.mpf('.5'))
with open(a.out,'w') as f:
 f.write('# integer_power D0 A00  (NaN means out of reliable range)\n')
 f.write('-2 0 '+mp.nstr(mp.mpf(1)/16,a.dps)+'\n')
 f.write('-1 '+mp.nstr(1/(2*mp.pi),a.dps)+' -0.25\n')
 for k in range(N-2):f.write(f'{k} {mp.nstr(I[k]/mp.pi,a.dps)} {mp.nstr(A[k],a.dps)}\n')
print('w(v):',[mp.nstr(x,16) for x in w[:8]])
print('D:',[mp.nstr(x/mp.pi,32) for x in I[:8]])
print('A00:',[mp.nstr(x,32) for x in A[:8]])
print('a0:',[mp.nstr(x,32) for x in Aq[:8]])
print('no-log checks:',mp.nstr(qh[1],8),mp.nstr(qq[2],8))
# direct q ODE in w
err=add(dx(dx(Q,-mp.mpf('.5'),N),-mp.mpf('.5'),N),scale(mul(U,Q,N),-1),N)
print('q ODE max relative scale:',mp.nstr(max(abs(err[i])/(1+abs(U[i])) for i in range(N)),5))
