"""Exact check: derive rho_0 from D_0 and A00, no numerical recognition."""
import sympy as s
v,p,z=s.symbols('v p z')
D=1/(2*p*v)-1+(p*p-3)*v/(12*p)+(8*p*p-9+27*z)*v*v/(24*p)
A=1/(16*v*v)-1/(4*v)-s.Rational(1,16)+(1-3*z)*v/32
rp=s.series(p*s.diff(D,v)**2/(2*s.diff(A,v)),v,0,3).removeO().expand()
ans=[s.simplify(rp.coeff(v,n-1)/n) for n in range(1,4)]
expected=[-2/p,(p*p-15)/(6*p),(117*z-159+40*p*p)/(36*p)]
assert all(s.simplify(a-b)==0 for a,b in zip(ans,expected))
for n,c in enumerate(ans,1):print('rho0 coefficient of v^',n,'=',c,'; substitute p=pi, z=zeta(3)')
