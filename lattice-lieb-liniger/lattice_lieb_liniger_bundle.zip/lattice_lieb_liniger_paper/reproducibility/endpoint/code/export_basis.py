"""Export the scalar building blocks for multiplicative/ODE resummation."""
import sectors as S
from series import power
import mpmath as mp,json,argparse,time
p=argparse.ArgumentParser();p.add_argument('seed');p.add_argument('sectors');p.add_argument('out');p.add_argument('-N',type=int,default=200);p.add_argument('--rmax',type=int,default=8);p.add_argument('--dps',type=int,default=210);a=p.parse_args()
mp.mp.dps=a.dps;S.KMAX=2*a.N+8;t=time.time();rows=[l.split() for l in open(a.seed) if not l.startswith('#')]
D={2*int(r[0]):mp.mpf(r[1]) for r in rows};A={2*int(r[0]):mp.mpf(r[2]) for r in rows};da=S.dot(A);lo=min(da)
sq=power([da.get(lo+2*i,mp.mpf(0)) for i in range(a.N+6)],mp.mpf('.5'),a.N+6);q=S.trim({lo//2+2*i:c for i,c in enumerate(sq)});iq=S.inverse(q);U=S.mul(S.dot(S.dot(q)),iq);h=S.scale(S.mul(S.dot(D),iq),mp.pi)
ars={r:S.aalpha(U,-2*r,a.N+3) for r in range(1,a.rmax+1)}
def enc(z):return {str(k):[mp.nstr(mp.re(c),a.dps),mp.nstr(mp.im(c),a.dps)] for k,c in z.items() if k<=2*a.N}
obj={'N':a.N,'rmax':a.rmax,'dps':a.dps,'X':[{}],'I':[{}],'a':[enc(q)],'Npair':{},'blocks':[]}
for r in ars:
 obj['X'].append(enc(S.ode(S.mul(q,ars[r]),-2*r)));obj['I'].append(enc(S.ode(S.mul(ars[r],h),-2*r)));obj['a'].append(enc(ars[r]))
 for s in range(r,a.rmax+1):
  if r+s>a.rmax:continue
  obj['Npair'][f'{r},{s}']=len(obj['blocks']);obj['blocks'].append(enc(S.ode(S.mul(ars[r],ars[s]),-2*(r+s))))
ref=json.load(open(a.sectors));obj['D']=[ref['D'][0]];obj['rho']=[ref['rho'][0]];obj['rho_log']=ref['rho_log'];obj['H']=[enc(h)]
json.dump(obj,open(a.out,'w'));print('basis seconds',time.time()-t,'pairs',len(obj['blocks']))
