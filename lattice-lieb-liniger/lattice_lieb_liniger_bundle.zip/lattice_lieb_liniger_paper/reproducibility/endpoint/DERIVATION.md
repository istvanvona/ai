# Lattice Lieb–Liniger endpoint trans-series: formal construction and fresh tests

Research calculation, 12 November 2026. This note distinguishes an explicit **formal trans-series construction** from an analytic theorem about its all-sector Borel sum. The latter theorem is not supplied. The numerical tests use newly generated coefficients, not the expired files from the earlier conversation.

## 1. Problem and conventions

Let
\[
 (\mathcal L_Q f)(x)=\frac1\pi\int_{-Q}^Q\frac{f(y)}{1+(x-y)^2}\,dy,
 \qquad (1-\mathcal L_Q)f_Q=1,
\]
\[
 (1-\mathcal L_Q)\widetilde\rho(x)=\frac1{\pi(1+x^2)}.
\]
The three target observables are
\[
 D(Q)=f_Q(0)-1=\int_{-Q}^Q\widetilde\rho(x)\,dx,
 \quad R(Q)=\widetilde\rho(0;Q),\quad E(Q)=2\pi R(Q)-2.
\]
These are Sant'Ana's dimensionless quantities. His dimensional energy is
\(e(\kappa,q)=-E(q/\kappa)/\kappa\). The expansion below is a large-\(Q\) expansion; at fixed physical \(q\), \(Q=q/\kappa\).

We use
\[
 b=\pi Q,\quad 2b=\frac1v+\log\frac{v}{8e},\quad
 \Lambda=e^{-2b}=\frac{8e}{v}e^{-1/v},\quad
 \partial_b=-\frac{2v^2}{1-v}\partial_v.
\]
The original physical rapidity is rescaled as \(\theta=\pi x\); Bajnok et al.'s constant-source Love function is twice \(f_Q\).

For the uploaded `o3.pdf`, the correct dictionary is
\[
 s=v,\qquad x_{\rm flow}=b+\frac32\log2.
\]
Its physical O(3) coupling \(g\) is **not** \(v\). In particular, \(g\sim2v\), and the nonlinear relation in its Eq. (16) must be retained. The supplied raw `nenr_336.txt` coefficients reproduce the present \(A_{00}(v)\) **before** the notebook's subsequent gamma-to-beta change of gauge. Applying that change and then identifying beta with this \(v\) is incorrect.

## 2. What the uploaded note supplies

Use its rational coordinate
\[
 t=\sqrt{1-2w}=\tanh u,\qquad \partial_x=-\frac{2w^2}{t}\partial_w,
 \qquad w=v+\frac12v^3+\frac34v^4+\cdots.
\]
At zero odd-zeta times,
\[
 U_*=-\frac{w^2(1+w^2)}{(1-2w)^3},\qquad
 q_*=a_{0,*}=\frac12\sqrt{t/w}.
\]
The Lenard polynomials and times are
\[
 G_0=-\frac12,\qquad
 G'_{j+1}=(\partial_x^3-4U\partial_x-2U')G_j,
\]
\[
 \tau_{2j+1}=-\frac{4^j-1}{(2j+1)16^j}\zeta(2j+1).
\]
The primitives vanish at \(w=0\). These definitions and the commuting flows are from the uploaded note, Sections 3.1–3.4.

## 3. New endpoint extension

The additional scalar required by the lattice point observable is
\[
 h=\frac{\mathcal I_0'}q,\qquad \mathcal I_0=\pi D_0.
\]
An explicit zero-time seed is
\[
 h_*={\cal E}(L_*)h_{\rm cl},\quad L_*=\partial_x^2-U_*,\quad
 h_{\rm cl}=\frac{2\sqrt w}{t^{3/2}},
\]
\[
 \boxed{\displaystyle
 {\cal E}(z)=\sqrt{\frac{\pi\sqrt z}{2}\cot\frac{\pi\sqrt z}{2}}.
 }
\]
The square root is the formal branch with value 1 at the origin. For example,
\[
 {\cal E}(L)=1-\frac{\pi^2}{24}L-\frac{\pi^4}{640}L^2+\cdots.
\]
This is a **new extension**, not an equation stated in the uploaded PDF.

Define ordered differential operators
\[
 P_j=\sum_{i=0}^j4^{j-i}(2G_i\partial_x-G_i')L^{j-i}.
\]
Then evolve
\[
 X_jU=-G'_{j+1},\qquad X_jq=(2G_j\partial_x-G_j')q,
 \qquad X_jh=P_jh,
\]
with \(X_j=\partial/\partial\tau_{2j+1}\), and evaluate the times at their zeta values. The ordering matters: the powers of \(L\) act first. For instance,
\(P_1=-4\partial_x^3+6U\partial_x+3U'\).

Finally,
\[
 A_{00}'=q^2,\qquad \mathcal I_0'=qh,\qquad R_0'=\frac{h^2}{2\pi}.
\]
The constants are fixed by
\[
 A_{00}=\frac1{16v^2}-\frac1{4v}-\frac1{16}+O(v),
 \quad \mathcal I_0=\frac1{2v}-\pi+O(v),
\]
\[
 R_0=\frac{-\log(\pi v)+\gamma_E}{\pi}+O(v).
\]
No TBA values enter these normalizations.

### Origin of the operator \({\cal E}\)

The normalized Wiener–Hopf spectral multiplier is
\[
 M(k)=\sqrt\pi\,2^{-k}\frac{\Gamma(1+k/2)}{\Gamma((1+k)/2)}.
\]
Its even and odd parts are
\[
 \sqrt{M(k)M(-k)}={\cal E}(k^2),
\]
\[
 \frac12[\log M(k)-\log M(-k)]
 =-\sum_{j\ge1}4^j\tau_{2j+1}k^{2j+1}.
\]
The latter is exactly the free spectral phase of the KdV operators \(P_j\). Thus the even-zeta multiplier belongs in the initial endpoint packet, while the odd-zeta multiplier is restored by the flows. Including either part twice would give a wrong answer.

A useful zero-time generalized Jost solution is
\[
 a_k^*=\sqrt t\left(\frac{1+t}{2}\right)^k
 e^{k e^{-2u}/2}\,{}_2F_0\left(\frac{1+k}2,\frac{1+k}2;;\frac wk\right).
\]
It solves \(a_k''+2ka_k'=U_*a_k\). Writing its hypergeometric factor through Tricomi's \(U\) turns the formal central source transform into an inverse spectral integral. On its central cut the phase is
\[
 \Phi(y)=\frac{y+1/2}{w}+\frac12\log\left|\frac{y}{1+y}\right|.
\]
The perturbative root is \(y=-1/2\), with
\(\Phi'(-1/2)=(1-2w)/w\). Its Jacobian and amplitude give
\(2\sqrt w/t^{3/2}\). The other roots approach the ends of the cut exponentially and do not belong to the power-series seed. This is a formal contour argument; it does not provide uniform analytic error bounds for the complete contour deformation.

## 4. Finite ODE recursions for all building blocks

For \(r,s\ge1\), write
\[
 a_r=a_{-2r},\quad X_r=A_{0,-2r},\quad N_{rs}=A_{-2r,-2s},
 \quad I_r=\mathcal I_{-2r}.
\]
They are determined by
\[
 a_r''-4r a_r'=Ua_r,\qquad a_r=1+O(v),
\]
\[
 X_r'-2rX_r=qa_r,
 \quad N_{rs}'-2(r+s)N_{rs}=a_ra_s,
 \quad I_r'-2rI_r=a_rh.
\]
All growing homogeneous solutions are excluded when selecting the formal power series. These are triangular coefficient recursions, not source integrations.

For \(F=v^\mu\sum f_nv^n\), the equation \(F'+\lambda F=H\) gives
\[
 f_n=\frac{h_n+2\sum_{k<n}(\mu+k)f_k}{\lambda}.
\]
The running partial sum makes this linear in the number of coefficients once the right-hand side has been formed.

## 5. Closed all-sector formula

All expressions in this section are formal in \(\Lambda\) with formal series in \(v\) as coefficients. Use the upper-lateral convention
\[
 C_r=\frac{(r/e)^r}{(r-1)!\sqrt{2\pi r}},\quad
 S_{2r}=\frac{2i}{(r-1)!r!}(r/e)^{2r}=4\pi i C_r^2.
\]
Set
\[
 P_{rs}=\delta_{rs}S_{2r}\Lambda^{2r},\qquad
 c_r=4\pi i C_r\Lambda^r,
 \qquad {\bf M}=(1-PN)^{-1}P=P(1-NP)^{-1}.
\]
Vectors \(I,X,a,c\) have the components just defined; \(N\) is symmetric. Transposes are bilinear transposes, not Hermitian adjoints. Let
\[
 J=I+Nc,\qquad Z=c+{\bf M}J=(1-PN)^{-1}(PI+c).
\]
Then the full formal endpoint construction is
\[
 \boxed{\displaystyle D^+=D_0+\frac1\pi X^T Z,}
\]
\[
 \boxed{\displaystyle
 R^+=R_0+\frac1\pi\left[I^Tc+\frac12c^TNc
                       +\frac12J^T{\bf M}J\right],}
\]
\[
 \boxed{\displaystyle E^+=2\pi R^+-2.}
\]
Expanding the inverse includes primitive poles, arbitrary internal paths, external source residues, and their mixed paths. At order \(\Lambda^n\), only finitely many labels \(r\le n\) can occur. There are no unspecified endpoint functions or additional trans-series parameters in this algorithm.

For example,
\[
 [\Lambda]R^+=4iC_1 I_1,
\]
\[
 [\Lambda^2]R^+=4iC_2 I_2-8\pi C_1^2N_{11}
                         +\frac{S_2}{2\pi}I_1^2.
\]
The second line displays why a primitive source term alone is not the complete second sector.

### Independent algebraic consistency check

Define
\[
 \chi=q+X^T{\bf M}a,\qquad H=h+a^TZ.
\]
Differentiating the matrix formulas with the ODEs above gives
\[
 D'=\frac{\chi H}{\pi},\qquad R'=\frac{H^2}{2\pi}.
\]
Therefore
\[
 R'=\frac\pi2\left(\frac{D'}\chi\right)^2,
\]
which is also an exact finite-interval endpoint-variation identity for the integral equation. The code implements both routes. The row/path and compact implementations agree through the tested range at approximately 200 working digits; the separate algebraic-density check agrees at its 160-digit working precision. These are algebraic implementation checks, not independent proofs of the asymptotic seed.

The lower-lateral convention is the conjugate one. A sector with purely imaginary formal coefficients must not be discarded before resummation: its lateral sum generally has a nonzero real part.

## 6. Low-order checks

The construction yields
\[
 D_0=\frac1{2\pi v}-1+\frac{\pi^2-3}{12\pi}v
 +\frac{8\pi^2-9+27\zeta(3)}{24\pi}v^2
 +\frac{9\pi^4+250\pi^2-145+2370\zeta(3)}{240\pi}v^3+\cdots,
\]
\[
 R_0=\frac{-\log(\pi v)+\gamma_E}{\pi}-\frac2\pi v
 +\frac{\pi^2-15}{6\pi}v^2
 +\frac{40\pi^2+117\zeta(3)-159}{36\pi}v^3+\cdots.
\]
The exact last coefficient corrects the earlier numerical conjecture. It also follows directly, without numerical recognition, from
\[
 \frac{dR_0}{dv}=\frac\pi2\frac{(dD_0/dv)^2}{dA_{00}/dv}.
\]
`low_order_exact.py` performs that rational symbolic calculation.

The real, integer-power part of the second sector begins
\[
 \Re_{\rm coefficients} R_2
 =e^{-2}\left(1-\frac14v-\frac{11}{32}v^2-\frac{175}{384}v^3+\cdots\right).
\]
This is not the real part of the full lateral resummation of that sector.

## 7. Numerical summation

Two equivalent exact operations need not be equally well conditioned after finite-order Padé approximation. The most useful implementation is:

1. Resum the primitive blocks, rather than Padé-approximating each expanded product separately.
2. Evaluate the poorly conditioned first endpoint function with its decaying Green function,
\[
 I_r(b)=-\frac1{2r}\int_0^\infty e^{-y}
 a_r\left(b+\frac{y}{2r}\right)
 h\left(b+\frac{y}{2r}\right)dy.
\]
3. Assemble the finite \(\Lambda\)-polynomial through the matrix formula.

This Green function excludes the growing homogeneous solution and avoids asking Padé to reproduce the negative-action singularity generated by formal ODE inversion. The supplied `green_resum.py` implements it for the first density sector, using \(R_1=4iC_1I_1\).

For \(F=\sum f_kv^k\), the Borel–Leroy convention is
\[
 {\cal B}_\ell F(z)=\sum\frac{f_k}{\Gamma(k+\ell)}z^k,
 \quad {\cal S}_+F(v)=\int_{0}^{\infty e^{i\phi}}
 e^{-t}t^{\ell-1}{\cal B}_\ell F(vt)\,dt.
\]
The code factors integer and half-integer power lattices separately. Known nonpositive powers are kept explicitly. The useful Leroy indices for the positive-power perturbative tails are \(\ell=5/2\) for \(D_0\) and \(\ell=3/2\) for \(R_0\). The factor \(\Lambda=(8e/v)e^{-1/v}\) is essential when identifying these large-order exponents.

The tables include order, angle, quadrature, and precision variations. A 256-node rule at angle 0.22 can itself leave errors around \(10^{-13}\)–\(10^{-14}\); increasing the coefficient count does not remove that quadrature floor. The stronger tests use 512 nodes and angles 0.40 and 0.55. Plain two-cut conformal Taylor summation and the tested conformal Padés did not outperform the factorized method; their raw results are retained, not used as evidence for higher-sector resolution.

## 8. Scope and remaining gaps

The flow was computed through order 210 at high precision; scalar seeds are retained through \(v^{208}\), with guards for the sector files through \(v^{200}\). Formal sectors through \(\Lambda^{12}\) were generated. The independent `nenr` comparison checks \(A_{00}\), not the new endpoint seed coefficient by coefficient. The latter has low-order analytic checks and high-precision integral-equation tests.

The formal construction is explicit at every finite order, and several exponentially small sectors are numerically resolved. This is not a proof of global Borel summability, uniform contour deformation, or convergence of the infinite sum over sectors. Error bars from Padé/angle variation are empirical diagnostics, not interval-certified bounds.

### Sources

- User-supplied `o3.pdf`, dated 21 October 2026, especially Eqs. (3)–(16) and Table 1. Its notation D(g) denotes a zeta-free O(3) series, not the lattice density D(Q).
- F. T. Sant'Ana, *Weak-Coupling Limit of the Lattice Nonlinear Schrödinger Integral Equation*, arXiv:2603.09522v2.
- Z. Bajnok, J. Balog, R. Miravitllas, D. le Plat, I. Vona, *The complete trans-series for conserved charges in the Lieb–Liniger model*, arXiv:2504.05932.
- B. Reichert and Z. Ristivojevic, *Analytical results for the capacitance of a circular plate capacitor*, arXiv:2001.01142.
- User-supplied `nenr_336.txt` and `O3TBA.wl`; the Chebyshev solver here is a fresh implementation using the analytic Lorentzian action on even Chebyshev polynomials.
