# Completing the lattice Love-equation analysis: exact reconstruction, a spectral scaling theorem, and validated numerics

## Scope and conventions

These notes record calculations made in the present continuation. They are not a claim that every exponentially small individual-eigenvalue correction, or the complete global Borel theorem, has been proved.

Let

\[
K_Q(x,y)=\frac1{\pi[1+(x-y)^2]},\qquad -Q<x,y<Q,
\]
\[
(I-K_Q)f_Q=1,\quad (I-K_Q)\rho_Q=K(x),\quad
D(Q)=f_Q(0)-1,\quad R(Q)=\rho_Q(0),\quad E(Q)=2\pi R(Q)-2.
\]
Write \(\chi(Q)=f_Q(Q)\), and \(\mathscr R_Q=K_Q(I-K_Q)^{-1}\). Thus \(\rho_Q(x)=\mathscr R_Q(x,0)\).
All derivatives in this document are in Q unless explicitly specified. In the earlier running coupling, \(b=\pi Q\), \(2b=v^{-1}+\log(v/(8e))\), and \(\Lambda=e^{-2\pi Q}\).

The numerical thermodynamics sets kappa=1. Fixed Q, fixed physical Fermi rapidity, and fixed particle density are different limits.

## 1. Exact boundary-to-bulk reconstruction

### 1.1 Resolvent identities

For interior x,y, interval differentiation and translation invariance give

\[
\partial_Q\mathscr R_Q(x,y)=\mathscr R_Q(x,Q)\mathscr R_Q(Q,y)+\mathscr R_Q(x,-Q)\mathscr R_Q(-Q,y),
\]
\[
(\partial_x+\partial_y)\mathscr R_Q(x,y)=\mathscr R_Q(x,-Q)\mathscr R_Q(-Q,y)-\mathscr R_Q(x,Q)\mathscr R_Q(Q,y).
\]
These follow directly by differentiating the resolvent equation, and by integration by parts. No asymptotic expansion is involved. If
\(s=\mathscr R_Q(Q,-Q)\), then \(\chi'=2s\chi\).

The constant-source solution satisfies

\[
\partial_Q f_Q(x)=\chi[\mathscr R_Q(x,Q)+\mathscr R_Q(x,-Q)],
\]
\[
\partial_x f_Q(x)=\chi[\mathscr R_Q(x,-Q)-\mathscr R_Q(x,Q)].
\]
Writing \(R_\pm(x,Q)=\mathscr R_Q(x,\pm Q)\), with total derivatives of the moving endpoint,

\[
\partial_Q R_+=-\partial_xR_++2sR_-,\qquad
\partial_Q R_-=\partial_xR_-+2sR_+.
\]
Consequently

\[
\boxed{\partial_Q^2f_Q(x)-\partial_x^2f_Q(x)=2\frac{\chi'}\chi\partial_Q f_Q(x).}
\]

### 1.2 Convergent Goursat construction

Set
\[
a=\chi'/\chi,\quad V=a^2-a',\quad f_Q(x)=\chi(Q)\psi(Q,x),
\quad\xi=Q+x,\quad\eta=Q-x.
\]
Then
\[
\psi_{\xi\eta}=\frac14 V((\xi+\eta)/2)\psi,
\qquad\psi(\xi,0)=\psi(0,\eta)=1.
\]
Equivalently,
\[
\boxed{\psi(\xi,\eta)=1+\frac14\int_0^\xi ds\int_0^\eta dt\,
 V((s+t)/2)\psi(s,t).}
\]
The boundary conditions follow from f_Q(±Q)=chi(Q); chi(0)=1. The exact point observable is
\[
\boxed{D(Q)+1=\chi(Q)\psi(Q,Q).}
\]

For a finite square 0≤xi,eta≤Q and M≥sup_[0,Q]|V|, the n-th Volterra iterate obeys
\[
|T_V^n1|\le \frac{(M\xi\eta/4)^n}{(n!)^2}.
\]
The iterates therefore converge absolutely and uniformly, and the same bound proves uniqueness. This is a convergent exact construction, not the divergent large-Q trans-series.

For two potentials V,W bounded by M with sup|V-W|≤delta, the same product estimate bounds the difference of their iterates by
\[
\delta\sum_{n\ge1}\frac{nM^{n-1}(\xi\eta/4)^n}{(n!)^2}.
\]
Thus the reconstruction is quantitatively stable on every finite square.

### 1.3 Recovering the lattice profile and energy

Let eta(Q)=rho_Q(Q). Exact identities imply
\[
D'=2\chi\eta,\qquad R'=2\eta^2.
\]
Hence
\[
\boxed{R(Q)=\frac1\pi+\frac12\int_0^Q\left(\frac{D'(s)}{\chi(s)}\right)^2ds.}
\]
For 0≤|x|≤Q the whole lattice profile is
\[
\boxed{\rho_Q(x)=\eta(|x|)+\int_{|x|}^Q
 \frac{\eta(s)}{\chi(s)}\partial_s f_s(x)\,ds.}
\]
The initial value eta(0)=1/pi follows from the zero-length integral equation. Energy follows by E=2pi R-2.

**Interpretation.** The earlier two-seed asymptotic algorithm is not minimal at the level of exact functions: the exact boundary function chi on 0≤q≤Q determines D,R,E and the full profiles. But a formal large-Q series for chi is not its value on that entire interval. Inserting that divergent series down to q=0 would be invalid. The argument therefore does not by itself prove the earlier endpoint-seed spectral multiplier or its Borel completion.

**Numerics.** The test uses chi and V computed from independent boundary resolvent columns, not D as an input. At Q=.9 a 256-grid Goursat solve with Richardson extrapolation gives 0.8146009425241081, versus D=0.81460094252788799...; at Q=2 the 512-grid extrapolation gives 1.970694838377316, versus 1.97069483838877704.... This is a low-order PDE-discretization check, not a nonperturbative-sector test.

## 2. A deformed-determinant scaling theorem

### 2.1 Exact normalization

Define
\[
F(z,Q)=\det(I-zK_Q),\qquad B_Q=\frac1QK_Q(I-K_Q)^{-1}.
\]
For every finite Q,
\[
\boxed{\mathfrak D_Q(u):=\frac{F(1+u/Q,Q)}{F(1,Q)}
 e^{u\operatorname{Tr}B_Q}=\det_2(I-uB_Q).}
\]
Here det_2 is the regularized product
\[
\det_2(I-uB)=\prod_j(1-u\beta_j)e^{u\beta_j}.
\]
This formula follows by factoring I-(1+u/Q)K=(I-K)(I-uB). At finite Q the ordinary determinants and trace exist.

Let A be the positive restricted half-Laplacian on (-1,1), defined by extending functions by zero outside the interval and using Fourier symbol |p|. It is NOT the square root defined spectrally from the ordinary interval Dirichlet Laplacian. Write its eigenvalues as lambda_j, j≥1.

### 2.2 Fixed-eigenvalue convergence

After rescaling the interval put h=1/Q and
\(T_h=P e^{-h|D|}P\). The quadratic forms
\[
q_h(f)=\frac1{2\pi}\int_{\mathbb R}
\frac{1-e^{-h|p|}}h|\widehat f(p)|^2dp
\]
increase to the form q(f) of A as h decreases to zero.

The min–max upper bound gives lambda_j(h)≤lambda_j for the low eigenvalues
\(\lambda_j(h)=[1-\mu_{j-1}(Q)]/h\). To exclude loss of compactness, if q_h(f)≤C and ||f||≤1, then for fixed M and sufficiently small h,
\[
\int_{|p|>M}|\widehat f(p)|^2\frac{dp}{2\pi}\le\frac{2C}{M}.
\]
Together with fixed compact spatial support, this makes bounded-energy eigenvectors precompact in L². The min–max lower bound then proves
\[
Q[1-\mu_{j-1}(Q)]\longrightarrow\lambda_j.
\]
It follows that the eigenvalues of B_Q obey
\[
\beta_j(Q)=\frac{\mu_{j-1}(Q)}{Q[1-\mu_{j-1}(Q)]}\longrightarrow\lambda_j^{-1}.
\]

### 2.3 Uniform control of the infinite product

The kernel is positive. Dropping the constraint on intermediate integration points gives, for every positive integer m,
\[
\operatorname{Tr}T_h^m\le\frac{2}{\pi m h}.
\]
Since j mu_{j-1}^m≤Tr T_h^m, put t=-log(mu_{j-1}). If t≤1 choose m=ceil(1/t), and if t>1 choose m=1. This yields
\[
\boxed{0\le\beta_j(Q)\le\frac{2e^2}{\pi j}\quad\text{uniformly in }Q.}
\]
The bound is not optimized. It supplies a summable majorant for beta_j². Therefore the regularized products converge uniformly on every compact u-set:
\[
\boxed{\mathfrak D_Q(u)\longrightarrow\det_2(I-uA^{-1}).}
\]
Their zeros converge to the lambda_j. A^-1 is Hilbert–Schmidt, not trace class, so omitting the exponential trace counterterm would destroy this normalized limit.

This is an all-spectral scaling limit, stronger than the single leading eigenvalue limit. It does NOT yet calculate finite-Q exponentially small corrections to its zeros.

## 3. An exact spectral sum rule

The known Green kernel of A is
\[
G_A(x,y)=\frac1\pi\log\frac{1-xy+\sqrt{1-x^2}\sqrt{1-y^2}}{|x-y|}.
\]
Set x=tanh(t), y=tanh(s). The logarithm becomes log coth(|t-s|/2). The convolution identity
\[
\int_{\mathbb R}\operatorname{sech}^2t\operatorname{sech}^2(t-u)dt
=4(u\coth u-1)\operatorname{csch}^2u
\]
gives
\[
\operatorname{Tr}A^{-2}=\frac8{\pi^2}\int_0^\infty
(u\coth u-1)\operatorname{csch}^2u[\log\coth(u/2)]^2du.
\]
Now use z=tanh(u/2):
\[
=\frac4{\pi^2}\int_0^1
[(z^{-3}-z)\operatorname{atanh}z-z^{-2}+1]\log^2z\,dz.
\]
Expanding atanh(z), integrating monomials, and telescoping partial fractions yields
\[
\int_0^1[\cdots]\log^2z\,dz=\frac12+\frac74\zeta(3).
\]
Therefore
\[
\boxed{\sum_{j\ge1}\lambda_j^{-2}=\frac{2+7\zeta(3)}{\pi^2}}
=1.0551991649196871247348017796117890\ldots.
\]
The code independently integrates the one-dimensional expression, agreeing to about 63 digits.
Consequently
\[
\log\det_2(I-uA^{-1})=-\frac{2+7\zeta(3)}{2\pi^2}u^2+O(u^3).
\]
No claim of first publication of this sum rule is made; the Green kernel and fractional spectral theory are published inputs.

### Efficient spectral matrix

An energy-orthonormal basis is
\(e_n(x)=\sqrt{2/(\pi n)}\sin(n\arccos x)\), n≥1.
The compact embedding matrix, isospectral to A^-1, is
\[
C_{mn}=\frac2{\pi\sqrt{mn}}
\left[\frac1{1-(m-n)^2}-\frac1{1-(m+n)^2}\right]
\]
for equal parities, and zero otherwise. It follows from
\(A[\sqrt{1-x^2}U_{n-1}(x)]=nU_{n-1}(x)\).
The code computes eigenvalues and regularized determinants directly from this rational matrix.

## 4. First logarithmic eigenvalue correction: prediction, not a completed theorem

Let the normalized A-eigenfunction behave at the endpoints as
\(\phi_j\sim c_\pm\sqrt{d}\). The fractional Pohozaev identity gives
\[
c_+^2+c_-^2=\frac{4\lambda_j}{\pi}.
\]
Its high-frequency Fourier tail has nonoscillatory squared amplitude
\(\pi(c_+^2+c_-^2)/(4|p|^3)\). Using this in q_h(phi_j)-q(phi_j) gives
\[
-\frac{c_+^2+c_-^2}{8}h\log(1/h)+O(h)
=-\frac{\lambda_j}{2\pi}h\log(1/h)+O(h).
\]
This is the fixed-eigenfunction Rayleigh calculation. It motivates
\[
\boxed{1-\mu_{j-1}(Q)=\frac{\lambda_j}{Q}
-\frac{\lambda_j\log Q}{2\pi Q^2}-\frac{C_j}{Q^2}+\cdots.}
\]
The code tests the predicted (not fitted) log coefficient for four modes, Q=128 through 4096, with two cell resolutions and Richardson extrapolation. The inferred C_j stabilize; for j=1 they increase from 1.04913 to 1.06915 over that range.

**Unfinished:** upgrading this Rayleigh expansion to an actual-eigenvalue asymptotic equality needs control of the perturbed endpoint eigenfunctions. The data support it but do not replace that estimate. Neither the constants C_j nor the eigenvalue exponential sectors are given closed forms here.

## 5. Certified finite-Q reference solutions

The exact sup-norm bound is
\[
\|K_Q\|_{\infty\to\infty}=\frac2\pi\arctan Q<1.
\]
Thus for any approximate full profile and residual r=(I-K)f_app-g,
\[
\|f_app-f\|_\infty\le\frac{\|r\|_\infty}{1-(2/\pi)\arctan Q}.
\]

Choose exact N-node Gauss–Legendre nodes y_j and weights w_j on [-Q,Q], and fixed decimal trial coefficients c_j. Let
\[
f_N(x)=g(x)+\sum_jw_jK(x-y_j)c_j.
\]
The interval code brackets every Legendre root by a sign change and encloses its exact weight, evaluates all node residuals with interval arithmetic, and regards the computed c_j merely as fixed decimals. It does not assume an exact matrix solve.

For 0<delta<1 put
\[
\rho_\delta=\delta/Q+\sqrt{1+(\delta/Q)^2},\qquad
k_\delta=[\pi(1-\delta^2)]^{-1}.
\]
The analytic ellipse bound for H_x(y)=K(x-y)f_N(y) is
\[
M_\delta=k_\delta\left[g_\delta+k_\delta\sum_jw_j|c_j|\right],
\]
where g_delta=1 for the Love source and g_delta=k_delta for the lattice Lorentzian source.
Since Gauss quadrature is exact through degree 2N-1, a Chebyshev tail estimate gives
\[
\left|\int_{-Q}^QH_x(y)dy-\sum_jw_jH_x(y_j)\right|
\le\frac{8QM_\delta\rho_\delta^{-2N}}{1-\rho_\delta^{-1}}.
\]
Adding \((2Q/\pi)\max_j|r_j|\), then the inverse bound, yields a full error enclosure.

With mpmath interval arithmetic at 120 digits, N=64, Q=.9, delta=.9, the bounds are below 2.44e-47 for D and 1.19e-47 for R; output intervals use a conservatively rounded radius 1e-46. At Q=2, N=96 gives conservative radii 1e-32 for D and 1e-33 for R. Interval arithmetic is the arithmetic-enclosure mechanism; the implementation is not separately formalized in a proof assistant.

This certifies the TBA reference, NOT a Borel–Padé error or a global equality of the trans-series with the Fredholm solution.

## 6. Fixed-density thermodynamics and the high-density T^4 coefficient

For kappa=1 write the grand potential
\[
\Omega(T,\mu)=\Omega_0(\mu)+a(\mu)T^2+b(\mu)T^4+O(T^6),
\quad a=-\frac\pi{6v_s}.
\]
Let \(\mathcal K=\partial_\mu D=\chi^2/(\pi v_s)>0\). At fixed D,
\[
\boxed{\mu(T)=\mu_0+\frac{a'(\mu_0)}{\mathcal K}T^2+O(T^4),}
\]
\[
\boxed{F(T,D)=F_0(D)+aT^2+
\left[b+\frac{(a')^2}{2\mathcal K}\right]T^4+O(T^6).}
\]
These follow by expanding D=-partial_mu Omega and performing the Legendre transform. All factors have the previously constructed formal trans-series, so the canonical correction introduces no additional seed.

At Q=.9, b=-.6292090698625181, while the canonical coefficient is
-.5989616140053465. An independent finite-T TBA solve adjusting mu to hold D fixed gives -.60106621374, -.59948400796, -.59909158066 at T=.02,.01,.005. The discrepancy falls by about four on halving T, as expected from the next T^6 term. The test is ordinary double precision, not an interval thermal certificate.

A separate exact Laurent calculation of the existing grand-canonical formula yields
\[
b(v)=-\frac1{2880v^3}+O(v^{-2}),\qquad
\boxed{b(Q)\sim-\frac{\pi^3}{360}Q^3.}
\]
The naively larger v^-4 contributions cancel. The three terms give at powers (v^-4,v^-3):
(-1/82944,1/9216), (1/82944,-7/27648), (0,-7/34560).
Numerical coefficients b(Q)/Q^3 approach -pi^3/360. This does not determine the full simultaneous low-T/high-Q scaling function from two coefficients alone.

## 7. What is and is not completed

Completed here: exact convergent boundary-to-bulk reconstruction; canonical determinant scaling limit; an exact inverse-square spectral sum; interval error enclosures for finite-Q TBA; the fixed-density T^4 Legendre correction with an independent thermal test.

Still open here: a uniform finite-Q deformation of the limiting determinant giving exponentially small corrections to each eigenvalue; an analytic proof of the log eigenvalue correction beyond its Rayleigh derivation; a theorem validating the endpoint spectral multiplier and the entire resummed trans-series globally; an identified attractive-dual physical excitation gap.

The attractive-dual gap is not the kernel eigenvalue gap, nor does a Borel singularity alone define an attractive Hamiltonian and its Bethe vacuum. No such missing model specification has been silently supplied.

The exact Goursat construction changes the proof strategy: if a proposed resummation of chi is shown to be the exact chi, its convergent Volterra reconstruction gives the unique full profiles. To establish that the previous endpoint trans-series is this reconstruction still requires asymptotic/Borel control under the double integral. Extending a large-Q series down to Q=0 is specifically excluded.

## 8. Well-posed research questions opened by these results

1. **Uniform spectral resurgence.** Determine the finite-Q perturbative and exponential deformation of det_2(I-uA^-1), uniformly near u=lambda_j. This would turn a determinant trans-series into individual-eigenvalue trans-series; merely evaluating F at z=1 cannot do it.
2. **One boundary master function and its Stokes propagation.** Can the Goursat representation derive the endpoint spectral multiplier and external-residue constants directly from the fixed-source boundary trans-series? This asks whether the distinct action sectors arise from characteristic propagation and matching, without independent endpoint assumptions.
3. **Noncommuting thermal and high-density limits.** Determine a uniform low-T/high-Q theory, with the canonical/grand-canonical distinction retained. The Q^4 cancellation in b and the vanishing sound velocity make this more than a request for additional Sommerfeld coefficients.
4. **Probabilistic meaning of resurgent sectors.** For the killed discrete Cauchy walk, E_x[z^tau]=1-(1-z)(I-zK_Q)^-1 1. Thus D+1 is the mean exit time at the center; zeros of the deformed determinant control exit-time exponential moments. Can the lattice-to-continuum correction and its exponentially small sectors be identified with particular path/overshoot mechanisms? This is a defined question, unlike an unspecified attractive dual.

The topics are ordered by direct relevance to the unresolved trans-series questions. Exact higher spectral-zeta sum rules provide a useful additional test bed, but no unverified arithmetic pattern is asserted.

## References and source audit

- Sant'Ana, arXiv:2603.09522. The current retrieval is inconsistent: the official cached record/html supplies March v2, while other indexed records advertise a September v3. No novelty claim about the unseen/reliably unavailable revised full text is made here.
- Bajnok et al., arXiv:2504.05932, fixed-source Love/Lieb–Liniger trans-series machinery.
- Kulczycki, Kwasnicki, Malecki, Stos, arXiv:0906.3113, especially section 11, the explicit interval Green kernel and fractional spectrum.
- Ros-Oton and Serra, arXiv:1207.5986, fractional Pohozaev identity and boundary trace.
- Zhong et al., arXiv:2602.03714, negative-spin-chain thermodynamics and excitations.
- The Goursat/Volterra construction is derived above from resolvent differentiation. Its relation to classical Krein/accelerant and inverse-wave methods must be checked before claiming novelty.
