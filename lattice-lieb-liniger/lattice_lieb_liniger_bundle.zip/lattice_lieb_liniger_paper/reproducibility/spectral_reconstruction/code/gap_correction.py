"""Test the predicted -lambda_j log(Q)/(2*pi*Q**2) gap correction.
Uses exact cell-integrated Toeplitz Galerkin matrix and parity sectors.
Predicted coefficient is not fitted. Finite constant is estimated.
"""
import numpy as np, scipy.fft as fft, scipy.sparse.linalg as sla
from pathlib import Path
import time,json
from fractional_spectrum import spectrum

def modes(Q,step=.05,k_each=2):
 n=int(round(2*Q/step));n+=n%2;step=2*Q/n;m=n//2;x=step*np.arange(n)
 z=step/(x-1j);power=z.copy();c=np.zeros(n)
 for k in range(16):c+=2*power.imag/((2*k+1)*(2*k+2)*np.pi);power*=z*z
 nf=fft.next_fast_len(2*n-1);emb=np.zeros(nf);emb[:n]=c;emb[-n+1:]=c[1:][::-1];ce=fft.rfft(emb)
 vals=[];res=[];t=time.time();calls=0
 for parity in [1,-1]:
  def mv(a):
   nonlocal calls
   calls+=1;tmp=np.zeros(nf);tmp[:m]=parity*a[::-1];tmp[m:n]=a
   return fft.irfft(fft.rfft(tmp)*ce,nf)[m:n]
  op=sla.LinearOperator((m,m),matvec=mv,dtype=float)
  yy=(np.arange(m)+.5)*step/Q
  start=np.sqrt(1-yy*yy)*(1 if parity==1 else yy)
  v,vec=sla.eigsh(op,k=k_each,which='LA',tol=2e-14,v0=start,ncv=28)
  vals.extend(v);res.extend([float(np.linalg.norm(mv(vec[:,j])-v[j]*vec[:,j])) for j in range(k_each)])
 vals=np.sort(vals)[::-1]
 return {'Q':Q,'step':step,'Qgap':list(Q*(1-vals)),'residual_max':max(res),'seconds':time.time()-t,'calls':calls}

if __name__=='__main__':
 target=spectrum(256,4);out=[];pairs=[]
 for Q in [128,256,512,1024,2048,4096]:
  rows=[modes(Q,h) for h in [.1,.05]]
  out.extend(rows);e=(4*np.array(rows[1]['Qgap'])-np.array(rows[0]['Qgap']))/3
  C=Q*(target-e)-target/(2*np.pi)*np.log(Q)
  item={'Q':Q,'Qgap_extrapolated':list(e),'finite_constant_estimate':list(C)}
  pairs.append(item);print(item,flush=True)
 root=Path(__file__).resolve().parents[1]/'results'
 (root/'gap_modes.json').write_text(json.dumps(out,indent=2))
 (root/'gap_log_correction.json').write_text(json.dumps({'target':list(target),'coefficients':list(target/(2*np.pi)),'results':pairs},indent=2))
