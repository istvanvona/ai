"""Finite-Q Love/TBA error enclosure using interval arithmetic plus an analytic
Gauss-Legendre remainder bound. No Padé or asymptotic-series assumptions.

Legendre roots are bracketed by sign changes in interval arithmetic. The trial
coefficients are fixed decimals, NOT assumed to be exact collocation solutions.
All residual and quadrature errors are included. Requires mpmath only.
"""
import json,time
from pathlib import Path
import mpmath as mp


def legendre_pair(n,x):
    p0=x*0+1
    if n==0:return p0,x*0
    p1=x
    for k in range(1,n):p0,p1=p1,((2*k+1)*x*p1-k*p0)/(k+1)
    return p1,p0

def certify(Qtext='0.9',n=64,dps=110,delta_text='0.9'):
    start=time.time();mp.mp.dps=dps;mp.iv.dps=dps+10;iv=mp.iv
    q=mp.mpf(Qtext);qi=iv.mpf(Qtext);delta=iv.mpf(delta_text)
    xx,ww=mp.gauss_quadrature(n,'legendre')
    # N disjoint sign-changing brackets contain all N real simple roots.
    nodes=[];weights=[];bracket_radius=mp.mpf(10)**(-dps+25)
    for j in range(n):
        lo=mp.nstr(xx[j]-bracket_radius,dps);hi=mp.nstr(xx[j]+bracket_radius,dps)
        pl=legendre_pair(n,iv.mpf(lo))[0];ph=legendre_pair(n,iv.mpf(hi))[0]
        signchange=(mp.mpf(pl.b)<0 and mp.mpf(ph.a)>0) or (mp.mpf(pl.a)>0 and mp.mpf(ph.b)<0)
        if not signchange:raise ArithmeticError(f'Could not certify root {j}')
        if j and mp.mpf(lo)<=oldhi:raise ArithmeticError('Overlapping root brackets')
        oldhi=mp.mpf(hi);x=iv.mpf([lo,hi]);p,prev=legendre_pair(n,x)
        dp=n*(x*p-prev)/(x*x-1)
        wi=2/((1-x*x)*dp*dp)
        if mp.mpf(wi.a)<=0:raise ArithmeticError('Nonpositive weight enclosure')
        nodes.append(qi*x);weights.append(qi*wi)
    def km(x):return 1/(mp.pi*(1+x*x))
    def ki(x):return 1/(iv.pi*(1+x*x))
    # Ordinary high-precision solves propose trial coefficients only.
    x=[q*t for t in xx];w=[q*t for t in ww]
    A=mp.matrix([[int(i==j)-w[j]*km(x[i]-x[j]) for j in range(n)] for i in range(n)])
    ell=delta/qi+iv.sqrt(1+(delta/qi)**2)
    kdelta=1/(iv.pi*(1-delta*delta))
    inverse_bound=1/(1-2/iv.pi*iv.atan2(qi,iv.mpf(1)))
    mat=[[weights[j]*ki(nodes[i]-nodes[j]) for j in range(n)] for i in range(n)]
    output={'Q':Qtext,'n':n,'dps':dps,'delta':delta_text,'root_brackets':'certified disjoint sign changes'}
    for name,g in [('f',lambda x:mp.mpf(1)),('rho',km)]:
        cf=mp.lu_solve(A,mp.matrix([g(t) for t in x]))
        ci=[iv.mpf(mp.nstr(a,dps-10)) for a in cf]
        residmax=mp.mpf(0)
        for i in range(n):
            gi=iv.mpf(1) if name=='f' else ki(nodes[i])
            r=ci[i]-gi-sum((mat[i][j]*ci[j] for j in range(n)),iv.mpf(0))
            residmax=max(residmax,mp.mpf(abs(r).b))
        nodal=iv.mpf(mp.nstr(residmax,dps+5))
        boundg=iv.mpf(1) if name=='f' else kdelta
        Mg=kdelta*(boundg+kdelta*sum((weights[j]*abs(ci[j]) for j in range(n)),iv.mpf(0)))
        quadrature=8*qi*Mg*ell**(-2*n)/(1-1/ell)
        residual=2*qi/iv.pi*nodal+quadrature
        error=inverse_bound*residual
        center=(iv.mpf(1) if name=='f' else 1/iv.pi)+sum((weights[j]*ki(nodes[j])*ci[j] for j in range(n)),iv.mpf(0))
        if name=='f':center-=1
        radius=mp.mpf(error.b)
        # A deliberately rounded-up decimal power gives a convenient rigorous radius.
        power=int(mp.ceil(mp.log10(radius)))
        radius_up=iv.mpf('1e'+str(power))
        enclosure=center+iv.mpf([-mp.mpf(radius_up.b),mp.mpf(radius_up.b)])
        output['D' if name=='f' else 'R']={
          'trial_center':mp.nstr((mp.mpf(center.a)+mp.mpf(center.b))/2,80),
          'uniform_error_bound_interval':str(error),
          'conservative_radius':f'1e{power}',
          'observable_enclosure':str(enclosure),
          'node_residual_bound':mp.nstr(residmax,8)}
    output['seconds']=time.time()-start
    return output

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--Q',default='0.9');a.add_argument('--n',type=int,default=64);a.add_argument('--dps',type=int,default=110)
    args=a.parse_args();out=certify(args.Q,args.n,args.dps)
    print(json.dumps(out,indent=2))
    path=Path(__file__).resolve().parents[1]/'results'/f'certified_tba_Q{args.Q}_N{args.n}.json'
    path.write_text(json.dumps(out,indent=2))
