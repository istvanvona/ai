"""Exact rational two-term Laurent calculation of the large-Q T^4 coefficient.
The input jets follow from the already-derived perturbative D,chi,log determinant.
No fitted constants; p stands for pi. Subleading unknown coefficients cannot
contribute to the displayed v^-4 and v^-3 terms.
"""
import sympy as s
import json
from pathlib import Path
p=s.symbols('p',positive=True)
class Jet:
    # coefficient keys are twice the power of v; keep first two integer-spaced orders
    def __init__(self,d):
        d={k:s.expand(v) for k,v in d.items() if v!=0}
        d={k:v for k,v in d.items() if v!=0}
        self.d={} if not d else {k:v for k,v in d.items() if k<=min(d)+2}
    @staticmethod
    def constant(a):return Jet({0:s.sympify(a)})
    def __add__(self,o):
        if not isinstance(o,Jet):o=Jet.constant(o)
        out=self.d.copy()
        for k,c in o.d.items():out[k]=out.get(k,0)+c
        return Jet(out)
    __radd__=__add__
    def __neg__(self):return Jet({k:-c for k,c in self.d.items()})
    def __sub__(self,o):return self+-o
    def __mul__(self,o):
        if not isinstance(o,Jet):o=Jet.constant(o)
        out={}
        for k,c in self.d.items():
            for l,d in o.d.items():out[k+l]=out.get(k+l,0)+c*d
        return Jet(out)
    __rmul__=__mul__
    def inv(self):
        k=min(self.d);c=self.d[k];c1=self.d.get(k+2,0)
        return Jet({-k:1/c,-k+2:-c1/c**2})
    def __truediv__(self,o):return self*(o.inv() if isinstance(o,Jet) else 1/s.sympify(o))
    def __pow__(self,n):
        if n<0:return self.inv()**(-n)
        out=Jet.constant(1)
        for _ in range(n):out=out*self
        return out
    def dq(self):
        out={}
        for k,c in self.d.items():
            for add in [2,4]:out[k+add]=out.get(k+add,0)-p*k*c
        return Jet(out)

chi=Jet({-1:s.Rational(1,2),1:-s.Rational(1,4)})
Dq=Jet({0:1,2:1})
eta=Dq/(2*chi);mu=-2*p*eta/chi
r=Jet({0:p/6,2:-p/4});cross=chi.dq()/(2*chi);A=r+cross
Ax=cross.dq()/2+(cross**2-r**2)/2-r*cross
fx=chi.dq()-chi*A
fxx=chi.dq().dq()-chi.dq()*A-chi*(A.dq()+Ax)
rx=eta.dq()-eta*A
rxx=eta.dq().dq()-eta.dq()*A-eta*(A.dq()+Ax)
u=mu.dq()*chi;u2=u.dq()+mu.dq()*fx;u3=u2.dq()+mu.dq()*fxx
e2=-p**2*A/(6*u);e2x=-p**2*Ax/(6*u)
t1=-eta*e2**2/u
t2=p**2/3*((rx*e2+eta*e2x)/u**2-eta*e2*u2/u**3)
t3=-7*p**4/180*(rxx/u**3-3*rx*u2/u**4-eta*u3/u**4+3*eta*u2**2/u**5)
terms=[t1,t2,t3];out={}
for i,t in enumerate(terms):out[f'term{i+1}']={str(s.Rational(k,2)):str(s.simplify(c)) for k,c in t.d.items() if k<=-6}
c4=s.simplify(sum(t.d.get(-8,0) for t in terms));c3=s.simplify(sum(t.d.get(-6,0) for t in terms))
assert c4==0 and c3==-s.Rational(1,2880),(c4,c3)
out['sum']={'v^-4':str(c4),'v^-3':str(c3),'Q^3':'-pi^3/360'}
print(json.dumps(out,indent=2))
(Path(__file__).resolve().parents[1]/'results/thermal_leading_exact.json').write_text(json.dumps(out,indent=2))
