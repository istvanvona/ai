"""Independent quadrature check of Tr(A^-2)=(2+7*zeta(3))/pi^2.
A is the restricted half-Laplacian on (-1,1), zero outside.
"""
import json
from pathlib import Path
import mpmath as mp

def calculation(dps=70):
    mp.mp.dps=dps
    def integrand(z):
        if z==0:return mp.inf
        if z==1:return mp.mpf(0)
        if z<mp.mpf('1e-12'):
            # (z^-3-z)atanh(z)-z^-2+1
            g=mp.mpf(4)/3
            for j in range(1,5):g+=(mp.mpf(1)/(2*j+3)-mp.mpf(1)/(2*j-1))*z**(2*j)
        else:g=(mp.atanh(z)-z)/z**3+1-z*mp.atanh(z)
        return g*mp.log(z)**2
    integral=mp.quad(integrand,[0,mp.mpf('.01'),mp.mpf('.2'),mp.mpf('.8'),1])
    exact=(2+7*mp.zeta(3))/mp.pi**2
    from_integral=4*integral/mp.pi**2
    return {'exact':mp.nstr(exact,dps),'integral':mp.nstr(from_integral,dps),
            'difference':mp.nstr(from_integral-exact,5)}

if __name__=='__main__':
    out=calculation();print(json.dumps(out,indent=2))
    (Path(__file__).resolve().parents[1]/'results/spectral_sum_rule.json').write_text(json.dumps(out,indent=2))
