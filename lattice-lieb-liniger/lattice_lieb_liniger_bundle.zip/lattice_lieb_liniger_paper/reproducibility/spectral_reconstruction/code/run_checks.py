"""Small reproducibility checks; omits the large eigenvalue-grid run."""
import mpmath as mp
from interval_tba import certify
from spectral_sum_rule import calculation
from fractional_spectrum import spectrum
from goursat_reconstruction import reconstruct
from canonical_thermal import prediction

c=certify('0.9',32,90)
assert mp.mpf(c['D']['conservative_radius'])<mp.mpf('1e-20')
print('Certified Q=.9 reference:',c['D']['conservative_radius'],c['R']['conservative_radius'])
s=calculation(55)
assert abs(mp.mpf(s['difference']))<mp.mpf('1e-45')
print('Spectral sum rule:',s['exact'])
e=spectrum(128,4)
assert abs(e[0]-1.15777388369759)<1e-9
print('First four fractional eigenvalues:',e)
a=reconstruct(.9,64);b=reconstruct(.9,128)
d=(4*b['D_from_boundary']-a['D_from_boundary'])/3
assert abs(d-.814600942527888)<2e-10
print('Boundary-to-bulk center value:',d)
p=prediction(.9)
assert abs(p['canonical_T4']+.59896161400535)<1e-9
print('Canonical T^4:',p['canonical_T4'])
print('All small checks passed.')
