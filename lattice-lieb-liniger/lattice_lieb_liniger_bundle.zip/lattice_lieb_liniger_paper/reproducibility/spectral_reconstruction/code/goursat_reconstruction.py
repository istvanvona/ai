"""Exact boundary-to-bulk Goursat identity, checked by an independent finite
Volterra discretization. INPUT to reconstruction: chi(Q) and its associated
V(Q)=[d log chi/dQ]^2-d^2 log chi/dQ^2, NOT D or the central density.
"""
import numpy as np
import scipy.linalg as la
from scipy.special import roots_legendre
from pathlib import Path
import json,time

K=lambda x:1/(np.pi*(1+x*x))
Kp=lambda x:-2*x/(np.pi*(1+x*x)**2)

def boundary(Q,n=48):
    if Q==0:return 1.,0.
    x,w=roots_legendre(n);x=x*Q;w=w*Q
    mat=np.eye(n)-K(x[:,None]-x[None,:])*w[None,:]
    # right-edge and left-edge resolvent columns
    sources=np.column_stack((np.ones(n),K(x-Q),K(x+Q)))
    f,plus,minus=la.solve(mat,sources).T
    chi=1+np.dot(w*K(Q-x),f)
    r=K(0)+np.dot(w*K(Q-x),plus)
    s=K(2*Q)+np.dot(w*K(Q-x),minus)
    tx=Kp(2*Q)+np.dot(w*Kp(Q-x),minus)
    V=4*(s*s-r*s-tx)
    return chi,V

def reconstruct(Q,N,nodes=48):
    start=time.time();step=Q/N
    vals=np.array([boundary(k*step/2,nodes) for k in range(2*N+1)])
    V=vals[:,1];p=np.ones((N+1,N+1));c=step*step/16
    for i in range(1,N+1):
        for j in range(1,N+1):
            p[i,j]=(p[i-1,j]+p[i,j-1]-p[i-1,j-1]+c*(
                V[i+j-1]*(p[i-1,j]+p[i,j-1])+V[i+j-2]*p[i-1,j-1]))/(1-c*V[i+j])
    return {'Q':Q,'N':N,'D_from_boundary':float(vals[-1,0]*p[-1,-1]-1),'seconds':time.time()-start}

if __name__=='__main__':
    from thermodynamics_base import zero
    out={}
    for Q in [.9,2.]:
        table=[reconstruct(Q,N) for N in [32,64,128,256,512]]
        for i in range(1,len(table)):
            table[i]['Richardson_D']=(4*table[i]['D_from_boundary']-table[i-1]['D_from_boundary'])/3
        out[str(Q)]={'independent_D':zero(Q)['D'],'table':table}
        print(json.dumps(out[str(Q)],indent=2),flush=True)
    (Path(__file__).resolve().parents[1]/'results/goursat_reconstruction.json').write_text(json.dumps(out,indent=2))
