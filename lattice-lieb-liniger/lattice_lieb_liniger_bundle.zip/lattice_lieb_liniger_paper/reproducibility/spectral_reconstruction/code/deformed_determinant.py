"""Independent composite Gauss-Legendre spectral test of the normalized
near-critical determinant. No transseries coefficients are fitted or used.
"""
import numpy as np
import scipy.linalg as la
from scipy.special import roots_legendre
from pathlib import Path
import json,time

def kernel_spectrum(Q:float,order:int=12,panel_width:float=2.):
    if Q<=0 or order<2:raise ValueError('Q>0 and order>=2 required')
    panels=int(np.ceil(Q/panel_width));edges=np.linspace(0,Q,panels+1)
    z,w=roots_legendre(order)
    x=np.concatenate([(a+b)/2+(b-a)/2*z for a,b in zip(edges[:-1],edges[1:])])
    weights=np.concatenate([(b-a)/2*w for a,b in zip(edges[:-1],edges[1:])]);sw=np.sqrt(weights)
    diff=1/(np.pi*(1+(x[:,None]-x[None,:])**2));summ=1/(np.pi*(1+(x[:,None]+x[None,:])**2))
    vals=[]
    for parity in [1,-1]:
        mat=(diff+parity*summ)*sw[:,None]*sw[None,:]
        vals.append(la.eigvalsh(mat))
    mu=np.sort(np.concatenate(vals))[::-1]
    # Small negative values of order floating point noise are retained: they
    # contribute negligibly to the regularized product, and are diagnostics.
    return mu,len(x)

if __name__=='__main__':
    out=[]
    for Q in [4,8,16,32,64,128,256]:
      for order in ([10,14] if Q<=128 else [14]):
        t=time.time();mu,n=kernel_spectrum(Q,order);beta=mu/(Q*(1-mu))
        d={'Q':Q,'order':order,'n_each_parity':n,'zeros':[float(Q*(1/v-1)) for v in mu[:4]],
           'Qgap':[float(Q*(1-v)) for v in mu[:4]],'trace_B2':float(np.dot(beta,beta)),
           'logdet2':{str(u):float(np.sum(np.log1p(-u*beta)+u*beta)) for u in [-1.,.5,1.]},
           'trace_error':float(np.sum(mu)-2*Q/np.pi),'seconds':time.time()-t}
        out.append(d);print(d,flush=True)
    (Path(__file__).resolve().parents[1]/'results/deformed_determinant.json').write_text(json.dumps(out,indent=2))
