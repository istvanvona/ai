"""Restricted |D| on (-1,1), not the spectral Dirichlet square root.
Energy-orthonormal basis e_n=sqrt(2/(pi*n))*sin(n arccos(x)).
C=J*J represents a compact operator isospectral to |D|^{-1}.
"""
import numpy as np
import scipy.linalg as la

def inverse_matrix(N:int):
    n=np.arange(1,N+1,dtype=float)
    d=n[:,None]-n[None,:]; s=n[:,None]+n[None,:]
    same=(d.astype(int)%2==0)
    m=np.zeros((N,N)); m[same]=1/(1-d[same]**2)-1/(1-s[same]**2)
    return 2/np.pi*m/np.sqrt(n[:,None]*n[None,:])

def spectrum(N=300,k=8):
    C=inverse_matrix(N)
    b=la.eigvalsh(C,subset_by_index=[N-k,N-1])[::-1]
    return 1/b

def log_det2(N,u):
    b=la.eigvalsh(inverse_matrix(N))
    x=-u*b
    if np.any(1+x<=0):
        return float(np.sum(np.log(np.abs(1+x))-x)),int(np.sum(1+x<0)%2)
    return float(np.sum(np.log1p(x)-x)),0

if __name__=='__main__':
    import json,time
    out=[]
    for N in [32,64,128,256,512,1024]:
        t=__import__('time').time();C=inverse_matrix(N);b=la.eigvalsh(C)
        d={'N':N,'eigenvalues':list(1/b[::-1][:8]),'trace_inverse_squared':float(np.sum(C*C)),
           'logdet2':{str(u):float(np.sum(np.log1p(-u*b)+u*b)) for u in [-1.,.5,1.]},'seconds':time.time()-t}
        out.append(d);print(d,flush=True)
    from pathlib import Path
    (Path(__file__).resolve().parents[1]/'results/fractional_spectrum.json').write_text(json.dumps(out,indent=2))
