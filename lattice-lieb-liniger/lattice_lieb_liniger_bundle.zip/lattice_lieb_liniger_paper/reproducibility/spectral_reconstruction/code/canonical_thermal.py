"""Legendre-transform completion and independent fixed-density thermal TBA test.
All energies use kappa=1; T^4 errors at the smallest T are double-precision-limited.
"""
import json
from pathlib import Path
import numpy as np
import scipy.linalg as la
from scipy.special import roots_legendre,expit
from thermodynamics_base import zero,K

def prediction(Q):
    z=zero(Q);h=2e-4
    av=lambda q:-np.pi/(6*zero(q)['vs'])
    aQ=(av(Q-2*h)-8*av(Q-h)+8*av(Q+h)-av(Q+2*h))/(12*h)
    ap=aQ/z['mup'];kap=z['kL']/(np.pi*z['vs'])
    return dict(**z,a=av(Q),a_mu=ap,compressibility=kap,mu2=ap/kap,
                canonical_T4=z['omega_T4']+ap*ap/(2*kap))

def finiteT_fixed_density(Q,T,n=60):
    base=prediction(Q);mu=base['mu']+base['mu2']*T*T
    ends=sorted(set([0.,max(0,Q-.4),max(0,Q-.12),Q,Q+.12,Q+.4,2.,4.,8.,16.]))
    zz,ww=roots_legendre(n)
    x=np.concatenate([(b+a)/2+(b-a)*zz/2 for a,b in zip(ends[:-1],ends[1:])])
    w=np.concatenate([(b-a)*ww/2 for a,b in zip(ends[:-1],ends[1:])])
    mat=(K(x[:,None]-x[None,:])+K(x[:,None]+x[None,:]))*w[None,:]
    eye=np.eye(len(x));eps=None
    for itmu in range(8):
        bare=-2/(1+x*x)-mu
        if eps is None:eps=bare.copy()
        for it in range(30):
            occ=expit(-eps/T);rhs=eps-bare+T*mat@np.logaddexp(0,-eps/T)
            update=la.solve(eye-mat*occ[None,:],rhs);eps-=update
            if np.max(abs(update))<4e-15:break
        occ=expit(-eps/T);charge=la.solve(eye-mat*occ[None,:],np.ones(len(x)))
        D=2*np.dot(w*K(x),occ*charge)
        if abs(D-base['D'])<3e-15:break
        dmu=(base['D']-D)/base['compressibility'];mu+=dmu;eps-=dmu*charge
    omega=-2*T*np.dot(w*K(x),np.logaddexp(0,-eps/T))
    F=omega+mu*base['D']
    measured=(F-base['energy']-base['a']*T*T)/T**4
    return {'Q':Q,'T':T,'n':n,'mu':mu,'density_residual':D-base['D'],
            'canonical_T4_measured':measured,'canonical_T4_prediction':base['canonical_T4'],
            'mu2_measured':(mu-base['mu'])/T**2,'mu2_prediction':base['mu2']}

if __name__=='__main__':
    out={}
    for Q in [.9,2.]:
        out[str(Q)]={'predicted':prediction(Q),'thermal':[finiteT_fixed_density(Q,T) for T in [.02,.01,.005]]}
        print(json.dumps(out[str(Q)],indent=2),flush=True)
    (Path(__file__).resolve().parents[1]/'results/canonical_thermal.json').write_text(json.dumps(out,indent=2))
