# Lattice Love-equation completion bundle

New calculations in this continuation, independent of the earlier archived coefficient-production run. These files do not claim a completed global Borel theorem or resolved exponentially small individual-eigenvalue corrections.

## Run

Python 3.10+; `numpy`, `scipy`, `mpmath`, `sympy`.

```bash
python -m pip install -r requirements.txt
cd code
OPENBLAS_NUM_THREADS=1 python run_checks.py
```

Individual computations:

```bash
python interval_tba.py --Q 0.9 --n 64
python interval_tba.py --Q 2 --n 96
OPENBLAS_NUM_THREADS=1 python goursat_reconstruction.py
OPENBLAS_NUM_THREADS=1 python deformed_determinant.py
OPENBLAS_NUM_THREADS=1 python fractional_spectrum.py
python spectral_sum_rule.py
OPENBLAS_NUM_THREADS=1 python canonical_thermal.py
python thermal_leading_check.py
OPENBLAS_NUM_THREADS=1 python gap_correction.py
```

`gap_correction.py` is the heaviest test: it uses FFT Toeplitz matrix-vector products on large cell grids through Q=4096. It is not needed to run the small checks.

## Contents

- `notes/DERIVATIONS.md`: definitions, proofs, derivations, limitations, source audit, and meaningful next questions.
- `RESULTS.md`: concise numerical results.
- `code/goursat_reconstruction.py`: exact boundary-to-bulk hyperbolic identity, checked with a convergent grid approximation.
- `code/interval_tba.py`: interval-enclosed Legendre roots, weights, node residuals, plus an analytic ellipse quadrature bound and exact Fredholm inverse bound.
- `code/deformed_determinant.py`: independent finite-Q deformed-determinant scaling tests.
- `code/fractional_spectrum.py`: rational energy-basis matrix for the restricted half-Laplacian inverse.
- `code/spectral_sum_rule.py`: high-precision independent integral check of (2+7 zeta(3))/pi^2.
- `code/gap_correction.py`: four-mode test of the predicted logarithmic correction (not a proof of the expansion).
- `code/canonical_thermal.py`: fixed-density T^4 formula and nonlinear TBA checks.
- `code/thermal_leading_check.py`: exact rational cancellation yielding the large-Q grand-canonical T^4 coefficient.
- `code/thermodynamics_base.py`: copied from the preceding bundle as the zero/finite-temperature base solver. It is included to keep this bundle self-contained.
- `results/*.json`: actual outputs; interval bounds and ordinary numerical diagnostics are explicitly distinguished.

The interval TBA certificate is about the exact integral-equation reference. It is NOT a certificate for Borel–Padé summation. No new high-order nonperturbative-sector separation is claimed in this continuation.
