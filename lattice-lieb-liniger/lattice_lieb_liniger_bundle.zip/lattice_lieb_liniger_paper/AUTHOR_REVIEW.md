# Author review before submission

## Attribution and version control

The manuscript is explicitly a continuation of **arXiv:2603.09522v3 (4 September 2026)**. The September paper already contains the density constant, killed-Cauchy-walk interpretation, leading restricted-half-Laplacian gap, and the distinction between a candidate exponential scale and a resurgence proof. The manuscript does not claim those as newly resolved.

The manuscript author is Istvan Vona. The O(3) commuting-flow input is credited to Dániel Nógrádi, unpublished research note, 21 October 2026. The private note is excluded from the public archive.

Zhong et al., JHEP 08 (2026) 101, is cited for the existing finite-temperature and low-energy context. No claim is made that those subjects were previously untouched. Bibliographic metadata were checked against primary arXiv/publisher/author records. No exhaustive priority theorem is asserted for the spectral trace identity.

## Claims requiring particular independent review

1. **Formal endpoint construction:** the even spectral multiplier and its flow extension are the principal new formal ingredient. They have low-order checks, exact-algebra consistency and high-order numerical evidence, but a uniform endpoint contour/Borel proof is missing.
2. **All-sector formula:** this is a finite coefficient-generating algorithm at each chosen order, not a convergence theorem for the infinite sector sum.
3. **Determinant normalization:** the Fisher–Hartwig constant uses a specific single-root Wiener–Hopf normalization; its derivation and highly sensitive numerical test are included. A full restatement of every analytic hypothesis of the general asymptotic theorem is not supplied.
4. **Spectral results:** the regularized determinant scaling proof and inverse-square sum are supplied. The logarithmic correction to actual eigenvalues is explicitly a conjecture; only the limiting-eigenfunction Rayleigh logarithm is derived.
5. **Thermal results:** the T^4 coefficient is validated against nonlinear TBA in both ensembles. Separate exponentially small thermal sectors and a simultaneous high-density/low-temperature scaling limit have not been resolved.

## Numerical claim limits

- D and R: formal sectors generated through Lambda^12; numerically resolved through Lambda^7. E follows by an exact scalar identity, not a third independent test.
- Point-observable Lambda^8: displayed but explicitly unresolved.
- log Fredholm determinant: even sectors only; Lambda^8 resolved in the tested scans.
- Interval certificates enclose the reference integral-equation solution only. They do not certify finite Padé continuation, the Borel tail, or the full resummation.
- Remainder/prediction ratios contain contributions of later sectors. Their distance from one is not automatically an error estimate.
- No exponentially small correction to an individual operator eigenvalue is claimed.
- No physical attractive-dual gap has been identified.

## Editorial choices

The article is a full-length paper rather than a letter so that the formal method, exact proofs, signed comparisons, failed-method diagnostics and reproduction commands are visible. The archive retains all raw numerical outputs; main-text tables and plots select the decisive tests instead of printing hundreds of machine-digit rows.

Independent mathematical review of the new formal endpoint step remains outstanding. Those are not typography defects and must not be hidden by editing.
