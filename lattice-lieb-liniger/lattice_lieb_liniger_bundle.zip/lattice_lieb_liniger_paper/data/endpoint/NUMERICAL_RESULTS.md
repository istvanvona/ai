# Fresh numerical validation

All target values are from the independent finite-interval Chebyshev solver. No TBA data are fitted to coefficients or sector amplitudes. The energy E=2*pi*rho-2 is not an independent validation.

## Primary point: Q=0.9

D_TBA = `0.814600942527887988555073271052401119549802501203493753478380985392279577716`

rho_TBA = `0.53475681783401556901033074309447919969592285229408207446738765248247891964`

Primary resummation: 198 terms for perturbative seeds; 190 for endpoint blocks; 130 for fixed-source blocks; 512 generalized Laguerre nodes; angle 0.40. The first endpoint is evaluated by a separate decaying Green-function integral.

Remainder before sector n includes all sectors n,n+1,...; its ratio to the n-th sector need not be exactly one.

## D

| n | Exact remainder before n | Predicted sector n | Remainder / prediction |
|---:|---:|---:|---:|
| 3 | -1.3714935953e-9 | -1.3683607314e-9 | 1.00228950147 |
| 4 | -3.13286389965e-12 | -3.11793595491e-12 | 1.00478776503 |
| 5 | -1.49279447411e-14 | -1.48881925111e-14 | 1.00267005078 |
| 6 | -3.97522299905e-17 | -3.95945715167e-17 | 1.00398182043 |
| 7 | -1.5765847375e-19 | -1.57024389952e-19 | 1.00403812298 |
| 8 | -6.34083797709e-22 | -4.49632348818e-22 | 1.4102272654 |

Sum through sector 8: `0.814600942527887988555257722501292010693486888237557996971994`.
Real error: `1.84451448890891144e-22`; remaining imaginary part: `5.66178768709443723793924263762786152510882150509697999509014e-23`.

## rho

| n | Exact remainder before n | Predicted sector n | Remainder / prediction |
|---:|---:|---:|---:|
| 3 | 7.38901846131e-9 | 7.35827166301e-9 | 1.00417853535 |
| 4 | 3.07467982928e-11 | 3.06310794577e-11 | 1.00377782426 |
| 5 | 1.15718835162e-13 | 1.15287177524e-13 | 1.00374419469 |
| 6 | 4.31657638475e-16 | 4.30095377986e-16 | 1.00363235824 |
| 7 | 1.56226048958e-18 | 1.55748873619e-18 | 1.00306374825 |
| 8 | 4.77175338841e-21 | 5.63401100229e-21 | 0.846954928996 |

Sum through sector 8: `0.534756817834015569011193000708363524989905949158333407501072`.
Real error: `8.62257613884325294e-22`; remaining imaginary part: `1.77313618557854026397642903063684668583458683838676479614171e-21`.

Final-order ensemble for rho: error / |sector 7| ranges from `-0.0078520469` to `0.003520860823` for orders 194,196,197,198,199,200 and angles 0.40,0.55. These are empirical stability diagnostics, not rigorous error bars.

Final-order ensemble for D: error / |sector 7| ranges from `-0.001426121063` to `0.001174667508` for orders 194,196,197,198,199,200 and angles 0.40,0.55. These are empirical stability diagnostics, not rigorous error bars.

## Interpretation

The seventh exponential sector is resolved for both D and rho in the tested ensemble. The eighth is not: it is comparable to the remaining resummation systematic. Formal coefficients through sector 12 are supplied, but sectors 9–12 are not claimed to be numerically resolved.

The independent data check is for A00 through power v^208, agreeing to over 150 digits. The new D0 seed has analytic low-order checks and numerical integral-equation checks; it has not been compared coefficient-by-coefficient with an independent 208-order direct-Volin endpoint file.

Plain conformal Taylor and tested conformal Padé outputs are retained in the raw results. They did not outperform the factorized/Green-function method and are not used to claim higher-sector verification.
