import subprocess,os,time,json
from pathlib import Path
root=Path('/mnt/data/lattice_paper_work')
names=['lattice_lieb_liniger_transseries/lattice_transseries_release','lattice_remaining_results/lattice_remaining_release','lattice_completion_and_questions/lattice_completion']
results=[]
for name in names:
 d=root/'archive'/name
 out=root/'audit'/(d.name+'_checks.txt')
 start=time.time()
 with out.open('w') as f:
  p=subprocess.run(['python','-u','run_checks.py'],cwd=d/'code',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
 results.append({'archive':name,'returncode':p.returncode,'seconds':time.time()-start})
 (root/'audit/status.json').write_text(json.dumps(results,indent=2))
