from pathlib import Path
import subprocess,time,json,os,shutil
r=Path('/mnt/data/lattice_paper_work');p=r/'archive';a=p/'lattice_lieb_liniger_transseries/lattice_transseries_release';b=p/'lattice_remaining_results/lattice_remaining_release';c=p/'lattice_completion_and_questions/lattice_completion'
steps=[
 ('determinant_resum',[ 'python','-u','determinant_numeric.py','resum','--Q','.9','--T','154','--phi','.45','--nodes','512','--dps','170'],b/'code'),
 ('certified_reference',['python','-u','interval_tba.py','--Q','0.9','--n','64'],c/'code'),
 ('endpoint_green',['python','-u','green_resum.py','../data/sectors200_n12.json','--Q','.9','-n','1','-T','190','--phi','.5','--inner','384','--outer','32','--dps','200','--evaldps','90','--out',str(r/'audit/green_recheck.json')],a/'code'),
 ('endpoint_factorized',['python','-u','factorized_resum.py','../data/basis200_r8.json','--Q','.9','--T0','198','--TI','190','--TF','130','--phi','.4','--nodes','512','--dps','200','--green',str(r/'audit/green_recheck.json'),'--out',str(r/'audit/factorized_recheck.json')],a/'code')]
results=[]
for name,cmd,cwd in steps:
 t=time.time()
 with (r/'audit'/f'{name}.log').open('w') as f:
  try: proc=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=1200,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'});rc=proc.returncode
  except subprocess.TimeoutExpired:rc='timeout'
 results.append({'test':name,'returncode':rc,'seconds':time.time()-t});(r/'audit/extended_status.json').write_text(json.dumps(results,indent=2))
