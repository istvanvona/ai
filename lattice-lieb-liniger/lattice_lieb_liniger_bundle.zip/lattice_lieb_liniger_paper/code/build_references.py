"""Regenerate the checked bibliography in LaTeX and BibTeX form."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
refs=[
('Santana2026', "Felipe Taha Sant'Ana", "Weak-Coupling Limit of the Lattice Nonlinear Schr{\\\"o}dinger Integral Equation", '', '', '', '2026', '', '2603.09522v3', 'Version 3, 4 September 2026.'),
('BBMLV2026', r'Zolt{\’a}n Bajnok and J{\’a}nos Balog and Ramon Miravitllas and Dennis le Plat and Istv{\’a}n Vona', 'The complete trans-series for conserved charges in the Lieb--Liniger model', 'SciPost Physics','20','096','2026','10.21468/SciPostPhys.20.4.096','2504.05932',''),
('BBV2025', r'Zolt{\’a}n Bajnok and J{\’a}nos Balog and Istv{\’a}n Vona', 'The complete trans-series for conserved charges in integrable field theories','Annals of Physics','481','170152','2025','10.1016/j.aop.2025.170152','2501.16435',''),
('BBV2023', r'Zolt{\’a}n Bajnok and J{\’a}nos Balog and Istv{\’a}n Vona', 'The full analytic trans-series in integrable field theories','Physics Letters B','844','138075','2023','10.1016/j.physletb.2023.138075','2212.09416',''),
('Love1949','E. R. Love','The electrostatic field of two equal circular co-axial conducting disks','Quarterly Journal of Mechanics and Applied Mathematics','2','428--451','1949','10.1093/qjmam/2.4.428','',''),
('LiebLiniger1963','Elliott H. Lieb and Werner Liniger','Exact Analysis of an Interacting Bose Gas. I. The General Solution and the Ground State','Physical Review','130','1605--1616','1963','10.1103/PhysRev.130.1605','',''),
('Farina2022','Leandro Farina and Guillaume Lang and P. A. Martin','Love--Lieb Integral Equations: Applications, Theory, Approximations, and Computations','SIAM Review','64','831--865','2022','10.1137/20M1371038','2010.11052',''),
('Volin2010','Dmytro Volin','From the mass gap in {O(N)} to the non-{Borel}-summability in {O(3)} and {O(4)} sigma-models','Physical Review D','81','105008','2010','10.1103/PhysRevD.81.105008','0904.2744',''),
('Volin2011','Dmytro Volin','Quantum integrability and functional equations','Journal of Physics A: Mathematical and Theoretical','44','124003','2011','10.1088/1751-8113/44/12/124003','1003.4725',''),
('MarinoReis2019',r'Marcos Mari{\~n}o and Tom{\’a}s Reis','Exact Perturbative Results for the Lieb--Liniger and Gaudin--Yang Models','Journal of Statistical Physics','177','1148--1156','2019','10.1007/s10955-019-02413-1','1905.09575',''),
('Reichert2020','Benjamin Reichert and Zoran Ristivojevic','Analytical results for the capacitance of a circular plate capacitor','Physical Review Research','2','013289','2020','10.1103/PhysRevResearch.2.013289','2001.01142',''),
('BBHV2022',r'Zolt{\’a}n Bajnok and J{\’a}nos Balog and {\’A}rp{\’a}d Heged{\H u}s and Istv{\’a}n Vona','Running coupling and non-perturbative corrections for {O(N)} free energy and for disk capacitor','Journal of High Energy Physics','09','001','2022','10.1007/JHEP09(2022)001','2204.13365',''),
('BBV2024',r'Zolt{\’a}n Bajnok and J{\’a}nos Balog and Istv{\’a}n Vona','Wiener--Hopf solution of the free energy {TBA} problem and instanton sectors in the {O(3)} sigma model','Journal of High Energy Physics','11','093','2024','10.1007/JHEP11(2024)093','2404.07621',''),
('O3note',r"D{\'a}niel N{\'o}gr{\'a}di",r'Perturbative free energy of the {O(3)} sigma model at $\vartheta=0$: the zeta-free series in closed form and the zeta terms from it','','','','2026','','','Unpublished research note, 21 October 2026.'),
('TracyWidom1994','Craig A. Tracy and Harold Widom','Fredholm determinants, differential equations and matrix models','Communications in Mathematical Physics','163','33--72','1994','10.1007/BF02101734','hep-th/9306042',''),
('Krein2010','Daniel Alpay and Israel Gohberg and Marinus A. Kaashoek and Leonid Lerer and Alexander L. Sakhnovich','Krein Systems and Canonical Systems on a Finite Interval: Accelerants with a Jump Discontinuity at the Origin and Continuous Potentials','Integral Equations and Operator Theory','68','115--150','2010','10.1007/s00020-010-1803-x','0912.4444',''),
('Zhong2026','Rong Zhong and Yang-Yang Chen and Kun Hao and Wen-li Yang and Vladimir Korepin','Thermodynamics of the Heisenberg {XXX} chain with negative spin','Journal of High Energy Physics','08','101','2026','10.1007/JHEP08(2026)101','2602.03714',''),
('Ristivojevic2019','Zoran Ristivojevic','Conjectures about the ground-state energy of the Lieb--Liniger model at weak repulsion','Physical Review B','100','081110(R)','2019','10.1103/PhysRevB.100.081110','1905.13705',''),
('Bornemann2010','Folkmar Bornemann','On the numerical evaluation of Fredholm determinants','Mathematics of Computation','79','871--915','2010','10.1090/S0025-5718-09-02280-7','0804.2543',''),
('Aniceto2019',r'In{\^e}s Aniceto and G{\"o}k{\c c}e Ba{\c s}ar and Ricardo Schiappa','A primer on resurgent transseries and their asymptotics','Physics Reports','809','1--135','2019','10.1016/j.physrep.2019.02.003','1802.10441',''),
('BasorWidom2004','Estelle L. Basor and Harold Widom','Wiener--Hopf determinants with Fisher--Hartwig symbols','','147','131--149','2004','','math/0205198',r'In \emph{Operator Theoretical Methods and Applications to Mathematical Physics}, Operator Theory: Advances and Applications, vol.\ 147, Birkh{\"a}user, Basel.'),
('Kozlowski2008','K. K. Kozlowski','Truncated Wiener--Hopf operators with Fisher Hartwig singularities','','','','2008','','0805.3902','Preprint; revised version 3, 2022.'),
('Kulczycki2010',r'Tadeusz Kulczycki and Mateusz Kwa{\’s}nicki and Jacek Ma{\l}ecki and Andrzej St{\’o}s','Spectral properties of the Cauchy process on half-line and interval','Proceedings of the London Mathematical Society','101','589--622','2010','10.1112/plms/pdq010','0906.3113',''),
('RosOton2014','Xavier Ros-Oton and Joaquim Serra','The Pohozaev identity for the fractional Laplacian','Archive for Rational Mechanics and Analysis','213','587--628','2014','10.1007/s00205-014-0740-2','1207.5986',''),
('YangYang1969','C. N. Yang and C. P. Yang','Thermodynamics of a one-dimensional system of bosons with repulsive delta-function interaction','Journal of Mathematical Physics','10','1115--1122','1969','10.1063/1.1664947','',''),
('Reich1953','E. Reich','A random walk related to the capacitance of the circular plate condenser','Quarterly of Applied Mathematics','11','341--345','1953','10.1090/qam/57625','',''),
('Spitzer1957','Frank Spitzer','The Wiener--Hopf equation whose kernel is a probability density','Duke Mathematical Journal','24','327--343','1957','','',''),
]
# Normalize TeX acute escapes in the hand-checked names.
refs=[tuple(x.replace('\\’',"\\'") if isinstance(x,str) else x for x in r) for r in refs]
tex=[r'\begin{thebibliography}{99}',r'\small\setlength{\itemsep}{4pt}']
bib=[]
for key,authors,title,journal,volume,pages,year,doi,arxiv,note in refs:
    fields={'title':title,'year':year}
    if authors: fields['author']=authors
    typ='article' if journal else 'misc'
    if key=='O3note': typ='unpublished'
    if key=='BasorWidom2004':
        typ='incollection'; fields.update(booktitle='Operator Theoretical Methods and Applications to Mathematical Physics',series='Operator Theory: Advances and Applications',volume=volume,pages=pages,publisher=r'Birkh{\"a}user',address='Basel')
    elif journal: fields.update(journal=journal,volume=volume,pages=pages)
    if doi: fields['doi']=doi
    if arxiv: fields.update(eprint=arxiv,archivePrefix='arXiv')
    if note: fields['note']=note
    bib.append('@'+typ+'{'+key+',\n'+',\n'.join('  '+k+' = {'+v+'}' for k,v in fields.items())+'\n}\n')
    line=r'\bibitem{'+key+'}\n'
    if authors: line+=authors.replace(' and ', ', ')+'. '
    line+=r'\emph{'+title+'}. '
    if journal: line+=journal+r' \textbf{'+volume+'}, '+pages+' ('+year+'). '
    elif key=='BasorWidom2004': line+=note+r' pp.\ '+pages+' ('+year+'). '; note=''
    else: line+='('+year+'). '
    if doi: line+=r'\doi{'+doi+'}. '
    if arxiv: line+=r'\arxiv{'+arxiv+'}. '
    if note: line+=note
    tex.append(line)
tex.append(r'\end{thebibliography}')
(ROOT/'references.tex').write_text('\n\n'.join(tex)+'\n')
(ROOT/'references.bib').write_text('% Verified reference metadata; supplied unpublished note attributed to Daniel Nogradi.\n\n'+'\n'.join(bib))
print(f'Wrote {len(refs)} bibliography entries.')
