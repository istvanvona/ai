"""Rebuild every manuscript figure and numerical table from retained data.

All calculations involving exponentially small differences use mpmath before
conversion to plotting doubles. No data points are fitted to predictions.
"""
from pathlib import Path
import json, csv, math
import numpy as np
import mpmath as mp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA, FIG, TAB = ROOT/'data', ROOT/'figures', ROOT/'tables'
FIG.mkdir(exist_ok=True); TAB.mkdir(exist_ok=True)
mp.mp.dps=90

def read(p): return json.loads(p.read_text())
def start():
    fig=plt.figure(figsize=(6.65,4.15)); ax=fig.add_subplot(111)
    ax.tick_params(labelsize=10)
    return fig,ax

def finish(fig,ax,name,xlabel,ylabel,legend=True):
    ax.set_xlabel(xlabel,fontsize=11); ax.set_ylabel(ylabel,fontsize=11)
    if legend: ax.legend(fontsize=9,frameon=False)
    ax.grid(True,alpha=.22)
    fig.tight_layout(pad=1.05)
    fig.savefig(FIG/(name+'.pdf'),bbox_inches='tight')
    fig.savefig(FIG/(name+'.png'),dpi=180,bbox_inches='tight')
    plt.close(fig)

exact={'D':mp.mpf('0.814600942527887988555073271052401119549802501203493753478380985392279577716'),
       'rho':mp.mpf('0.53475681783401556901033074309447919969592285229408207446738765248247891964')}
end=read(DATA/'endpoint/factorized_recheck.json')
summary=[]
for obs in ['D','rho']:
    rows=end[obs]; fig,ax=start()
    ns=list(range(1,9))
    residual=[float(abs(exact[obs]-mp.mpf(rows[n-1]['sum_re']))) for n in ns]
    pred=[float(abs(mp.mpf(rows[n]['sector_re']))) for n in ns]
    ax.semilogy(ns,residual,'o-',label='Remainder before sector $n$')
    ax.semilogy(ns,pred,'s--',label='Predicted sector $n$')
    ax.set_xticks(ns)
    ax.annotate('Sector 8 unresolved',xy=(8,residual[-1]),
                xytext=(4.9,max(residual[-1],pred[-1])*0.9),
                arrowprops={'arrowstyle':'->'},fontsize=9,va='center')
    finish(fig,ax,'endpoint_'+obs,'Exponential sector $n$',r'Absolute contribution at $Q=0.9$')
    for n in ns:
        rem=exact[obs]-mp.mpf(rows[n-1]['sum_re']); p=mp.mpf(rows[n]['sector_re'])
        summary.append({'observable':obs,'n':n,'remainder':str(rem),'prediction':str(p),'ratio':str(rem/p)})

fig,ax=start()
for obs,marker,label in [('D','o','$D$'),('rho','s','$R$')]:
    ax.semilogy(range(9),[float(abs(mp.mpf(r['sum_im']))) for r in end[obs]],marker+'-',label=label)
finish(fig,ax,'lateral_cancellation','Highest included sector $n$',r'Absolute imaginary part, $Q=0.9$')

with (DATA/'endpoint/stability.csv').open() as f: stable=list(csv.DictReader(f))
fig,ax=start()
for phi,marker in [('0.4','o'),('0.55','s')]:
    rr=sorted([r for r in stable if r['observable']=='rho' and r['angle']==phi],key=lambda r:int(r['terms'])) if 'angle' in stable[0] else []
    if not rr:
        # Column labels are read explicitly, not inferred from row order.
        phi_key='phi' if 'phi' in stable[0] else 'angle'
        term_key='T0'
        rr=sorted([r for r in stable if r['observable']=='rho' and r[phi_key]==phi],key=lambda r:int(r[term_key]))
    else: term_key='terms'
    ax.plot([int(r[term_key]) for r in rr],[100*float(r['error_over_sector7']) for r in rr],marker+'-',label=r'$\phi='+phi+'$')
ax.axhline(0,linestyle=':',linewidth=1)
finish(fig,ax,'endpoint_stability','Perturbative truncation order',r'Post-$\Lambda^8$ error / sector 7 (%)')

# Determinant residual hierarchy, all data retained including first lateral sector.
with (DATA/'determinant_thermal/determinant_comparison.csv').open() as f: det=list(csv.DictReader(f))
# Derive from the canonical resummation record to avoid ambiguity in CSV names.
dj=read(DATA/'determinant_thermal/resum_det_Q.9_T154_phi.45_nodes512.json')
# More flexible record inspection, used only to get documented keys.
if 'rows' in dj: drows=dj['rows']
elif 'sectors' in dj: drows=dj['sectors']
else: drows=dj.get('results',[])
# Numeric tables below are sourced from CSV (schema inspected once).
fig,ax=start()
# Actual schema exported by original comparison script.
ns=[]; rs=[]; ps=[]
for r in det:
    n=int(r['Lambda_power'])
    if n>=4 and r['Pade_terms']=='154':
        ns.append(n)
        kr='exact_minus_previous_real_sum'
        kp='predicted_sector_real'
        rs.append(abs(float(r[kr]))); ps.append(abs(float(r[kp])))
ax.semilogy(ns,rs,'o-',label='Exact remainder')
ax.semilogy(ns,ps,'s--',label='Predicted determinant sector')
ax.set_xticks(ns)
finish(fig,ax,'determinant_sectors','Exponential sector $n$',r'Absolute contribution to $\log F$, $Q=0.9$')

# Exact boundary reconstruction.
g=read(DATA/'spectral_reconstruction/goursat_reconstruction.json')
fig,ax=start()
for Q,marker in [('0.9','o'),('2.0','s')]:
    rr=g[Q]['table']; target=mp.mpf(str(g[Q]['independent_D']))
    ax.loglog([r['N'] for r in rr],[float(abs(mp.mpf(str(r['D_from_boundary']))-target)) for r in rr],marker+'-',label=f'$Q={Q}$, raw')
    r2=[r for r in rr if 'Richardson_D' in r]
    ax.loglog([r['N'] for r in r2],[float(abs(mp.mpf(str(r['Richardson_D']))-target)) for r in r2],marker+'--',label=f'$Q={Q}$, extrapolated')
finish(fig,ax,'goursat_convergence','Characteristic-grid size $N$',r'Error in reconstructed $D$')

sp=read(DATA/'spectral_reconstruction/gap_log_correction.json')
fig,ax=start()
for j,marker in enumerate(['o','s','^','D']):
    ax.semilogx([r['Q'] for r in sp['results']],[r['Qgap_extrapolated'][j]/sp['target'][j] for r in sp['results']],marker+'-',label=f'Mode {j+1}')
ax.axhline(1,linestyle=':',label='Fractional-Laplacian limit')
finish(fig,ax,'spectral_gaps','$Q$',r'$Q(1-\mu_{j-1})/\lambda_j$')
fig,ax=start()
for j,marker in enumerate(['o','s','^','D']):
    ax.semilogx([r['Q'] for r in sp['results']],[r['finite_constant_estimate'][j]/sp['target'][j] for r in sp['results']],marker+'-',label=f'Mode {j+1}')
finish(fig,ax,'spectral_logarithm','$Q$',r'$[Q(\lambda_j-Q\delta_j)-\lambda_j\log Q/(2\pi)]/\lambda_j$')

spec=read(DATA/'spectral_reconstruction/deformed_determinant.json')
fig,ax=start()
for order,marker in [(10,'o'),(14,'s')]:
    rr=[r for r in spec if r['order']==order]
    ax.semilogx([r['Q'] for r in rr],[r['trace_B2'] for r in rr],marker+'-',label=f'Panel quadrature order {order}')
val=float((2+7*mp.zeta(3))/mp.pi**2)
ax.axhline(val,linestyle='--',label=r'$(2+7\zeta(3))/\pi^2$')
finish(fig,ax,'spectral_trace','$Q$',r'$\mathrm{Tr}\, B_Q^2$')

therm=read(DATA/'determinant_thermal/thermo_subtracted.json')
can=read(DATA/'spectral_reconstruction/canonical_thermal.json')
fig,ax=start()
tr=[r for r in therm if r['Q']==.9 and r['n']==80]
tr.sort(key=lambda r:r['T'])
ax.plot([r['T']**2 for r in tr],[r['omega_T4_estimate']-r['predicted_T4'] for r in tr],'o-',label='Fixed chemical potential')
cr=sorted(can['0.9']['thermal'],key=lambda r:r['T'])
ax.plot([r['T']**2 for r in cr],[r['canonical_T4_measured']-r['canonical_T4_prediction'] for r in cr],'s-',label='Fixed density')
ax.axhline(0,linestyle=':',linewidth=1)
ax.ticklabel_format(axis='x',style='sci',scilimits=(0,0))
finish(fig,ax,'thermal_quartic','$T^2$',r'Quartic estimator minus predicted $T\to0$ value')

hd=read(DATA/'spectral_reconstruction/high_density_thermal.json')
fig,ax=start()
rr=[r for r in hd if r['Q']>=4]
ax.plot([1/r['Q'] for r in rr],[r['omega_T4']/r['Q']**3 for r in rr],'o-',label='Zero-temperature endpoint formula')
ax.axhline(-math.pi**3/360,linestyle='--',label=r'$-\pi^3/360$')
finish(fig,ax,'thermal_high_density','$1/Q$',r'$b_{\mathrm{grand}}(Q)/Q^3$')

# TeX numerical tables, generated from high-precision strings.
def sci(x,d=8):
    x=mp.mpf(x)
    if x==0: return '$0$'
    e=int(mp.floor(mp.log10(abs(x)))); m=x/mp.power(10,e)
    return '$'+mp.nstr(m,d)+r'\times10^{'+str(e)+'}$'
for obs in ['D','rho']:
    text=[]
    for r in summary:
        if r['observable']==obs and int(r['n'])>=3:
            text.append(f"{r['n']} & {sci(r['remainder'])} & {sci(r['prediction'])} & {mp.nstr(mp.mpf(r['ratio']),9)}" + (r'\,\textit{(unresolved)}' if r['n']==8 else '')+r' \\')
    (TAB/('endpoint_'+obs+'.tex')).write_text('\n'.join(text)+'\n')
with (ROOT/'data/endpoint_recomputed.csv').open('w') as f:
    wr=csv.DictWriter(f,fieldnames=summary[0].keys()); wr.writeheader(); wr.writerows(summary)

# Validation of figure outputs.
for p in FIG.glob('*.pdf'):
    assert p.stat().st_size>5000,p
print('Generated',len(list(FIG.glob('*.pdf'))),'figures in',FIG)
