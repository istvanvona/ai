"""Run the three independent fast suites in their expected working directories."""
from pathlib import Path
import subprocess,sys,time,json
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/"audit"/"portable_checks";out.mkdir(parents=True,exist_ok=True)
status={}
for name in ("endpoint","determinant_thermal","spectral_reconstruction"):
    start=time.monotonic()
    result=subprocess.run([sys.executable,"run_checks.py"],cwd=ROOT/"reproducibility"/name/"code",stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (out/(name+".txt")).write_text(result.stdout)
    status[name]={"returncode":result.returncode,"elapsed_seconds":time.monotonic()-start}
    print(name+": "+("PASS" if result.returncode==0 else "FAIL"),flush=True)
    if result.returncode:
        print(result.stdout)
        (out/"status.json").write_text(json.dumps(status,indent=2))
        raise SystemExit(result.returncode)
(out/"status.json").write_text(json.dumps(status,indent=2))
print("All three reproducibility suites passed.")
