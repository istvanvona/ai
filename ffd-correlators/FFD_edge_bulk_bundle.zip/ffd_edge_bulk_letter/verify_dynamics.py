"""Independent audit against sparse commutator evolution (not a fast solver).

Run: python verify_dynamics.py > validation_dynamics.json
The exponential ordered-word basis is used ONLY as an independent small-M check.
"""
import json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import expm_multiply
from ffd_correlators import clique_correlators

def exact_all(b,times):
    b=np.asarray(b); M=len(b); dim=1<<M; rows=[]; cols=[]; vals=[]
    for mask in range(dim):
      for i in range(M):
        neigh=sum(1<<j for j in range(max(0,i-2),min(M,i+3)) if j!=i)
        if (mask&neigh).bit_count()%2:
          lower=sum(1<<j for j in range(max(0,i-2),i))
          sign=(-1)**((mask&lower).bit_count()%2)
          rows.append(mask^(1<<i)); cols.append(mask); vals.append(2j*b[i]*sign)
    L=coo_matrix((vals,(rows,cols)),shape=(dim,dim)).tocsr()
    init=np.zeros((dim,min(M,3)),complex)
    for k in range(1,min(M,3)+1):
      for i in range(k): init[1<<i,k-1]=b[i]
    out=[]
    for t in times:
      evolved=expm_multiply(t*L,init,traceA=0.)
      out.append(evolved[[1<<i for i in range(M)],:].T*b[None,:])
    return out



def main():
    rng=np.random.default_rng(23117)
    worst=0.0
    comparisons=0
    times=[0.0,0.13,0.7,1.9]
    for M in range(2,13):
        for case in ["uniform","affine","random_signed"]:
            if case == "uniform":
                b=np.ones(M)
            elif case == "affine":
                b=1+0.17*np.arange(M)
            else:
                b=rng.uniform(0.6,1.5,M)*rng.choice([-1,1],M)
            exact=exact_all(b,times)
            for it,t in enumerate(times):
                for k in range(1,min(M,3)+1):
                    result=clique_correlators(b,k,t)
                    err=float(np.max(abs(result-exact[it][k-1])))
                    worst=max(worst,err)
                    comparisons+=M
                    if err > 1e-8:
                        raise AssertionError((M,case,k,t,err))
    print(json.dumps({
        "M_min":2,"M_max":12,"times":times,"seed":23117,
        "coupling_families":["uniform","affine","random_signed"],
        "scalar_comparisons":comparisons,
        "max_absolute_error":worst,
        "numpy_version":np.__version__,
        "status":"PASS"
    },indent=2))

if __name__ == "__main__":
    main()
