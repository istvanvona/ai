"""Reference evaluation of the scalar FFD edge--bulk formulas.

Conventions and derivation: ffd_edge_bulk_letter.pdf, Eqs. (19), (24),
(27)--(34). Requires NumPy. No spin matrices or induced paths are enumerated.
The arithmetic algorithm is polynomial; this implementation does not provide
certified precision or a stable large-M polynomial-root solver.
"""
from __future__ import annotations
import numpy as np
from numpy.polynomial import Polynomial as Poly

def interval(B,a,b):
    # one-based inclusive interval
    prev=[Poly([1.]),Poly([1.]),Poly([1.])]
    for m in range(a,b+1):
        p=prev[-1]-Poly([0.,B[m-1]])*prev[-3]
        prev=prev[1:]+[p]
    return prev[-1]

def paths(k,M,y,B):
    R=np.zeros(M+1,dtype=np.result_type(y,float)); A=R.copy(); D=R.copy()
    R[1:k+1]=1
    for m in range(k+1,M+1):
        D[m]=-y*B[m-3]*R[m-2] if m>=3 else 0
        A[m]=-y*B[k-1] if m==k+1 else (y*y*B[m-4]*B[m-2]*R[m-3] if m>=4 else 0)
        R[m]=A[m]+D[m]
    return R,A,D

def clique_correlators(b, k: int, t: float) -> np.ndarray:
    """Return <(h_1+...+h_k)(t) h_j>_infinity for j=1,...,M.

    k is one-based and must be 1, 2 or 3 (and no greater than M).
    b contains the real nonzero couplings; output index j-1 corresponds to h_j.
    Small imaginary roundoff is retained to make numerical diagnostics possible.
    This straightforward double-precision reference code is intended for modest
    system sizes, not highly ill-conditioned polynomial root problems.
    """
    b = np.asarray(b, dtype=float)
    if b.ndim != 1 or b.size == 0 or not np.all(np.isfinite(b)):
        raise ValueError("b must be a nonempty finite real one-dimensional array")
    if not isinstance(k, (int, np.integer)) or not 1 <= k <= min(3, len(b)):
        raise ValueError("k must be an integer between 1 and min(3, M)")
    if np.any(b == 0) or not np.isfinite(t):
        raise ValueError("Couplings must be nonzero and time must be finite")
    B=b*b; M=len(B)
    if not np.all(np.isfinite(B)) or np.any(B == 0):
        raise FloatingPointError("Squared couplings overflowed or underflowed")
    P=interval(B,1,M)
    raw_roots=P.roots()
    if np.any(np.abs(raw_roots.imag) > 1e-9*(1+np.abs(raw_roots.real))):
        raise FloatingPointError("Root computation lost reality; use higher precision")
    roots=np.sort(raw_roots.real)
    if np.any(roots <= 0) or not np.all(np.isfinite(roots)):
        raise FloatingPointError("Root computation lost positivity; use higher precision")
    u=np.r_[np.sqrt(roots),-np.sqrt(roots)]; ep=1/u; dp=P.deriv()(u*u)
    result=np.zeros(M,complex)
    tails={j:interval(B,j,M)(u*u) for j in range(1,M+4)}
    Q=tails[k+1]
    for s,us in enumerate(u):
      for r,ur in enumerate(u):
        R,A,D=paths(k,M,us*ur,B)
        fac=(np.exp(2j*(ep[s]+ep[r])*t)-np.exp(2j*ep[s]*t))/(4*us**3*ur**2*dp[s]*dp[r])
        for j in range(1,M+1):
          L=tails[j+3]
          if j<=k:
            K=B[j-1]*(us*L[s]*Q[r]-ur*Q[s]*L[r])
          else:
            C1=tails[j+2]; C2=tails[j+1]
            K=B[j-1]*(D[j]*(us*L[s]*C2[r]-ur*C2[s]*L[r])+A[j]*(us*L[s]*C1[r]-ur*C1[s]*L[r]))
          result[j-1]+=K*fac
      for j in range(1,k+1):
        result[j-1]+=-B[j-1]*tails[j+3][s]*np.exp(2j*ep[s]*t)/(2*us*us*dp[s])
    return result


def edge_correlators(b, edge: int, t: float, side: str = "left") -> np.ndarray:
    """Return all <h_i(t) h_j> with i=edge or i=M-edge+1.

    edge=1,2,3 counts inward from the chosen side. Targets are returned in
    original left-to-right order. Divide entry j-1 by b[i-1]*b[j-1] for g_i,g_j.
    """
    if side not in ("left", "right"):
        raise ValueError("side must be 'left' or 'right'")
    b = np.asarray(b, dtype=float)
    if side == "right":
        return edge_correlators(b[::-1], edge, t, "left")[::-1]
    result = clique_correlators(b, edge, t)
    if edge > 1:
        result -= clique_correlators(b, edge-1, t)
    return result
