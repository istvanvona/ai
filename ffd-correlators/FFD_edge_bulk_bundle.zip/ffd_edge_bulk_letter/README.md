# From edge to bulk in free fermions in disguise

An eight-page, single-column expository letter, prepared from the supplied inverse-problem calculations. The main text contains the derivations and four vector diagrams; there is no supplementary mathematical section. Author: Istvan Vona. Dated 10 November 2026.

## Files

- `ffd_edge_bulk_letter.pdf`: typeset manuscript.
- `ffd_edge_bulk_letter.tex`: self-contained LaTeX, including the bibliography and all TikZ figures.
- `ffd_correlators.py`: reference implementation of the scalar correlator formulas.
- `verify_dynamics.py`: independent comparison against sparse commutator evolution.
- `verify_algebra.py`: exact-integer checks of the path and overlap identities.
- `validation_dynamics.json`, `validation_algebra.json`: actual outputs from the included verification scripts.
- `requirements.txt`, `environment.txt`: Python dependencies and the versions used for the checks.

The verification code is not a dependency of the analytic proof. The exponential direct-evolution calculation is used only as an independent small-system audit; the correlator evaluator itself uses polynomial recurrences and finite mode sums.

## Build and run

A normal TeX Live installation with `newtx`, `tikz`, `amsmath`, `mathtools`, `microtype`, `titlesec`, `fancyhdr`, and `hyperref` is sufficient. No external figure assets or bibliography processor are needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error ffd_edge_bulk_letter.tex
pdflatex -interaction=nonstopmode -halt-on-error ffd_edge_bulk_letter.tex

python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python verify_dynamics.py
python verify_algebra.py
```

`OPENBLAS_NUM_THREADS=1` is optional and makes the small-matrix audit reproducible without unnecessary multithreading. Python 3.10 or newer is recommended. The exact-algebra script uses only the standard library.

## Evaluating a correlator

```python
import numpy as np
from ffd_correlators import edge_correlators, clique_correlators

b = np.ones(10)
t = 0.7

# Output entry j-1 is <h_3(t) h_j>_infinity.
left = edge_correlators(b, edge=3, t=t)
print(left[5])  # <h_3(t) h_6>_infinity

# Third generator inward from the right: h_8 for M=10.
# Output targets remain in original left-to-right order.
right = edge_correlators(b, edge=3, t=t, side="right")

# Sum of the first two generators as the source observable.
block = clique_correlators(b, k=2, t=t)
```

All generator labels in the mathematics and the `edge`/`k` arguments are one-based. NumPy output arrays are zero-based. Couplings must be finite, real, and nonzero. The observable convention is `h_j = b_j g_j`, not `g_j` alone. Divide the corresponding entry by `b[i-1]*b[j-1]` for a normalized-generator correlator. The trace is the full infinite-temperature spin trace, not a trace restricted to one symmetry sector.

This is transparent reference code in double precision, not a certified large-system solver. It checks root reality and positivity, but does not guarantee accurate roots for large M, extreme coupling ratios, or clustered roots. Such cases require a better-conditioned or higher-precision spectral calculation. Small imaginary roundoff is retained in the output. Zero-coupling and other singular limits are not implemented by direct substitution; the paper discusses continuity of the full correlator.

## Basis in the supplied calculations and substantive revisions

The manuscript follows the scalar path/interval-polynomial approach in `h1hM.tex`, `h1hj.tex`, `edge-edge.tex`, `edge-edge-clique.tex`, `edge-edge-clique-bulk.tex`, and the consolidated `bulk-edge.tex`. `inverseprob.tex` supplies overlapping background and conventions. These original files are not duplicated in this distribution.

The exposition is reorganized into the endpoint correlator, nested boundary-clique sources, and the two possible terminal configurations at a bulk target. The following changes are explicit rather than silent reconciliations of the notes:

1. **Normalization-free residues.** The source components are written as `F_s = -Xi(u_s)/(2 u_s^2 P'(u_s^2))`. This combines the normalized fermion with its source coefficient and cancels the source-normalization polynomial from the final correlator. `Xi` is defined by the path-product formula in the paper; raw transfer-product numerators in other conventions should not be compared without matching normalization.
2. **Stationary source components.** Their existence depends on the source clique, not on M alone. For k=1 the stationary part is present at M mod 3 = 0 or 2; for k=2 only at M mod 3 = 0; for k=3 it is absent. The final spectral weight always uses the same subtraction, which vanishes after summation when the stationary part is absent. Thus the formulas need no switch by congruence class.
3. **Near-boundary targets.** The direct-path initial condition `rho_(1,k+1) = -y B_k` is treated separately. This extends the bulk kernel to every j>k, including the first site after the three-generator boundary block, rather than imposing the safe but unnecessary separation j>=k+3.
4. **Targets within the source clique.** The empty-path/singleton overlap supplies a simple extra single-mode term. With it, differences of clique correlators cover every target, including boundary autocorrelations.
5. **Opposite boundary blocks.** Their first-hit formulas are presented as consequences of the bulk kernel, avoiding another independent derivation.

The speculative ancillary/quartic discussion in `hM3h4.md` is not included as a theorem or used in any proof. In particular, the paper does not claim a quadratic/quartic truncation for generic bulk densities, or a general polynomial algorithm for bulk-bulk correlators.

## What was actually verified

### Exact integer algebra

All allowed source sizes k=1,2,3 were tested for 1<=M<=18, with `B_j = 1 + ((j-1) mod 4)`. The recurrence was checked at y=-3 and y=2. Resolvent and overlap checks use u=2 and v=-3. Integer arithmetic is exact; these are parameter evaluations, not symbolic verification of all couplings.

- 102 path-recurrence checks against explicit induced-path sums.
- 51 resolvent-identity checks by graph-Clifford multiplication.
- 509 all-target overlap checks against the scalar kernel.
- 117 opposite-boundary-clique sum checks.

All 779 checks agree exactly. General validity is established by the analytic derivation, not by these finite evaluations.

### Independent dynamics

For 2<=M<=12, all allowed k and every target j were compared at t=0, 0.13, 0.7, and 1.9. Coupling families were uniform; `b_j = 1 + 0.17*(j-1)`; and random signed couplings with magnitudes sampled uniformly from [0.6,1.5], using NumPy generator seed 23117. The reference evolution acts directly on the ordered graph-Clifford-word basis and does not use polynomial roots, hidden modes, or path sums.

There are 2,748 scalar comparisons. The maximum observed absolute difference is `1.0419443138093346e-13`. This is a finite-size numerical consistency check, not an error bound for untested parameters.

## Literature and scope

The essential external input is Fukai, Pozsgay and Vona, *Solving models with generalized free fermions II: Path-product expansion and conserved charges*, arXiv:2605.31453v2, revised 31 August 2026. Its general path-product theorem is cited and specialized; its full graph-theoretic proof is not reproduced. The new exposition derives the density-overlap kernels explicitly from that identity.

The bibliography also covers Fendley's original chain; graph-theoretic solvability; Vona, Mestyán and Pozsgay's boundary dynamics; the circuit simulability work of Szász-Schagrin, Cristani, Piroli and Vernier; the Hilbert-space analysis by Vernier and Piroli; and the revised July 2026 correlation/quench paper by Szász-Schagrin, Bayona-Pena, Piroli and Vernier. The latter is cited as version 2, not its superseded version 1. Literature was checked through 10 November 2026.

The circuit matrix-product-operator approach supplies a related polynomial-contraction strategy; the paper therefore makes no claim to be the first observation of efficient boundary-observable simulation. It emphasizes the explicit scalar overlap reduction. No exhaustive novelty or priority claim is made.

The result concerns the open chain, real couplings, and the full infinite-temperature trace. It does not cover arbitrary initial states, finite-temperature correlators, or generic bulk-bulk pairs.
