"""Exact-integer audits of induced-path identities, independent of spectral roots.

Run: python verify_algebra.py > validation_algebra.json
Uses only the Python standard library; Python 3.10 or newer is recommended.
All checks are finite verification, not a substitute for the analytic proof.
"""
from collections import defaultdict
import json

def pval(B,a,b,x):
    p=[1,1,1]
    for m in range(a,b+1): p=p[1:]+[p[-1]-x*B[m-1]*p[-3]]
    return p[-1]

def enumerate_paths(M,k):
    out=[()]
    def extend(p):
        out.append(p)
        for j in range(p[-1]+1,min(M,p[-1]+2)+1):
            if j<=k: continue
            if len(p)>1 and j-p[-2]<=2: continue
            extend(p+(j,))
    for j in range(1,k+1): extend((j,))
    return out

def r_arrays(M,k,B,y):
    R=[0]*(M+1); a=[0]*(M+1); c=[0]*(M+1)
    R[1:k+1]=[1]*k
    for m in range(k+1,M+1):
        c[m]=-y*B[m-3]*R[m-2] if m>=3 else 0
        a[m]=-y*B[k-1] if m==k+1 else (y*y*B[m-4]*B[m-2]*R[m-3] if m>=4 else 0)
        R[m]=a[m]+c[m]
    return R,a,c

def mul(A,C,B,k):
    sign=1
    for i in range(len(B)+1):
      if not (A>>i)&1: continue
      for j in range(i):
        if not (C>>j)&1: continue
        adj=(i<=k) if j==0 else (i-j<=2)
        if adj: sign=-sign
    for i in range(1,len(B)+1):
      if ((A&C)>>i)&1: sign*=B[i-1]
    return A^C,sign

def xi(M,k,B,u):
    d={}
    for p in enumerate_paths(M,k):
      a=k+1 if not p else p[-1]+3
      mask=1+sum(1<<j for j in p)
      d[mask]=(-u)**len(p)*pval(B,a,M,u*u)
    return d

def kernel(M,k,j,B,u,v):
    R,a,c=r_arrays(M,k,B,u*v)
    Lu=pval(B,j+3,M,u*u); Lv=pval(B,j+3,M,v*v)
    if j<=k:
      return B[j-1]*(u*Lu*pval(B,k+1,M,v*v)-v*pval(B,k+1,M,u*u)*Lv)
    c1u=pval(B,j+2,M,u*u); c1v=pval(B,j+2,M,v*v)
    c2u=pval(B,j+1,M,u*u); c2v=pval(B,j+1,M,v*v)
    return B[j-1]*(c[j]*(u*Lu*c2v-v*c2u*Lv)+a[j]*(u*Lu*c1v-v*c1u*Lv))

if __name__=='__main__':
 stats={'resolvent_exact_checks':0,'kernel_exact_checks':0,'path_recurrence_exact_checks':0,'boundary_clique_exact_checks':0}
 for M in range(1,19):
  B=[1+(j%4) for j in range(M)]
  for k in range(1,min(M,3)+1):
   for y in [-3,2]:
    R,_,_=r_arrays(M,k,B,y); got=[0]*(M+1)
    for p in enumerate_paths(M,k):
     if p:
      weight=1
      for j in p[:-1]: weight*=-y*B[j-1]
      got[p[-1]]+=weight
    assert got==R,(M,k,y,got,R)
    stats['path_recurrence_exact_checks']+=1
   u,v=2,-3
   X=xi(M,k,B,u); Y=xi(M,k,B,v)
   # u [H,X]/2 = X - P chi
   lhs=defaultdict(int)
   for mask,w in X.items():
    for j in range(1,M+1):
     m,s=mul(1<<j,mask,B,k); _,r=mul(mask,1<<j,B,k)
     lhs[m]+=u*w*(s-r)//2
   rhs=defaultdict(int,X); rhs[1]-=pval(B,1,M,u*u)
   assert {a:w for a,w in lhs.items() if w}=={a:w for a,w in rhs.items() if w},(M,k)
   stats['resolvent_exact_checks']+=1
   for j in range(1,M+1):
    K=0
    for mask,coeff in X.items():
     other=mask^(1<<j)
     if other in Y:
      target,s=mul(mask,other,B,k); ident,r=mul(target,1<<j,B,k)
      assert ident==0
      K+=coeff*Y[other]*s*r
    assert K==kernel(M,k,j,B,u,v),(M,k,j,K,kernel(M,k,j,B,u,v))
    stats['kernel_exact_checks']+=1
   if M>=6:
    R,_,_=r_arrays(M,k,B,u*v)
    cal=[B[-1]*R[M],B[-2]*R[M-1]-u*v*B[-1]*B[-3]*R[M-2],B[-3]*R[M-2]-u*v*B[-2]*B[-4]*R[M-3]]
    for ell in [1,2,3]:
     assert sum(kernel(M,k,j,B,u,v) for j in range(M-ell+1,M+1))==(u-v)*cal[ell-1],(M,k,ell)
     stats['boundary_clique_exact_checks']+=1
 print(json.dumps(stats,indent=2))
