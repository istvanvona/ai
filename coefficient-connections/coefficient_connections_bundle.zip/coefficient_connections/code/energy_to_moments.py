"""Finite algebraic conversion of physical strong-coupling energy coefficients.
Uses the exact Lieb--Liniger Fermi-endpoint differential identity.
SymPy implementation intended for symbolic low/moderate orders.
"""
from __future__ import annotations
import sympy as sp

def energy_to_moments(energy_coefficients):
    e=[sp.sympify(x) for x in energy_coefficients]
    if not e or sp.simplify(e[0]-sp.pi**2/3)!=0:
        raise ValueError('Expected e(1/x)=pi**2/3+O(x).')
    nmax=len(e)-1
    s=[sp.pi]
    for n in range(1,nmax+1):
        rhs=sp.Rational((n+2)*(n+3),2)*e[n]
        s.append(sp.expand((rhs-sum(s[j]*s[n-j] for j in range(1,n)))/(2*sp.pi)))
    x,a=sp.symbols('x a')
    B=sum(s[n]*x**(n+1)/sp.Integer(n+1) for n in range(nmax+1))
    X=sp.S.Zero
    for n in range(1,nmax+2):
        already=sp.series(B.subs(x,X),a,0,n+1).removeO().expand().coeff(a,n)
        target=1 if n%2 else 0 # B(a)=a/(1-a^2)
        X+=sp.expand((target-already)/sp.pi)*a**n
    I0=sp.series(2*sp.pi*(1-a*a)*X/a,a,0,nmax+1).removeO().expand()
    E=sum(e[n]*X**n for n in range(nmax+1))
    I2=sp.series(E*I0**3/(4*sp.pi**2),a,0,nmax+1).removeO().expand()
    return {'B_of_x':sp.expand(B),'x_of_a':X,
            'I0':[sp.simplify(I0.coeff(a,n)) for n in range(nmax+1)],
            'I2':[sp.simplify(I2.coeff(a,n)) for n in range(nmax+1)]}

if __name__=='__main__':
    p=sp.pi
    e=[p*p/3,-4*p*p/3,4*p*p,-32*p*p*(15-p*p)/45,
       80*p*p/3-64*p**4/9]
    result=energy_to_moments(e)
    for key,value in result.items():print(key,':',value)
    import numpy as np
    from pathlib import Path
    data=np.load(Path(__file__).resolve().parents[1]/'data'/'conformal_4000_2048.npz')
    for key in ['I0','I2']:
        err=max(abs(float(sp.N(v,17))-data[key][n]) for n,v in enumerate(result[key]))
        print(key,'maximum error against independently generated coefficients:',err)
