"""Compare supplied coefficient datasets and check elementary invariants.

The comparison tests sensitivity to the quadrature node count, not a rigorous
roundoff bound. The 2020-node dataset is retained from the earlier notes; the
2048-node dataset was regenerated for the present manuscript.
"""
from __future__ import annotations
import hashlib
import json
import platform
from pathlib import Path
import numpy as np
import scipy
import sympy
import mpmath

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'


def main() -> None:
    paths = [DATA/'conformal_4000_2048.npz', DATA/'inherited_conformal_4000.npz']
    with np.load(paths[0]) as fresh, np.load(paths[1]) as inherited:
        assert int(fresh['order']) == int(inherited['order']) == 4000
        assert int(fresh['nodes']) == 2048 and int(inherited['nodes']) == 2020
        result = {}
        for key, bound in [('I0', 4.), ('I2', 12/5)]:
            b, old = fresh[key], inherited[key]
            assert b.ndim == 1 and b.size == 4001 and np.all(np.isfinite(b))
            assert np.max(np.abs(b)) < bound
            result[key] = {
                'max_coefficient_difference': float(np.max(np.abs(b-old))),
                'max_first_difference_difference': float(np.max(np.abs(np.diff(b-old)/2))),
                'max_absolute_coefficient': float(np.max(np.abs(b))),
                'proved_uniform_bound': bound,
            }
        assert np.isclose(fresh['I0'][0], 2.)
        assert np.isclose(fresh['I2'][0], 2/3)
    result.update(nodes_recomputed=2048, nodes_inherited=2020, order=4000)
    result['software'] = {'python': platform.python_version(), 'numpy': np.__version__,
                          'scipy': scipy.__version__, 'sympy': sympy.__version__,
                          'mpmath': mpmath.__version__}
    result['sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (DATA/'revalidation.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
