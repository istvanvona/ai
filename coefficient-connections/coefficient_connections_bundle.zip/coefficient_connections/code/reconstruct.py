"""Inverse-Laplace diagnostics from conformal coefficients only.

Actions are found by a continuous scan, not by imposing a multiple-of-pi lattice.
The finite-N amplitudes below are estimates with systematic truncation bias,
not certified interval bounds. The exact inverse is an infinite Abel-Laguerre sum.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.signal import find_peaks


def laguerre_inverse(b: np.ndarray, t: np.ndarray, r: float = 1.0) -> np.ndarray:
    """Inverse of M((w-1)/(w+1))/(w+1)^2, truncated at len(b)-1.
    With 0<r<1 this evaluates its Abel-regularized Laguerre expansion.
    """
    if not 0 < r <= 1:
        raise ValueError('Require 0 < r <= 1.')
    t = np.asarray(t, dtype=float)
    if np.any(t < 0):
        raise ValueError('The causal inverse has t >= 0.')
    q = np.diff(np.r_[0., np.asarray(b, dtype=float)]) / 2
    x = 2*t
    previous = np.zeros_like(t)
    current = np.ones_like(t)
    total = q[0]*current
    for n in range(1, len(q)):
        previous, current = current, ((2*n-1-x)*current-(n-1)*previous)/n
        total += q[n]*(r**n)*current
    return np.exp(-t)*total


def laguerre_inverse_derivative(b: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Differentiate the finite inverse exactly; not a stable infinite-data estimator.

    The derivative is useful for displaying finite-order resolution of a cusp.
    It must not be used as a certified singularity coefficient estimate.
    """
    t = np.asarray(t, dtype=float)
    b = np.asarray(b, dtype=float)
    if b.ndim != 1 or not len(b) or np.any(t < 0):
        raise ValueError('Require nonempty one-dimensional coefficients and t >= 0.')
    q = np.diff(np.r_[0., b]) / 2
    previous, current = np.zeros_like(t), np.ones_like(t)
    dprevious, dcurrent = np.zeros_like(t), np.zeros_like(t)
    total, derivative = q[0] * current, np.zeros_like(t)
    for n in range(1, len(q)):
        factor = 2*n - 1 - 2*t
        following = (factor*current - (n-1)*previous)/n
        dfollowing = (factor*dcurrent - 2*current - (n-1)*dprevious)/n
        previous, current = current, following
        dprevious, dcurrent = dcurrent, dfollowing
        total += q[n]*current
        derivative += q[n]*dcurrent
    return np.exp(-t)*(derivative-total)


def quadratures(b: np.ndarray, action: float, nmax: int,
                fraction: float = 0.15) -> tuple[float, float]:
    """Return C and R estimates for h(A+s)~C*s*log|s|+R*s_+.
    These refer to the total local singularity. Beyond the first action,
    lower-sector analytic continuations must be subtracted to isolate sectors.
    """
    if action <= 0 or not 20 <= nmax < len(b) or not 0 < fraction < 1:
        raise ValueError('Invalid action, coefficient count, or window fraction.')
    q = np.diff(np.r_[0., b])/2
    n = np.arange(max(20, int(fraction*nmax)), nmax+1)
    y = np.sqrt(n)
    x = (y-y[0])/(y[-1]-y[0])
    weight = np.sin(np.pi*x)**4/(2*y)
    phase = 2*np.sqrt(2*action*n)-np.pi/4
    design = np.column_stack([np.sin(phase), np.cos(phase), np.ones(len(n))])
    coefficients = np.linalg.lstsq(design*np.sqrt(weight)[:, None],
                                  q[n]*n**1.25*np.sqrt(weight), rcond=None)[0]
    C = coefficients[0]*2**.25/(np.sqrt(np.pi)*action**.75)
    R = -coefficients[1]*2**.25*np.sqrt(np.pi)/action**.75
    return float(C), float(R)


def spectral_power(b: np.ndarray, action: float, nmax: int) -> float:
    C, R = quadratures(b, action, nmax)
    return (C*C+(R/np.pi)**2)*action**1.5


def scan_actions(b: np.ndarray, nmax: int, interval=(.5, 16.), samples=1400):
    actions = np.linspace(*interval, samples)
    powers = np.array([spectral_power(b, a, nmax) for a in actions])
    candidates = find_peaks(powers)[0]
    candidates = candidates[np.argsort(powers[candidates])[-5:]][::-1]
    rows = []
    for j in candidates:
        fit = minimize_scalar(lambda a: -spectral_power(b, a, nmax),
                              bounds=(actions[j-1], actions[j+1]), method='bounded')
        rows.append({'action': float(fit.x), 'power': float(-fit.fun)})
    return actions, powers, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=Path(__file__).resolve().parents[1]/'data'/'conformal_4000_2048.npz')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1]/'data')
    parser.add_argument('--plots', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    b = np.load(args.input)['I0']
    N = len(b)-1
    actions, powers, peaks = scan_actions(b, N)
    convergence=[]
    for n in [400, 800, 1200, 2000, 3000, N]:
        if n>N: continue
        # Locate first peak within a bracket identified by the global scan.
        fit = minimize_scalar(lambda a: -spectral_power(b,a,n), bounds=(3.,3.3),method='bounded')
        C,R = quadratures(b, np.pi, n)
        convergence.append({'N':n, 'first_action':float(fit.x),
                            'C_at_A_pi':C, 'R_at_A_pi':R})
    results={'coefficient_order':N,'peaks':peaks,'convergence':convergence,
             'validation_target_C':float(1/(2*np.pi*np.e**2)),
             'note':'Targets are for comparison, not used to generate coefficients or scan actions. No certified errors.'}
    (args.output/'results.json').write_text(json.dumps(results,indent=2))
    np.savez(args.output/'action_spectrum.npz',actions=actions,power=powers)
    print(json.dumps(results,indent=2))
    if args.plots:
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(7.6,3.8))
        ax.semilogy(actions,powers)
        ax.set_xlabel('Trial action A in the inverse-Laplace variable')
        ax.set_ylabel('Windowed coefficient power')
        ax.set_ylim(1e-10,1e-2)
        fig.tight_layout();fig.savefig(args.output/'action_spectrum.pdf');plt.close(fig)
        t=np.linspace(.01,7,1800)
        fig,ax=plt.subplots(figsize=(7.6,3.8))
        for n in [400,1200,N]:
            ax.plot(t,laguerre_inverse(b[:n+1],t),label=f'{n} coefficients')
        ax.set_xlabel('Inverse-Laplace variable t');ax.set_ylabel('Reconstructed h(t)')
        ax.legend();fig.tight_layout();fig.savefig(args.output/'inverse_kernel.pdf');plt.close(fig)

if __name__=='__main__':main()
