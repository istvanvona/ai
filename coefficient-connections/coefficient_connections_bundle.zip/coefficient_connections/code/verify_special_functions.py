"""Independent symbolic and numerical checks for the revised connection note.
Requires sympy and mpmath. Run with: python code/verify_special_functions.py
"""
import sympy as sp
import mpmath as mp
mp.mp.dps = 60
results=[]
def check(name, lhs, rhs, tolerance=mp.mpf('1e-48')):
    error=abs(lhs-rhs)/max(1,abs(lhs),abs(rhs))
    assert error<tolerance, (name,error)
    results.append((name,mp.nstr(error,5)))

# Incomplete gamma: actual Laplace integral and two-sector connection formula.
for q in [mp.mpf('0.5'),mp.mpf('1.3'),mp.mpf('2.5')]:
    for z in [mp.mpf('0.03'),mp.mpf('0.4'),mp.mpf('2')]:
        exact=mp.exp(z)*z**(q-1)*mp.gammainc(1-q,z,mp.inf)
        local=mp.gamma(1-q)*z**(q-1)*mp.exp(z)+mp.hyp1f1(1,2-q,z)/(q-1)
        check(f'Gamma two sectors q={q}, z={z}',exact,local)
        integ=mp.quad(lambda p: mp.exp(-z*p)*(1+p)**(-q),[0,1,mp.inf])
        check(f'Gamma Laplace q={q}, z={z}',exact,integ)

# Master family, including an independent Laplace test.
a,b=mp.mpf(1)/6,mp.mpf(5)/6
for w in [mp.mpf('0.03'),mp.mpf('0.7'),mp.mpf('2')]:
    exact=w**a*mp.hyperu(a,1+a-b,w)
    local=mp.gamma(b-a)/mp.gamma(b)*w**a*mp.hyp1f1(a,1+a-b,w)+mp.gamma(a-b)/mp.gamma(a)*w**b*mp.hyp1f1(b,1+b-a,w)
    lap=w*mp.quad(lambda p:mp.exp(-w*p)*mp.hyp2f1(a,b,1,-p),[0,1,mp.inf])
    check(f'Master local w={w}',exact,local)
    check(f'Master Laplace w={w}',exact,lap)
    xi=w/2
    x=(3*xi/2)**(mp.mpf(2)/3)
    airy=2*mp.sqrt(mp.pi)*x**(mp.mpf(1)/4)*mp.exp(xi)*mp.airyai(x)
    check(f'Airy equals master w={w}',exact,airy)

# Symbolic Riccati expansions and recursions.
z,L=sp.symbols('z L')
p=[L]
for n in range(6):
    rhs=sp.expand(sum(p[k]*p[n-k] for k in range(n+1))-p[n])
    poly=sp.Integer(0)
    term=rhs
    for j in range(sp.degree(rhs,L)+1):
        poly+=term/sp.Integer(n+1)**(j+1)
        term=sp.diff(term,L)
    p.append(sp.expand(poly))
    assert sp.expand(sp.diff(p[-1],L)-(n+1)*p[-1]+rhs)==0
    assert sp.Poly(p[-1],L).LC()==1
    assert sp.degree(p[-1],L)==n+2
N=6
g=sum((-1)**(k+1)*z**k/(k*sp.factorial(k)) for k in range(1,N+1))
den=sum((-z)**k/sp.factorial(k) for k in range(N+1))-z*(L+g)
res=sp.Poly(sp.expand(den*sum(p[n]*z**n for n in range(N+1))-(L+g)),z)
assert all(res.coeff_monomial(z**n)==0 for n in range(N+1))
results.append(('Riccati local polynomials to n=6','exact'))

# Riccati coefficient recursion at infinity.
aco=[sp.Integer(1)]
for n in range(1,13):
    aco.append((-1)**n*sp.factorial(n)-sum((-1)**k*sp.factorial(k+1)*aco[n-k] for k in range(1,n+1)))
for n in range(1,len(aco)):
    if n==1:
        assert aco[n]==1
    else:
        assert sp.simplify(aco[n]+(n-1)*aco[n-1]+sum(aco[k]*aco[n-k] for k in range(1,n)))==0
results.append(('Riccati large coefficients to n=12','exact'))

for zz in [mp.mpf('0.07'),mp.mpf('0.8'),mp.mpf('2.3')]:
    for c in [mp.mpf('-0.3'),mp.mpf('0.2')]:
        E=mp.e1(zz)
        f=(c+E)/(mp.exp(-zz)-zz*(c+E))
        sigma=1/c
        Q=mp.exp(-zz)/zz-E
        trans=-1/zz-sigma*mp.exp(-zz)/(zz**2*(1-sigma*Q))
        check(f'Riccati exact trans-series identity z={zz}, c={c}',f,trans)

# Airy inverse-gamma coefficient conversion is exact at every checked order.
for aa in [sp.Rational(1,6),sp.Rational(5,6)]:
    for n in range(20):
        tail=sp.rf(aa,n)**2*(-2)**n/(sp.rf(2*aa,n)*sp.factorial(n))
        gamratio=(-1)**n/sp.rf(aa,n) # Gamma(1-a-n)/Gamma(1-a)
        target=2**n*sp.rf(aa,n)/(sp.rf(2*aa,n)*sp.factorial(n))
        assert sp.simplify(tail*gamratio-target)==0
results.append(('Airy Borel-tail kernel conversion through n=19','exact'))

# Riccati spectral density: moments and dispersion integral.
def rho_R(t):
    if not t:
        return mp.mpf(1)
    e=mp.exp(-t)
    return e/((1-t*e*mp.ei(t))**2+(mp.pi*t*e)**2)
for n,target in enumerate([1,2,8,44,296,2312]):
    integral=mp.quad(lambda t:t**n*rho_R(t),[0,1,5,20,80,200])
    check(f'Riccati density moment n={n}',integral,mp.mpf(target))
for z in [mp.mpf('0.1'),mp.mpf('1'),mp.mpf('5')]:
    G=mp.exp(z)*mp.e1(z)
    exact=G/(1-z*G)-1
    integ=mp.quad(lambda t:rho_R(t)/(z+t),[0,1,5,20,80,200])
    check(f'Riccati Stieltjes formula z={z}',exact,integ)

# Airy self-density identity: t=u^6 removes the integrable endpoint singularity.
a,b=mp.mpf(1)/6,mp.mpf(5)/6
Phi=lambda t:t**a*mp.hyperu(a,2*a,t)
for w in [mp.mpf('0.2'),mp.mpf('1'),mp.mpf('3')]:
    integrand=lambda u: 6*mp.exp(-u**6)*Phi(u**6)/(2*mp.pi*u*(w+u**6))
    val=mp.quad(integrand,[0,1,2,3])
    check(f'Airy self-density w={w}',Phi(w)/w,val)

for name,error in results:
    print(f'{name}: {error}')
print(f'ALL {len(results)} CHECKS PASSED')
print('Riccati p3 =',p[3])
print('Riccati a0,...,a7 =',aco[:8])
