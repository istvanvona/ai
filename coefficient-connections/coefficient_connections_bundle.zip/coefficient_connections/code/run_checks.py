"""Run the manuscript's reproducible checks using the included coefficient data.

Use --regenerate to generate a fresh 4000-order, 2048-node dataset first.
Use --figures to repeat direct integral-equation solves and remake the figures.
Failures propagate as a nonzero process exit code. No internet access is used.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def run(script: str, report: str, *arguments: str) -> None:
    env = os.environ.copy()
    env['OPENBLAS_NUM_THREADS'] = '1'
    env['MPLBACKEND'] = 'Agg'
    process = subprocess.run([sys.executable, str(ROOT/'code'/script), *arguments],
                             cwd=ROOT, env=env, text=True, capture_output=True)
    output = process.stdout
    if process.stderr:
        output += '\nSTDERR:\n'+process.stderr
    (ROOT/'data'/report).write_text(output)
    if process.returncode:
        print(output, file=sys.stderr)
        raise subprocess.CalledProcessError(process.returncode, process.args)
    print(f'PASS  {script} -> data/{report}', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regenerate', action='store_true')
    parser.add_argument('--figures', action='store_true')
    args = parser.parse_args()
    (ROOT/'data').mkdir(exist_ok=True)
    if args.regenerate:
        run('generate_coefficients.py', 'generation_log.txt')
    for script, report in [
        ('verify_dataset.py', 'dataset_checks.txt'),
        ('verify_special_functions.py', 'special_function_checks.txt'),
        ('energy_to_moments.py', 'energy_conversion_checks.txt'),
        ('lang_blocks.py', 'lang_checks.txt'),
        ('test_inverse.py', 'toy_inverse_checks.txt'),
        ('reconstruct.py', 'reconstruction_checks.txt'),
    ]:
        run(script, report)
    if args.figures:
        run('make_figures.py', 'figure_checks.txt')
    print('All requested checks completed successfully.')


if __name__ == '__main__':
    main()
