"""Recompute continuation checks and vector figures for the manuscript.
No fitted weak-coupling values are used by the coefficient generator.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.special import roots_legendre
from scipy.linalg import solve
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reconstruct import laguerre_inverse, laguerre_inverse_derivative

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'
FIG = ROOT/'figures'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size': 10, 'axes.labelsize': 10,
                     'legend.fontsize': 9, 'pdf.fonttype': 42,
                     'axes.spines.top': False, 'axes.spines.right': False})


def save(fig, name):
    fig.tight_layout(pad=0.8)
    fig.savefig(FIG/(name+'.pdf'), bbox_inches='tight')
    fig.savefig(FIG/(name+'.png'), dpi=180, bbox_inches='tight')
    plt.close(fig)


def direct(alpha: float, nodes: int):
    x, weight = roots_legendre(nodes)
    kernel = alpha/(np.pi*(alpha*alpha+(x[:, None]-x[None, :])**2))
    u = solve(np.eye(nodes)-kernel*weight[None, :], np.ones(nodes),
              check_finite=False)
    i0 = float(weight@u)
    i2 = float((weight*x*x)@u)
    return i0, i2, 2*np.pi*alpha/i0, 4*np.pi**2*i2/i0**3


def main():
    coeff = np.load(DATA/'conformal_4000_2048.npz')
    b = coeff['I0']
    result = json.loads((DATA/'results.json').read_text())
    scan = np.load(DATA/'action_spectrum.npz')
    fig, ax = plt.subplots(figsize=(6.4,3.25))
    ax.semilogy(scan['actions'], scan['power'], linewidth=1.3)
    for k in range(1,6):
        ax.axvline(k*np.pi, linestyle=':', linewidth=.8)
        ax.text(k*np.pi, 4.5e-3, r'$\pi$' if k==1 else rf'${k}\pi$',
                ha='center', va='bottom', fontsize=9)
    ax.set(xlabel=r'Trial action $A$', ylabel='Windowed coefficient power',
           xlim=(.5,16), ylim=(1e-10,1.6e-2))
    save(fig,'action_spectrum')

    fig, ax = plt.subplots(figsize=(6.4,3.25))
    t=np.linspace(.01,7,2000)
    for n, line in [(400,':'),(1200,'--'),(4000,'-')]:
        ax.plot(t,laguerre_inverse(b[:n+1],t),line,label=rf'$N={n}$',lw=1.25)
    for k in [1,2]:
        ax.axvline(k*np.pi,ls=':',lw=.7)
    ax.set(xlabel=r'Inverse-Laplace variable $t$',ylabel=r'Truncated inverse $h_N(t)$',xlim=(0,7))
    ax.legend(frameon=False)
    save(fig,'inverse_kernel')

    conv=result['convergence']
    fig,ax=plt.subplots(figsize=(6.4,2.8))
    ns=np.array([v['N'] for v in conv]); cs=np.array([v['C_at_A_pi'] for v in conv])
    ax.plot(ns,cs,'o-',label='Leading-quadrature estimate')
    ax.axhline(result['validation_target_C'],ls='--',label=r'Reference $1/(2\pi e^2)$')
    ax.set(xlabel=r'Coefficient order $N$',ylabel=r'First logarithmic strength $C$')
    ax.legend(frameon=False,loc='best')
    save(fig,'strength_convergence')

    tzoom = np.linspace(2.55, 3.75, 1600)
    fig, ax = plt.subplots(figsize=(6.4, 3.1))
    for n, ls in [(400, ':'), (1200, '--'), (4000, '-')]:
        ax.plot(tzoom, laguerre_inverse_derivative(b[:n+1], tzoom),
                ls=ls, lw=1.25, label=rf'$N={n}$')
    ax.axvline(np.pi, lw=.75, ls=':')
    ax.set(xlabel=r'Inverse-Laplace variable $t$',
           ylabel=r'Derivative of finite inverse $h_N^{\prime}(t)$')
    ax.legend(frameon=False, loc='lower left')
    save(fig, 'threshold_resolution')

    records=[]
    for alpha in [0.5,0.2,0.1,0.05]:
        lo=direct(alpha,512); hi=direct(alpha,768)
        a=2/(np.sqrt(alpha*alpha+4)+alpha)
        energy=[]
        for n in [100,200,400]:
            i0=np.polynomial.polynomial.polyval(a,coeff['I0'][:n+1])
            i2=np.polynomial.polynomial.polyval(a,coeff['I2'][:n+1])
            e=4*np.pi**2*i2/i0**3
            energy.append({'N':n, 'relative_error':float(abs(e/hi[3]-1))})
        records.append({'alpha':alpha,'a':float(a),'gamma':hi[2], 'energy':hi[3],
                        'reference_change_512_768':abs(hi[3]-lo[3]),'errors':energy})
    (DATA/'continuation_recheck.json').write_text(json.dumps(records,indent=2))
    fig, ax = plt.subplots(figsize=(6.4,3.25))
    for rec in records[1:]:
        alpha=rec['alpha']; a=rec['a']; exact=rec['energy']
        counts=np.arange(20,401,5)
        errors=[]
        for n in counts:
            i0=np.polynomial.polynomial.polyval(a,coeff['I0'][:n+1])
            i2=np.polynomial.polynomial.polyval(a,coeff['I2'][:n+1])
            e=4*np.pi**2*i2/i0**3
            errors.append(abs(e/exact-1))
        ax.semilogy(counts,errors,label=rf'$\alpha={alpha}$',lw=1.4)
    ax.set(xlabel=r'Truncation order $N$',ylabel='Relative energy error',ylim=(1e-13,1))
    ax.legend(frameon=False)
    save(fig,'continuation_error')
    print(json.dumps(records,indent=2))

if __name__=='__main__':
    main()
