"""Exact symbolic construction of the first five Lang regrouping polynomials."""
import sympy as s
import json, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]/'data'
OUT.mkdir(exist_ok=True)
x, r, gamma = s.symbols('x r gamma')
N=5

def integ(poly):
    poly=s.Poly(s.expand(poly),x)
    return s.expand(sum(c*(s.Rational(2,k[0]+1) if k[0]%2==0 else 0) for k,c in poly.terms()))

def P(poly,m):
    # integral (x-y)**(2m)*poly(y) dy
    return s.expand(sum(s.binomial(2*m,k)*(-1)**k*x**(2*m-k)*integ(x**k*poly) for k in range(2*m+1)))

def mul(a,b,n):
    return [s.expand(sum(a[j]*b[k-j] for j in range(max(0,k-len(b)+1),min(k,len(a)-1)+1))) for k in range(n+1)]

def power(a,p,n):
    b=[s.Integer(1)]+[s.Integer(0)]*n
    for _ in range(p): b=mul(b,a,n)
    return b

T=[s.Integer(1)]; w=[s.Rational(1,2)]
for n in range(1,N+1):
    v=s.Integer(0)
    for m in range(1,n+1):
        tp=power(T,2*m+1,n-m)
        v+= r*(-1)**m*sum(tp[n-m-j]*P(w[j],m) for j in range(n-m+1))
    v=s.expand(v)
    tn=-integ(v)
    T.append(tn); w.append(s.expand(v+tn/2))
    print('n',n,'Tn',s.factor(tn),flush=True)
C=mul(power(T,2,N),[integ(x*x*a) for a in w],N)
for n,c in enumerate(C):
    en=s.factor((c/r**n).subs(r,1/(gamma+2)))
    print('C',n,s.factor(c),'E',en,flush=True)
with open(OUT/'blocks.txt','w') as f:
    for n,c in enumerate(C):
        f.write(f'C{n} = {s.factor(c)}\nE{n} = {s.factor((c/r**n).subs(r,1/(gamma+2)))}\n')
with open(OUT/'blocks.json','w') as f: json.dump([str(s.factor((c/r**n).subs(r,1/(gamma+2)))) for n,c in enumerate(C)],f,indent=2)
