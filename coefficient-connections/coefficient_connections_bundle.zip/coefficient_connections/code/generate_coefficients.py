"""Generate strong-origin conformal coefficients for the Love--Lieb equation.

The rational kernel gives an O(N M^2) recurrence. With an even number M of
Gauss nodes at least (N+3)//2, all required polynomial integrations are exact
in exact arithmetic. This implementation uses floating point, not interval
arithmetic. No weak-coupling coefficients or transseries data are used.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import argparse
import time
from pathlib import Path
import numpy as np
from scipy.special import roots_legendre


def generate(order: int, nodes: int, output: Path):
    if order < 1 or nodes % 2 or nodes < (order+3)//2:
        raise ValueError('Require order >= 1 and even nodes >= (order+3)//2.')
    xx, ww = roots_legendre(nodes)
    x, weight = xx[nodes//2:], ww[nodes//2:]
    m = len(x)
    twice_s_minus = 2-(x[:, None]-x[None, :])**2
    twice_s_plus = 2-(x[:, None]+x[None, :])**2
    history_minus = np.zeros((4, m, m))
    history_plus = np.zeros_like(history_minus)
    values = np.zeros((4, m)); values[0] = 1
    I0 = np.zeros(order+1); I0[0] = 2
    I2 = np.zeros(order+1); I2[0] = 2/3
    kernel_weight = weight/np.pi
    start = time.time()
    output = Path(output)
    output.parent.mkdir(exist_ok=True, parents=True)
    for n in range(1, order+1):
        source = values[(n-1) % 4]-(values[(n-3) % 4] if n >= 3 else 0)
        new_minus = (source[None, :]+twice_s_minus*history_minus[(n-2) % 4]
                     -history_minus[n % 4])
        new_plus = (source[None, :]+twice_s_plus*history_plus[(n-2) % 4]
                    -history_plus[n % 4])
        history_minus[n % 4], history_plus[n % 4] = new_minus, new_plus
        values[n % 4] = (new_minus+new_plus) @ kernel_weight
        I0[n] = (2*weight) @ values[n % 4]
        I2[n] = (2*weight*x*x) @ values[n % 4]
        if n % 500 == 0:
            np.savez(output, I0=I0[:n+1], I2=I2[:n+1], order=n, nodes=nodes)
            print(f'Order {n}: elapsed {time.time()-start:.2f}s', flush=True)
    np.savez(output, I0=I0, I2=I2, order=order, nodes=nodes)
    return I0, I2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--order', type=int, default=4000)
    parser.add_argument('--nodes', type=int, default=2048)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).resolve().parents[1]/'data'/'conformal_4000_2048.npz')
    args = parser.parse_args()
    generate(args.order, args.nodes, args.output)
