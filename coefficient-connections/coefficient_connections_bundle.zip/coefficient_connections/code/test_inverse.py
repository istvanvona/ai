"""Independent exact-function checks of the inverse transform and normalization."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad
from scipy.special import eval_laguerre, expi
from reconstruct import laguerre_inverse, quadratures


def toy_coefficients(order: int, action: float, C: float, R: float):
    """M(w)=-C exp(-A w) Ei(A w)+R exp(-A w), a=(w-1)/(w+1)."""
    f = np.zeros(order+1)
    f[0] = np.exp(-action)*expi(action)
    for n in range(order):
        forcing = 2. if n == 0 else 4.*(-1.)**n
        f[n+1]=(forcing-(2*action-2*n)*f[n]-(n-1)*(f[n-1] if n else 0))/(n+1)
    n=np.arange(order+1)
    ell=eval_laguerre(n,2*action)
    exponential=np.exp(-action)*(ell-np.r_[0.,ell[:-1]])
    return -C*f+R*exponential


def toy_inverse(t, action, C, R):
    t=np.asarray(t)
    s=t-action
    if np.any(s==0):
        raise ValueError('Choose test points away from the threshold.')
    return -C*(1-np.exp(-t)+s*np.exp(-s)*(expi(-action)-expi(s)))+R*(s>0)*s*np.exp(-s)


def main():
    errs=[]
    for n in [0,1,2,5,10]:
        for w in [1.2,2.,4.]:
            got=quad(lambda t:np.exp(-(w+1)*t)*eval_laguerre(n,2*t),0,np.inf,
                     epsabs=2e-13,epsrel=2e-13)[0]
            exact=(w-1)**n/(w+1)**(n+1)
            errs.append(abs(got-exact))
    A,C,R=2.3,.017,.011
    points=np.array([.15,.5,1.,1.7,2.,2.6,3.,4.,5.])
    b=toy_coefficients(4000,A,C,R)
    exact=toy_inverse(points,A,C,R)
    rows=[]
    for N in [200,800,2000,4000]:
        error=float(np.max(np.abs(laguerre_inverse(b[:N+1],points)-exact)))
        c,r=quadratures(b,A,N)
        rows.append({'N':N,'max_pointwise_error_away_from_threshold':error,
                     'C_estimate':c,'R_estimate':r})
    result={'laplace_basis_max_error':max(errs),'toy_input':{'A':A,'C':C,'R':R},'toy_results':rows}
    assert max(errs)<1e-11
    assert rows[-1]['max_pointwise_error_away_from_threshold']<2e-4
    assert abs(rows[-1]['C_estimate']-C)<.002
    assert abs(rows[-1]['R_estimate']-R)<.003
    (Path(__file__).resolve().parents[1]/'data'/'inverse_tests.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
