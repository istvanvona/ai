# From factorial divergence to convergent coefficients
## Mellin connections and inverse reconstruction in the Lieb–Liniger model

Research manuscript and reproducibility materials, 13 November 2026.

## Read and compile

`coefficient_connections.pdf` is the complete manuscript. Its editable source is
`coefficient_connections.tex`; the bibliography is embedded in that file. The
three conceptual diagrams are drawn in TikZ. Numerical figures are vector PDFs
in `figures/`, with PNG previews also supplied. No font files are distributed.

From the bundle directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error coefficient_connections.tex
```

A standard TeX Live installation with newtx, TikZ/PGF, microtype, booktabs,
tabularx, hyperref and cleveref suffices. Alternatively run `make paper`.
The numerical code is not needed to compile the paper: all figures are included.
Author: Istvan Vona. Dated 13 November 2026. The document is a research manuscript, not a peer-reviewed publication.

## Mathematical status

The manuscript distinguishes exact identities and proved statements from formal
series algebra, conditional reconstruction and finite-data evidence. In
particular:

* The special-function connections, slit-plane resolvent argument, conformal
  coefficient map and Laguerre transform are derived explicitly.
* Lang's denominator/degree structure is proved as a formal regrouping, not as
  a globally convergent infinite block sum.
* The all-sector inverse is conditional on an exact shifted-support decomposition,
  a specified analytic germ class, growth conditions and a lateral convention.
  Those hypotheses are not proved here directly from the Fredholm equation.
* The finite-data experiment detects five action locations and estimates the first
  logarithmic/discontinuity strength with a 1.90% discrepancy against its known
  benchmark. The real quadrature and higher fluctuation coefficients remain
  numerically unresolved. This discrepancy is not a certified confidence interval.
* The Abel-smoothing bound controls an L2 kernel error if coefficient noise is
  bounded; it does not certify a Stokes coefficient or a singular derivative.

The primary-source bibliography credits the classical Mellin and Laguerre
methods and the existing Lieb–Liniger trans-series. No claim of priority for
these general methods is made.

## Numerical environment and commands

The reported run used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0 and
mpmath 1.3.0. Matplotlib supplies the figures. Install dependencies in a virtual
environment if needed:

```sh
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

The verification suite uses the included coefficient data:

```sh
python code/run_checks.py
```

To regenerate all coefficient data, perform the checks, repeat direct
integral-equation solves, and redraw the figures:

```sh
python code/run_checks.py --regenerate --figures
```

The generation uses O(N M^2) arithmetic and O(M^2) working memory, with N=4000
and M=2048 by default. The scripts do not download anything. The test runner
forces one OpenBLAS thread for reproducibility and avoids uncontrolled nested
parallelism. Floating-point roundoff remains; no interval arithmetic is used.

Individual commands are also available:

```sh
python code/generate_coefficients.py --order 4000 --nodes 2048 \
  --output data/conformal_4000_2048.npz
python code/reconstruct.py --input data/conformal_4000_2048.npz --output data
python code/verify_special_functions.py
python code/energy_to_moments.py
python code/lang_blocks.py
python code/test_inverse.py
python code/verify_dataset.py
python code/make_figures.py
```

## Files and provenance

`data/conformal_4000_2048.npz` was freshly generated for this manuscript from the
rational-kernel recurrence, without weak-coupling or trans-series input. It stores
arrays `I0` and `I2` indexed from 0 to 4000, with scalar fields `order` and `nodes`.
These are coefficients in the disk coordinate a, not coefficients directly in
1/gamma. Their first differences, divided by two, are the Laguerre coefficients.

`data/inherited_conformal_4000.npz` is the separately generated 2020-node dataset
retained from the earlier inverse-reconstruction note. It is used only as a
cross-discretization check. Its origin is distinguished from the fresh run.

`data/revalidation.json` records comparisons, software versions and SHA-256 hashes.
`data/results.json` contains the continuous action scan and finite-order C/R fits.
`data/action_spectrum.npz` holds the plotted scan grid. `data/inverse_tests.json`
contains the exact-function inverse benchmark. `data/continuation_recheck.json`
contains the direct 512/768-node integral-equation comparisons. Symbolic Lang
polynomials are in `data/blocks.json` and `data/blocks.txt`. The remaining text
files record verification output.

`figures/inverse_kernel.pdf` shows the un-differentiated inverse as an additional
figure. The manuscript instead uses `threshold_resolution.pdf`, which makes the
first logarithmic derivative singularity and finite-order oscillations visible.

The code does not implement a stable arbitrary-order analytic-continuation engine,
complete recursive higher-sector subtraction, or certified trans-series extraction.
It reproduces the exact stated scope of the numerical section.
